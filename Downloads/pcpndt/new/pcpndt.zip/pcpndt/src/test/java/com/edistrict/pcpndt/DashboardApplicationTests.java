package com.edistrict.pcpndt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
