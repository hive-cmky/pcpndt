package in.gov.serviceplus.pcpndt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcpndtApplicationTests {

	@Test
	void contextLoads() {
	}

}
