package in.gov.serviceplus.pcpndt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PcpndtApplication {

	public static void main(String[] args) {
		SpringApplication.run(PcpndtApplication.class, args);
	}

}
