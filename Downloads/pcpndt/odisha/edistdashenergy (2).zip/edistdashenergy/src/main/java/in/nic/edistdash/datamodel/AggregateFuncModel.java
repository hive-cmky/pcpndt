package in.nic.edistdash.datamodel;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AggregateFuncModel {

    private String serviceid;
    private String servicename;
    private Integer max_diff;
    private Integer min_diff;
    private Double avg_diff;
    private Double median_diff;
}
