package in.nic.edistdash.datamodel;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class percentageModel {

    private String serviceid;
    private String districtlgd;
    private String district;
    private String tehasillgd;
    private String tehasil;
    private String status;
    private Long status_count;
    private Double percentagevalue;
    private DistrictStatusModel districtStatusModel;
}
