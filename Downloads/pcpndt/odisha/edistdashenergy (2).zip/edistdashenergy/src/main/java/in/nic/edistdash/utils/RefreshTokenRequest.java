package in.nic.edistdash.utils;

import lombok.Data;

@Data
public class RefreshTokenRequest {

    private String token;
}
