package in.nic.edistdash.utils;

import lombok.Data;

@Data
public class ApplDataRequest {
	private String appRefNo;
	private String dummy1;
	private String dummy2;
}
