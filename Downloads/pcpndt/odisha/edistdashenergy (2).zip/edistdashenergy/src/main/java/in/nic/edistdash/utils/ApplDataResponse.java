package in.nic.edistdash.utils;

import lombok.Data;

@Data
public class ApplDataResponse {
	private String message;
	private String appRefNo;
	private String dummy1;
	private String dummy2;
}
