package in.nic.edistdash.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import in.nic.edistdash.entities.EnergyOfcZoneData;


public interface EnergyOfcZoneDao extends JpaRepository<EnergyOfcZoneData, String> {
	
	 @Query(value="SELECT DISTINCT main_grand_lgd_code,grand_lgd_code,parent_lgd_code,child_lgd_code,ofc_lgd_code FROM energy_ofc_zone_data where main_grand_lgd_code IN :main_lgd OR grand_lgd_code IN :main_lgd OR parent_lgd_code IN :main_lgd OR child_lgd_code IN :main_lgd OR ofc_lgd_code IN :main_lgd",nativeQuery=true)
List<Object> getDistinctlgdCodeByserviceandmainZone(@Param("main_lgd") List<String> main_lgd);
	 
	 @Query(value="SELECT DISTINCT grand_lgd_code,parent_lgd_code,child_lgd_code,ofc_lgd_code FROM energy_ofc_zone_data where grand_lgd_code IN :main_lgd OR parent_lgd_code IN :main_lgd OR child_lgd_code IN :main_lgd OR ofc_lgd_code IN :main_lgd",nativeQuery=true)
List<Object> getDistinctlgdCodeByserviceandgrandZone(@Param("main_lgd") List<String> main_lgd);
	 
	 @Query(value="SELECT DISTINCT parent_lgd_code,child_lgd_code,ofc_lgd_code FROM energy_ofc_zone_data where parent_lgd_code IN :main_lgd OR child_lgd_code IN :main_lgd OR ofc_lgd_code IN :main_lgd",nativeQuery=true)
List<Object> getDistinctlgdCodeByserviceandparentZone(@Param("main_lgd") List<String> main_lgd);
	 
	 @Query(value="SELECT DISTINCT child_lgd_code,ofc_lgd_code FROM energy_ofc_zone_data where child_lgd_code IN :main_lgd OR ofc_lgd_code IN :main_lgd",nativeQuery=true)
List<Object> getDistinctlgdCodeByserviceandchildZone(@Param("main_lgd") List<String> main_lgd);
	 
	 @Query(value="SELECT DISTINCT ofc_lgd_code FROM energy_ofc_zone_data where ofc_lgd_code IN :main_lgd",nativeQuery=true)
	 List<Object> getDistinctlgdCodeByserviceandofcZone(@Param("main_lgd") List<String> main_lgd);
}
