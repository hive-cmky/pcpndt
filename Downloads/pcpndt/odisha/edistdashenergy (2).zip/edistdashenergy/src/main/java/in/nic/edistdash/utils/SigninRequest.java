package in.nic.edistdash.utils;

import lombok.Data;

@Data
public class SigninRequest {

    private String email;
    private String password;
}
