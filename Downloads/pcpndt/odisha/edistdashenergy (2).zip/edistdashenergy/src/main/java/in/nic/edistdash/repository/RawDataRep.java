package in.nic.edistdash.repository;

import in.nic.edistdash.entities.RawData;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RawDataRep extends JpaRepository<RawData, Long> {
    List<RawData> findAllByIsProcessed(boolean isProcessed);
    
    
    
}
