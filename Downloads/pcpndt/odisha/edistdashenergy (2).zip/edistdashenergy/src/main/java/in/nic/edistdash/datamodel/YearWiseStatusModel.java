package in.nic.edistdash.datamodel;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class YearWiseStatusModel {

    private String submiyear;
    private Long deliver_count;
    private Long forward_count;
    private Long reject_count;

}

