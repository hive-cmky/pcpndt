package in.nic.edistdash.datamodel;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FindStatusModel {
    private String district;
    private String distadmin;
    private Long totalapplied;
    private Long countrjct;
    private Long countdel;
    private Long countpen;
}

