package in.nic.edistdash.entities;

import in.nic.edistdash.datamodel.FindStatusModel;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "pndt")


public class PndtData {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long id;
	private String district;
	private String appl_ref;
	private String appl_name;
	private String submi_date;
	private String clinic_name;
	private String appl_type;
	private String institute_type;
	private String owner_type;
	private String amount;
	private String payment_date;
	private String payment_mode;
	private String reference;
	private String status;
	private String due_date;
	private String distadmin;
	private String distlgd;
	private String timeline;
}
