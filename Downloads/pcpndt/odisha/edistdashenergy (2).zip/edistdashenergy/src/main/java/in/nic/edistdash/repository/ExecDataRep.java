package in.nic.edistdash.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.nic.edistdash.entities.ExecData;

public interface ExecDataRep extends JpaRepository<ExecData, Long> {
	List<ExecData> findAllByIsProcessed(boolean isProcessed);
}
