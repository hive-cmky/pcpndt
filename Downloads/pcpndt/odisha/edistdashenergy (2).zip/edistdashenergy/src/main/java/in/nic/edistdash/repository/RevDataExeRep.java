package in.nic.edistdash.repository;

import in.nic.edistdash.entities.Exeproc;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RevDataExeRep extends JpaRepository<Exeproc, String> {


}



