package in.nic.edistdash.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "exeproc")
public class Exeproc {

    @Id
    private String application_id;

    private String receivedtime;
    private String executiontime;
    private String locname;
    private String username;
    private String taskname;
    private String serviceid;
    private String taskid;
    private String status;
    private String officialform;

}
