package in.nic.edistdash.entities;


import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import com.fasterxml.jackson.databind.JsonNode;

import jakarta.persistence.Column;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "energy_initiate_data")
public class EnergyInitiatedData {


	@Id
	private String serviceid;
	private String baseservice_id;
	private String applicationid;
	private String applicationrefno;
	private String submilocation;
	private String submissiondate;
	private String duedate;
	private String routinglocation;
	private String paymentrefno;
	private String paymentdate;
	private String paymentamount;
	private String routinglocationid;
	private String routinglocationname;
	@Column(columnDefinition = "jsonb")
    @JdbcTypeCode(SqlTypes.JSON)
	private JsonNode intiatedata;

}
