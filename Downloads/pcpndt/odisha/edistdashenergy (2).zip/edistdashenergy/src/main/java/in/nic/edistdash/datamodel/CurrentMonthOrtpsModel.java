package in.nic.edistdash.datamodel;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CurrentMonthOrtpsModel {

    private String district;
    private String currentmonthdistrictlgd;
    private Long currentmonth;
    private Long currentmonthapplicationreceived;
    private Long totalprocessed;
}
