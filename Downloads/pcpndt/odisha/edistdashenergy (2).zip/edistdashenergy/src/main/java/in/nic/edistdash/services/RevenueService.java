package in.nic.edistdash.services;

import in.nic.edistdash.datamodel.*;
import in.nic.edistdash.repository.RevDataIniproRep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class RevenueService {

    @Autowired
    private RevDataIniproRep revDataIniproRep;

    public List<DistrictModel> finddistrict(){
        List<Map<String, Object>> result = revDataIniproRep.finddistrictlist();
        List<DistrictModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            DistrictModel efg = new DistrictModel();
            efg.setDistrict((String) row.get("district"));
            efg.setDistrictlgd(Long.valueOf((String) row.get("districtlgd")));
            abc.add(efg);
        }
        return abc;
    }

    public List<ServiceModel> findservice(){
        List<Map<String, Object>> result = revDataIniproRep.findservicelist();
        List<ServiceModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            ServiceModel efg = new ServiceModel();
            efg.setServiceid((String) row.get("serviceid"));
            efg.setServicename((String) row.get("servicename"));
            abc.add(efg);
        }
        return abc;
    }

    public List<ServiceNameModel> findservicenamecout(){
        List<Map<String, Object>> result = revDataIniproRep.findservicenamewithcount();
        List<ServiceNameModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            ServiceNameModel ghb = new ServiceNameModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setServicename((String) row.get("servicename"));
            ghb.setDelivercount((Long) row.get("delivercount"));
            ghb.setForwardcount((Long) row.get("forwardcount"));
            ghb.setRejectcount((Long) row.get("rejectcount"));
            ghb.setMax_diff((Integer) row.get("max_diff"));
            ghb.setMin_diff((Integer) row.get("min_diff"));
            ghb.setAvg_diff((Double) row.get("avg_diff"));
            ghb.setMedian_diff((Double) row.get("median_diff"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<DistrictStatusModel> getapplicationstatusbydistrictwisecount(){
        List<Map<String, Object>> result = revDataIniproRep.districtwisecount();
        List<DistrictStatusModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            DistrictStatusModel ghb = new DistrictStatusModel();
            ghb.setDistrict((String) row.get("district"));
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setDelivercount((Long) row.get("delivercount"));
            ghb.setForwardcount((Long) row.get("forwardcount"));
            ghb.setRejectcount((Long) row.get("rejectcount"));
            ghb.setAppliedcount((Long) row.get("appliedcount"));
            ghb.setOrtpscount((Long) row.get("ortpscount"));
            ghb.setOrtps_percentage((Double) row.get("ortps_percentage"));
            abc.add(ghb);
        }
        return abc;
    }
    public List<DistrictStatusModel> getapplicationstatusbytehasilwisecount(){
        List<Map<String, Object>> result = revDataIniproRep.tehasilwisecount();
        List<DistrictStatusModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            DistrictStatusModel ghb = new DistrictStatusModel();
            ghb.setDistrict((String) row.get("tehasil"));
            ghb.setDistrictlgd((String) row.get("tehasillgd"));
            ghb.setDelivercount((Long) row.get("delivercount"));
            ghb.setForwardcount((Long) row.get("forwardcount"));
            ghb.setRejectcount((Long) row.get("rejectcount"));
            ghb.setAppliedcount((Long) row.get("appliedcount"));
            ghb.setOrtpscount((Long) row.get("ortpscount"));
            ghb.setOrtps_percentage((Double) row.get("ortps_percentage"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<ServiceNameModel> findcountbyStartDate(Map<String, Object> requestBody) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        Date SubmitDate = formatter.parse((String) requestBody.get("SubmitDate"));
        List<Map<String, Object>> result = revDataIniproRep.findcountBystartdate(SubmitDate);
        List<ServiceNameModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            ServiceNameModel ghb = new ServiceNameModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setServicename((String) row.get("servicename"));
            ghb.setDelivercount((Long) row.get("delivercount"));
            ghb.setForwardcount((Long) row.get("forwardcount"));
            ghb.setRejectcount((Long) row.get("rejectcount"));
            ghb.setMax_diff((Integer) row.get("max_diff"));
            ghb.setMin_diff((Integer) row.get("min_diff"));
            ghb.setAvg_diff((Double) row.get("avg_diff"));
            ghb.setMedian_diff((Double) row.get("median_diff"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<ServiceNameModel> findcountByserviceId(Map<String, Object> requestBody){
    	List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
        List<Map<String, Object>> result = revDataIniproRep.findcountByserviceId(serviceIds);
        List<ServiceNameModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            ServiceNameModel ghb = new ServiceNameModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setServicename((String) row.get("servicename"));
            ghb.setDelivercount((Long) row.get("delivercount"));
            ghb.setForwardcount((Long) row.get("forwardcount"));
            ghb.setRejectcount((Long) row.get("rejectcount"));
            ghb.setMax_diff((Integer) row.get("max_diff"));
            ghb.setMin_diff((Integer) row.get("min_diff"));
            ghb.setAvg_diff((Double) row.get("avg_diff"));
            ghb.setMedian_diff((Double) row.get("median_diff"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<ServiceNameModel> findcountByserviceIdAndDistrict(Map<String, Object> requestBody){
    	List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
    	List<String> districtIds = (List<String>) requestBody.get("districtIds");
        List<Map<String, Object>> result = revDataIniproRep.findcountByserviceIdAndDistrict(serviceIds,districtIds);
        List<ServiceNameModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            ServiceNameModel ghb = new ServiceNameModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setServicename((String) row.get("servicename"));
            ghb.setDelivercount((Long) row.get("delivercount"));
            ghb.setForwardcount((Long) row.get("forwardcount"));
            ghb.setRejectcount((Long) row.get("rejectcount"));
            ghb.setMax_diff((Integer) row.get("max_diff"));
            ghb.setMin_diff((Integer) row.get("min_diff"));
            ghb.setAvg_diff((Double) row.get("avg_diff"));
            ghb.setMedian_diff((Double) row.get("median_diff"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<Object> getDistrictlist(Map<String, Object> requestBody) {
    	List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
         List<Object> list = null;
        list= revDataIniproRep.getDistinctServiceByDistrict(serviceIds);
        return list;
    }

    public List<YearWiseStatusModel> findyearwisestatuscount(){
        List<Map<String, Object>> result = revDataIniproRep.yearwisestatuscount();
        List<YearWiseStatusModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            YearWiseStatusModel ghb = new YearWiseStatusModel();
            ghb.setSubmiyear((String) row.get("submiyear"));
            ghb.setDeliver_count((Long) row.get("deliver_count"));
            ghb.setForward_count((Long) row.get("forward_count"));
            ghb.setReject_count((Long) row.get("reject_count"));
            abc.add(ghb);
        }
        return abc;
    }


    public Object getCountDeliverData() {
        return revDataIniproRep.countDeliverRevdata();
    }

    public Object getCountForwardData() {
        return revDataIniproRep.countForwardRevdata();
    }

    public Object getCountRejectData() {
        return revDataIniproRep.countRejectRevdata();
    }

    public Object getalltimetakenvalue(){ return revDataIniproRep.getalltimetakenvalue();}

    public Object getalltimetakenvaluebyStartdate(Map<String, Object> requestBody) throws ParseException {

        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        Date SubmitDate = formatter.parse((String) requestBody.get("SubmitDate"));
        System.out.println(requestBody.get("SubmitDate"));
        return revDataIniproRep.getalltimetakenvaluebystartdate(SubmitDate);
    }

    public Object getalltimetakenvaluebyServiceid(Map<String, Object> requestBody){
        List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
        return revDataIniproRep.getalltimetakenvaluebyserviceId(serviceIds);
    }

    public Object getalltimetakenvaluebyServiceidanddistrict(Map<String, Object> requestBody){
        List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
        List<String> districtIds = (List<String>) requestBody.get("districtIds");
        return revDataIniproRep.getalltimetakenvaluebyserviceIdanddistrict(serviceIds,districtIds);
    }

    public List<AggregateFuncModel> findaggregatefuncvalue(){
        List<Map<String, Object>> result = revDataIniproRep.aggregatefunc();
        List<AggregateFuncModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            AggregateFuncModel ghb = new AggregateFuncModel();
                ghb.setServiceid((String) row.get("serviceid"));
            ghb.setServicename((String) row.get("servicename"));
                ghb.setMax_diff((Integer) row.get("max_diff"));
                ghb.setMin_diff((Integer) row.get("min_diff"));
                ghb.setAvg_diff((Double) row.get("avg_diff"));
                ghb.setMedian_diff((Double) row.get("median_diff"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<percentageModel> findtopperformercountbydistrictwise(){
        List<Map<String, Object>> result = revDataIniproRep.topperformerpercentage();
        List<percentageModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            percentageModel ghb = new percentageModel();
                ghb.setServiceid((String) row.get("serviceid"));
                ghb.setDistrictlgd((String) row.get("districtlgd"));
                ghb.setDistrict((String) row.get("district"));
                ghb.setStatus((String) row.get("status"));
                ghb.setStatus_count((Long) row.get("status_count"));
                ghb.setPercentagevalue((Double) row.get("percentagevalue"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<percentageModel> findtopperformercountbyStartdate(Map<String, Object> requestBody) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        Date SubmitDate = formatter.parse((String) requestBody.get("SubmitDate"));
        List<Map<String, Object>> result = revDataIniproRep.topperformerbystartdate(SubmitDate);
        List<percentageModel> abc = new ArrayList<>();
        for(Map<String, Object> row : result){
            percentageModel ghb = new percentageModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setDistrict((String) row.get("district"));
            ghb.setStatus((String) row.get("status"));
            ghb.setStatus_count((Long) row.get("status_count"));
            ghb.setPercentagevalue((Double) row.get("percentagevalue"));
            abc.add(ghb);
        }
        return abc;
    }

     public List<percentageModel> findtopperformercountbyserviceid(Map<String, Object> requestBody){
        List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
        List<Map<String, Object>> result = revDataIniproRep.topperformerbyserviceId(serviceIds);
        List<percentageModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            percentageModel ghb = new percentageModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setDistrict((String) row.get("district"));
            ghb.setStatus((String) row.get("status"));
            ghb.setStatus_count((Long) row.get("status_count"));
            ghb.setPercentagevalue((Double) row.get("percentagevalue"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<percentageModel> findBottomperformerbyserviceId(Map<String, Object> requestBody){
        List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
        List<Map<String, Object>> result = revDataIniproRep.BottomperformerbyserviceId(serviceIds);
        List<percentageModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            percentageModel ghb = new percentageModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setDistrict((String) row.get("district"));
            ghb.setStatus((String) row.get("status"));
            ghb.setStatus_count((Long) row.get("status_count"));
            ghb.setPercentagevalue((Double) row.get("percentagevalue"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<percentageModel> topperformerbyServiceIdAndDistrict(Map<String, Object> requestBody){
        List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
        List<String> districtIds = (List<String>) requestBody.get("districtIds");
        List<Map<String, Object>> result = revDataIniproRep.topperformerbyserviceIdanddistrict(serviceIds,districtIds);
        List<percentageModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            percentageModel ghb = new percentageModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setDistrict((String) row.get("district"));
            ghb.setStatus((String) row.get("status"));
            ghb.setStatus_count((Long) row.get("status_count"));
            ghb.setPercentagevalue((Double) row.get("percentagevalue"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<percentageModel> BottomperformerbyserviceIdanddistrict(Map<String, Object> requestBody){
        List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
        List<String> districtIds = (List<String>) requestBody.get("districtIds");
        List<Map<String, Object>> result = revDataIniproRep.BottomperformerbyserviceIdanddistrict(serviceIds,districtIds);
        List<percentageModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            percentageModel ghb = new percentageModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setDistrict((String) row.get("district"));
            ghb.setStatus((String) row.get("status"));
            ghb.setStatus_count((Long) row.get("status_count"));
            ghb.setPercentagevalue((Double) row.get("percentagevalue"));
            abc.add(ghb);
        }
        return abc;
    }



    public List<percentageModel> findbottomperformercountbydistrict(){
        List<Map<String, Object>> result = revDataIniproRep.bottomformerpercentage();
        List<percentageModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
        	percentageModel ghb = new percentageModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setDistrict((String) row.get("district"));
            ghb.setStatus((String) row.get("status"));
            ghb.setStatus_count((Long) row.get("status_count"));
            ghb.setPercentagevalue((Double) row.get("percentagevalue"));
            abc.add(ghb);
        }
        return abc;
    }
    
    public List<percentageModel> topPerformerByTehasil(){
        List<Map<String, Object>> result = revDataIniproRep.topPerformerByTehasil();
        List<percentageModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
        	percentageModel ghb = new percentageModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setDistrict((String) row.get("district"));
            ghb.setTehasillgd((String) row.get("tehasillgd"));
            ghb.setTehasil((String) row.get("tehasil"));
            ghb.setStatus((String) row.get("status"));
            ghb.setStatus_count((Long) row.get("status_count"));
            ghb.setPercentagevalue((Double) row.get("percentagevalue"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<percentageModel> TopPerformerbyTehasilbyStartDate(Map<String, Object> requestBody) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        Date SubmitDate = formatter.parse((String) requestBody.get("SubmitDate"));
        List<Map<String, Object>> result = revDataIniproRep.topPerformerbyTehasilbystartdate(SubmitDate);
        List<percentageModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            percentageModel ghb = new percentageModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setDistrict((String) row.get("district"));
            ghb.setTehasillgd((String) row.get("tehasillgd"));
            ghb.setTehasil((String) row.get("tehasil"));
            ghb.setStatus((String) row.get("status"));
            ghb.setStatus_count((Long) row.get("status_count"));
            ghb.setPercentagevalue((Double) row.get("percentagevalue"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<percentageModel> TopPerformerbyTehasilbyServiceId(Map<String, Object> requestBody){
        List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
        List<Map<String, Object>> result = revDataIniproRep.topPerformerbyTehasilbyserviceId(serviceIds);
        List<percentageModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            percentageModel ghb = new percentageModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setDistrict((String) row.get("district"));
            ghb.setTehasillgd((String) row.get("tehasillgd"));
            ghb.setTehasil((String) row.get("tehasil"));
            ghb.setStatus((String) row.get("status"));
            ghb.setStatus_count((Long) row.get("status_count"));
            ghb.setPercentagevalue((Double) row.get("percentagevalue"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<percentageModel> TopPerformerbyTehasilbyserviceIdandDistrict(Map<String, Object> requestBody){
        List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
        List<String> districtIds = (List<String>) requestBody.get("districtIds");
        List<Map<String, Object>> result = revDataIniproRep.TopPerformerbyTehasilbyserviceIdanddistrict(serviceIds,districtIds);
        List<percentageModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            percentageModel ghb = new percentageModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setDistrict((String) row.get("district"));
            ghb.setTehasillgd((String) row.get("tehasillgd"));
            ghb.setTehasil((String) row.get("tehasil"));
            ghb.setStatus((String) row.get("status"));
            ghb.setStatus_count((Long) row.get("status_count"));
            ghb.setPercentagevalue((Double) row.get("percentagevalue"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<percentageModel> BottomPerformerByTehasil(){
        List<Map<String, Object>> result = revDataIniproRep.BottomPerformerByTehasil();
        List<percentageModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
        	percentageModel ghb = new percentageModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setDistrict((String) row.get("district"));
            ghb.setTehasillgd((String) row.get("tehasillgd"));
            ghb.setTehasil((String) row.get("tehasil"));
            ghb.setStatus((String) row.get("status"));
            ghb.setStatus_count((Long) row.get("status_count"));
            ghb.setPercentagevalue((Double) row.get("percentagevalue"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<percentageModel> BottomPerformerbyTehasilbyServiceId(Map<String, Object> requestBody){
        List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
        List<Map<String, Object>> result = revDataIniproRep.BottomPerformerTehasilbyserviceId(serviceIds);
        List<percentageModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            percentageModel ghb = new percentageModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setDistrict((String) row.get("district"));
            ghb.setTehasillgd((String) row.get("tehasillgd"));
            ghb.setTehasil((String) row.get("tehasil"));
            ghb.setStatus((String) row.get("status"));
            ghb.setStatus_count((Long) row.get("status_count"));
            ghb.setPercentagevalue((Double) row.get("percentagevalue"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<percentageModel> BottomPerformerbyTehasilbyServiceIdandDistrict(Map<String, Object> requestBody){
        List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
        List<String> districtIds = (List<String>) requestBody.get("districtIds");
        List<Map<String, Object>> result = revDataIniproRep.BottomPerformerbyTehasilbyserviceIdanddistrict(serviceIds,districtIds);
        List<percentageModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            percentageModel ghb = new percentageModel();
            ghb.setServiceid((String) row.get("serviceid"));
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setDistrict((String) row.get("district"));
            ghb.setTehasillgd((String) row.get("tehasillgd"));
            ghb.setTehasil((String) row.get("tehasil"));
            ghb.setStatus((String) row.get("status"));
            ghb.setStatus_count((Long) row.get("status_count"));
            ghb.setPercentagevalue((Double) row.get("percentagevalue"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<DistrictStatusCountModel> finddistrictwisecountstatus(){
        List<Map<String, Object>> result = revDataIniproRep.districtwisecountstatus();
        List<DistrictStatusCountModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            DistrictStatusCountModel ghb = new DistrictStatusCountModel();
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setDistrict((String) row.get("district"));
            ghb.setDuedate((String) row.get("duedate"));
            ghb.setExecutiontime((String) row.get("executiontime"));
            ghb.setNew_status((String) row.get("new_status"));
            ghb.setCount_status((Integer) row.get("count_status"));
            ghb.setDelivercount((Long) row.get("delivercount"));
            ghb.setForwardcount((Long) row.get("forwardcount"));
            ghb.setRejectcount((Long) row.get("rejectcount"));
            ghb.setApplied_count((Long) row.get("applied_count"));
            ghb.setPercentage((Double) row.get("percentage"));
            abc.add(ghb);
        }
        return abc;
    }


    public List<DistrictStatusModel> findortpscountbystartdate(Map<String, Object> requestBody) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        Date SubmitDate = formatter.parse((String) requestBody.get("SubmitDate"));

        System.out.println(requestBody.get("SubmitDate"));

        List<Map<String, Object>> result = revDataIniproRep.ortpscountbystartdate(SubmitDate);
        List<DistrictStatusModel> abc = new ArrayList<>();
        for(Map<String, Object> row : result){
            DistrictStatusModel ghb = new DistrictStatusModel();
            ghb.setDistrict((String) row.get("district"));
            ghb.setDelivercount((Long) row.get("delivercount"));
            ghb.setForwardcount((Long) row.get("forwardcount"));
            ghb.setRejectcount((Long) row.get("rejectcount"));
            ghb.setAppliedcount((Long) row.get("appliedcount"));
            ghb.setOrtpscount((Long) row.get("ortpscount"));
            ghb.setOrtps_percentage((Double) row.get("ortps_percentage"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<DistrictStatusModel> findortpscountbyserviceId(Map<String, Object> requestBody){
        List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
        List<Map<String, Object>> result = revDataIniproRep.ortpscountbyserviceId(serviceIds);
        List<DistrictStatusModel> abc = new ArrayList<>();
        for(Map<String, Object> row : result){
            DistrictStatusModel ghb = new DistrictStatusModel();
            ghb.setDistrict((String) row.get("district"));
            ghb.setDelivercount((Long) row.get("delivercount"));
            ghb.setForwardcount((Long) row.get("forwardcount"));
            ghb.setRejectcount((Long) row.get("rejectcount"));
            ghb.setAppliedcount((Long) row.get("appliedcount"));
            ghb.setOrtpscount((Long) row.get("ortpscount"));
            ghb.setOrtps_percentage((Double) row.get("ortps_percentage"));
            abc.add(ghb);
        }
        return abc;
    }
    public List<DistrictStatusModel> findortpsTehasilcountbyserviceId(Map<String, Object> requestBody){
        List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
        List<Map<String, Object>> result = revDataIniproRep.ortpsTehasilcountbyserviceId(serviceIds);
        List<DistrictStatusModel> abc = new ArrayList<>();
        for(Map<String, Object> row : result){
            DistrictStatusModel ghb = new DistrictStatusModel();
            ghb.setDistrict((String) row.get("tehasil"));
            ghb.setDelivercount((Long) row.get("delivercount"));
            ghb.setForwardcount((Long) row.get("forwardcount"));
            ghb.setRejectcount((Long) row.get("rejectcount"));
            ghb.setAppliedcount((Long) row.get("appliedcount"));
            ghb.setOrtpscount((Long) row.get("ortpscount"));
            ghb.setOrtps_percentage((Double) row.get("ortps_percentage"));
            abc.add(ghb);
        }
        return abc;
    }

    public List<DistrictStatusModel> findOrtpscountbyServiceIdandDistrict(Map<String, Object> requestBody){
        List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
        List<String> districtIds = (List<String>) requestBody.get("districtIds");
        List<Map<String, Object>> result = revDataIniproRep.ortpscountbyserviceIdanddistrict(serviceIds,districtIds);
        List<DistrictStatusModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            DistrictStatusModel ghb = new DistrictStatusModel();
            ghb.setDistrict((String) row.get("district"));
            ghb.setDelivercount((Long) row.get("delivercount"));
            ghb.setForwardcount((Long) row.get("forwardcount"));
            ghb.setRejectcount((Long) row.get("rejectcount"));
            ghb.setAppliedcount((Long) row.get("appliedcount"));
            ghb.setOrtpscount((Long) row.get("ortpscount"));
            ghb.setOrtps_percentage((Double) row.get("ortps_percentage"));
            abc.add(ghb);
        }
        return abc;
    }
    public List<DistrictStatusModel> findOrtpsTehasilcountbyServiceIdandDistrict(Map<String, Object> requestBody){
        List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
        List<String> districtIds = (List<String>) requestBody.get("districtIds");
        List<Map<String, Object>> result = revDataIniproRep.ortpsTehasilcountbyserviceIdanddistrict(serviceIds,districtIds);
        List<DistrictStatusModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            DistrictStatusModel ghb = new DistrictStatusModel();
            ghb.setDistrict((String) row.get("tehasil"));
            ghb.setDelivercount((Long) row.get("delivercount"));
            ghb.setForwardcount((Long) row.get("forwardcount"));
            ghb.setRejectcount((Long) row.get("rejectcount"));
            ghb.setAppliedcount((Long) row.get("appliedcount"));
            ghb.setOrtpscount((Long) row.get("ortpscount"));
            ghb.setOrtps_percentage((Double) row.get("ortps_percentage"));
            abc.add(ghb);
        }
        return abc;
    }
    public List<percentageModel> findAppliedPendingRejectOrtpscountOrtpspercentagebyTehasil(String id){
        List<Map<String, Object>> result = revDataIniproRep.findappliedpendingrejectortpscountortpspercentagebytehasil(String.valueOf(id));
        List<percentageModel> abc = new ArrayList<>();

        for(Map<String, Object> row : result){
            percentageModel ghb = new percentageModel();
            DistrictStatusModel fgh = new DistrictStatusModel();

            ghb.setTehasil((String) row.get("tehasil"));
            ghb.setTehasillgd((String) row.get("tehasillgd"));
            fgh.setDelivercount((Long) row.get("delivercount"));
            fgh.setRejectcount((Long) row.get("rejectcount"));
            fgh.setAppliedcount((Long) row.get("appliedcount"));
            fgh.setForwardcount((Long) row.get("forwardcount"));
            fgh.setOrtpscount((Long) row.get("ortpscount"));
            fgh.setOrtps_percentage((Double) row.get("ortps_percentage"));
            ghb.setDistrictStatusModel(fgh);
            abc.add(ghb);
        }
        return abc;
    }

    public List<allCountModel> findOrtpscountbySubmissionmonthandyear(Map<String, Object> requestBody) {

    	String endDate = (String) requestBody.get("enddate");

    	String[] endDateParts = endDate.split("-");
    	int endYear = Integer.parseInt(endDateParts[0]);
    	int endMonth = Integer.parseInt(endDateParts[1]);

    	int previousMonth = endMonth - 1;

    	if (previousMonth == 0) {
    	    previousMonth = 12;
    	    endYear = endYear - 1;
    	}

    	
    	String formattedMonth = String.format("%02d", previousMonth);
    	String dateEnd = endYear + "-" + formattedMonth;
    	System.out.println(formattedMonth);
    	
    	System.out.println(endYear);
    	System.out.println("------------prevdateend");
    	System.out.println(dateEnd);



        List<Object> submissionDate = revDataIniproRep.findortpsdistrictwisebysubmidate();
        String startDate = submissionDate.toString();
        List<Map<String, Object>> currentmonth = revDataIniproRep.findortpscountbycurrentmonth(endDate);
        List<Map<String, Object>> result = revDataIniproRep.findortpscountdistrictwisebymonthandyear(startDate, dateEnd);

        List<OrtpsCountModel> abc = new ArrayList<>();
        List<CurrentMonthOrtpsModel> check = new ArrayList<>();

        // Populate the checklist
        for (Map<String, Object> xyz : currentmonth) {
            CurrentMonthOrtpsModel ortps = new CurrentMonthOrtpsModel();
            ortps.setDistrict((String) xyz.get("district"));
            ortps.setCurrentmonthdistrictlgd((String) xyz.get("districtlgd"));
            ortps.setCurrentmonth((Long) xyz.get("currentmonth"));
            ortps.setCurrentmonthapplicationreceived((Long) xyz.get("currentmonthapplicationreceived"));
            ortps.setTotalprocessed((Long) xyz.get("totalprocessed"));
            check.add(ortps);
        }

        // Populate the abc list
        for (Map<String, Object> row : result) {
            OrtpsCountModel ghb = new OrtpsCountModel();
            ghb.setDistrict((String) row.get("district"));
            ghb.setDistrictlgd((String) row.get("districtlgd"));
            ghb.setTotal_applications((Long) row.get("total_applications"));
            ghb.setForward_count((Long) row.get("forward_count"));
            ghb.setOrtps_count((Long) row.get("ortps_count"));
            abc.add(ghb);
        }

       
        List<allCountModel> mergedList = new ArrayList<>();

        for (OrtpsCountModel abcItem : abc) {
            boolean isMerged = false;
            
            for (CurrentMonthOrtpsModel checkItem : check) {
                if (abcItem.getDistrictlgd().equals(checkItem.getCurrentmonthdistrictlgd())) {
                   
                    allCountModel mergedItem = new allCountModel();
                    
                    // Set fields from abcItem
                    mergedItem.setDistrict(abcItem.getDistrict());
                    mergedItem.setDistrictlgd(abcItem.getDistrictlgd());
                    mergedItem.setTotal_applications(abcItem.getTotal_applications());
                    mergedItem.setForward_count(abcItem.getForward_count());
                    mergedItem.setOrtps_count(abcItem.getOrtps_count());
                    
                    // Set fields from checkItem
                    mergedItem.setCurrentmonthdistrictlgd(checkItem.getCurrentmonthdistrictlgd());
                    mergedItem.setCurrentmonth(checkItem.getCurrentmonth());
                    mergedItem.setCurrentmonthapplicationreceived(checkItem.getCurrentmonthapplicationreceived());
                    mergedItem.setTotalprocessed(checkItem.getTotalprocessed());
                    
                    mergedList.add(mergedItem);
                    isMerged = true;
                    break; 
                }
            }
            
            if (!isMerged) {
               
                allCountModel mergedItem = new allCountModel();
                mergedItem.setDistrict(abcItem.getDistrict());
                mergedItem.setDistrictlgd(abcItem.getDistrictlgd());
                mergedItem.setTotal_applications(abcItem.getTotal_applications());
                mergedItem.setForward_count(abcItem.getForward_count());
                mergedItem.setOrtps_count(abcItem.getOrtps_count());
                mergedList.add(mergedItem);
            }
        }

       
        for (CurrentMonthOrtpsModel checkItem : check) {
            boolean isPresent = false;
            
            for (allCountModel mergedItem : mergedList) {
                if (checkItem.getCurrentmonthdistrictlgd().equals(mergedItem.getDistrictlgd())) {
                    isPresent = true;
                    break;
                }
            }
            
            if (!isPresent) {
               
                allCountModel mergedItem = new allCountModel();
                mergedItem.setDistrict(checkItem.getDistrict());
                mergedItem.setDistrictlgd(checkItem.getCurrentmonthdistrictlgd());
                mergedItem.setCurrentmonth(checkItem.getCurrentmonth());
                mergedItem.setCurrentmonthapplicationreceived(checkItem.getCurrentmonthapplicationreceived());
                mergedItem.setTotalprocessed(checkItem.getTotalprocessed());
                mergedList.add(mergedItem);
            }
        }

        return mergedList;


    }


    public List<Object> findofficenamebypendingcountoftehasil(String id){
        return revDataIniproRep.findofficenamebypendingcountoftehasil(String.valueOf(Integer.parseInt(id)));
    }

    public List<Object> findOfficebyOrtpsCount(String id){
        return revDataIniproRep.findofficebyortpscount(String.valueOf(Integer.parseInt(id)));
    }

    public List<Object> FindOfficebyTehasilOrtpscount(String id){
        return revDataIniproRep.findofficebytehasilortpscount(String.valueOf(Integer.parseInt(id)));
    }

    public List<Object> findofficenamebypendingcount(String id){
        return revDataIniproRep.findofficenamebypendingcount(String.valueOf(Integer.parseInt(id)));
    }



    public List<Object> findusernameandtaskidbyofficetype(String id){
        return revDataIniproRep.findusernameandtaskidbyofficetype(id);
    }

    public List<Object> findusernameandtaskidbyortpscount(String id){
        return revDataIniproRep.findusernameandtaskidbyortpscount(id);
    }
}

