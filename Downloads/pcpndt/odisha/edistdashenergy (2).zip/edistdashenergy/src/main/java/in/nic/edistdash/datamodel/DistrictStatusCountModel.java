package in.nic.edistdash.datamodel;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DistrictStatusCountModel {

    private String districtlgd;
    private String district;
    private String duedate;
    private String executiontime;
    private String new_status;
    private Integer count_status;
    private Long delivercount;
    private Long forwardcount;
    private Long rejectcount;
    private Long applied_count;
    private Double percentage;
}
