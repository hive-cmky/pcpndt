package in.nic.edistdash.datamodel;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrtpsCountModel {

    private String district;
    private String districtlgd;
    private Long total_applications;
    private Long forward_count;
    private Long ortps_count;
}
