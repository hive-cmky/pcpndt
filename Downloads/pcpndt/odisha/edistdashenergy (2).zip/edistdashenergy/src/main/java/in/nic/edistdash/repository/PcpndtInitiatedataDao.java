package in.nic.edistdash.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import in.nic.edistdash.entities.PcpndtInitiatedData;

public interface PcpndtInitiatedataDao extends JpaRepository<PcpndtInitiatedData, String> {
	
	
	@Query(value = "WITH diff_calculation AS (SELECT (to_timestamp(e.execution_time, 'DD-MM-YYYY')\\:\\:date - to_timestamp(i.submission_date, 'DD-MM-YYYY')\\:\\:date) AS diff, i.routinglocationid FROM pcpndt_initiated_data AS i INNER JOIN pcpndt_execution_filtered AS e ON i.appl_id = e.appl_id WHERE e.status IS NOT NULL), status_counts AS (SELECT i.routinglocationid, COUNT(CASE WHEN e.status = 'Deliver' THEN 1 END) AS delivercount, COUNT(CASE WHEN e.status = 'Forward' THEN 1 END) AS forwardcount, COUNT(CASE WHEN e.status = 'Reject' THEN 1 END) AS rejectcount FROM pcpndt_initiated_data AS i INNER JOIN pcpndt_execution_filtered AS e ON i.appl_id = e.appl_id WHERE e.status IS NOT NULL GROUP BY i.routinglocationid) SELECT s.routinglocationid, es.routinglocationname, MAX(d.diff) AS max_diff, MIN(d.diff) AS min_diff, ROUND(AVG(d.diff), 2)\\:\\:double precision AS avg_diff, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY d.diff) AS median_diff, s.delivercount, s.forwardcount, s.rejectcount FROM status_counts AS s JOIN diff_calculation AS d ON s.routinglocationid = d.routinglocationid JOIN pcpndt_districtnmlgd es ON es.routinglocationid = s.routinglocationid GROUP BY s.routinglocationid, es.routinglocationname, s.delivercount, s.forwardcount, s.rejectcount", nativeQuery = true)
	List<Map<String, Object>> findMaxMinTimeByServicePcpndt();

}
