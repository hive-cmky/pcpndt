package in.nic.edistdash.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class FinalTab {


    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    private long id;
    private String appl_id;
    private String appl_ref_no;
    private String service_id;
    private String inital_json;
    private String exec_json;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date executed_time;
}
