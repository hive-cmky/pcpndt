package in.nic.edistdash.repository;

import in.nic.edistdash.entities.District;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistrictRepo extends JpaRepository<District, Long> {
}
