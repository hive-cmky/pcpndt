package in.nic.edistdash.controller;

import java.util.List;

import in.nic.edistdash.datamodel.ApprovedStatusModel;
import in.nic.edistdash.datamodel.FindStatusModel;
import in.nic.edistdash.datamodel.PendingStatusModel;
import in.nic.edistdash.datamodel.RejectedStatusModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import in.nic.edistdash.entities.PndtData;
import in.nic.edistdash.services.PndtService;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class PndtController {
    @Autowired
    private PndtService pndtService;
    @GetMapping("/")
    public String login(Model model) {
    	 System.out.println("Inside root");
        return "login"; 
    }
    @GetMapping("/login")
    public String loginPage(Model model, HttpServletResponse response) {
        return "login"; 
    }
    
    @GetMapping("/pcpndt")
    public String pcndt(Model model, HttpServletResponse response) {
        return "pcpndt";
    }
    
    @GetMapping("/pndt")
    public String pndt(Model model, HttpServletResponse response) {
        return "pndt";
    }

    @GetMapping("/Revenue")
    public String Revenue(Model model, HttpServletResponse response) {
        return "Revenue";
    }
    @GetMapping("/Search")
    public String Search(Model model, HttpServletResponse response) {
        return "EnergySearch";
    }

    @GetMapping("/ServicewiseFilter")
    public String ServicewiseFilter(Model model, HttpServletResponse response) {
        return "ServiceFilter";
    }


    @GetMapping("/Home")
    public String Home(Model model, HttpServletResponse response) {
        return "Home";
    }
  
    @GetMapping("/Energy")
    public String Energy(Model model, HttpServletResponse response) {
        return "Energy";
    }
    @GetMapping("/pndtAllData")
    @ResponseBody
    public List<PndtData> getAllData() {
        return pndtService.getAllData();
    }

    @GetMapping("/getPndtCount")
    @ResponseBody
    public long getPndtCount() {
        return pndtService.getPndtCount();
    }

    @GetMapping("/getPendingData")
    @ResponseBody
    public List<PndtData> getPendingData() {
        return pndtService.getPendingData();
    }

    @GetMapping("/getCountPendingData")
    @ResponseBody
    public Object getCountPendingData() {
        return pndtService.getCountPendingData();
    }

    @GetMapping("/getApprovedPndData")
    @ResponseBody
    public List<PndtData> findApprovedPndData() {
        return pndtService.findApprovedPndData();
    }

    @GetMapping("/getcountApprovedPndData")
    @ResponseBody
    public Object countApprovedPndData() {
        return pndtService.countApprovedPndData();
    }

    @GetMapping("/getRejectPndData")
    @ResponseBody
    public List<PndtData> findRejectedData() {
        return pndtService.findRejectedPndData();
    }

    @GetMapping("/getcountRejectPndData")
    @ResponseBody
    public Object countRejectPndData() {
        return pndtService.countRejectPndData();
    }

    // Shaswat starts

    @GetMapping("/getRenewalPndData")
    @ResponseBody
    public List<PndtData> findRenewalPndData() {
        return pndtService.findRenewalPndData();
    }

    @GetMapping("/getcountRenewalPndData")
    @ResponseBody
    public Object countRenewalPndData() {
        return pndtService.countRenewalPndData();
    }

    @GetMapping("/getfindNewRegistrationPndData")
    @ResponseBody
    public List<PndtData> findNewRegistrationPndData() {
        return pndtService.findNewRegistrationPndData();
    }

    @GetMapping("/getcountNewRegistrationPndData")
    @ResponseBody
    public Object countNewRegistrationPndData() {
        return pndtService.countNewRegistrationPndData();
    }

    @GetMapping("/getfindFreshApplicationPndData")
    @ResponseBody
    public List<PndtData> findFreshApplicationPndData() {
        return pndtService.findFreshApplicationPndData();
    }

    @GetMapping("/getcountfindFreshApplicationPndData")
    @ResponseBody
    public Object countFreshApplicationPndData() {
        return pndtService.countFreshApplicationPndData();
    }

    @GetMapping("/getfindReapplyPndData")
    @ResponseBody
    public List<PndtData> findReapplyPndData() {
        return pndtService.findReapplyPndData();
    }

    @GetMapping("/getcountReapplyPndData")
    @ResponseBody
    public Object countReapplyPndData() {
        return pndtService.countReapplyPndData();
    }

    @GetMapping("/getfindapplyFormBPndData")
    @ResponseBody
    public List<PndtData> findapplyFormBPndData() {
        return pndtService.findapplyFormBPndData();
    }

    @GetMapping("/getcountapplyFormBPndData")
    @ResponseBody
    public Object countapplyFormBPndData() {
        return pndtService.countapplyFormBPndData();
    }

    @GetMapping("/getfindRegisterPndData")
    @ResponseBody
    public List<PndtData> findRegisterPndData() {
        return pndtService.findRegisterPndData();
    }

    @GetMapping("/getcountRegisterPndData")
    @ResponseBody
    public Object countRegisterPndData() {
        return pndtService.countRegisterPndData();
    }

    @GetMapping("/totalAppliedByDistrict")
    @ResponseBody
    public List<FindStatusModel> getTotalApplication() {
        return pndtService.countTotalApplicationByDistrict();
    }


    @GetMapping("/totalstatusbydistrict")
    @ResponseBody
    public List<FindStatusModel> getTotalDeliveredApplication() {
        return pndtService.countTotalDeliveredByDistrict();
    }

    @GetMapping("/countapproveddistrictwise")
    @ResponseBody
    public List<ApprovedStatusModel> countapproveddistrictwise() {
        return pndtService.findApprovedByDistrictWise();
    }

    @GetMapping("/findpendbydistrictwise")
    @ResponseBody
    public List<PendingStatusModel> countpenbydistrictwise() {
        return pndtService.findpendingbydistrictwise();
    }

    @GetMapping("/findrjctdistrictwise")
    @ResponseBody
    public List<RejectedStatusModel> countrjcdistrictwise() {
        return pndtService.findrjctbydistrictwise();
    }

    @GetMapping("/totalUnderProcessByDistrict")
    @ResponseBody
    public List<FindStatusModel> getTotalUnderProcessApplication() {
        return pndtService.countTotalUnderProcessByDistrict();
    }

    @GetMapping("/totalRejectedByDistrict")
    @ResponseBody
    public List<FindStatusModel> getTotalRejectedApplication() {
        return pndtService.countTotalRejectedByDistrict();
    }

//By Using distadmin we can get the district by status list of type(Under Process, Rejected and Delivered)


    @GetMapping("/totaldeliveredbydistrict/{id}")
    @ResponseBody
    public List<PndtData> getotaldelivered(@PathVariable String id) throws NumberFormatException {
        return pndtService.totaldata(id);
    }

    @GetMapping("/totalpendingbydistrict/{id}")
    @ResponseBody
    public List<PndtData> getpending(@PathVariable String id) {
        return pndtService.penddata(id);
    }

    @GetMapping("/getTotalRejectPndData/{id}")
    @ResponseBody
    public List<PndtData> findRejectPndData(@PathVariable String id) {
        return pndtService.findRejectPndData(id);
    }

    @GetMapping("/getAppliedList/{id}")
    @ResponseBody
    public List<PndtData> findListapplied(@PathVariable String id) {
        return pndtService.findListApplied(id);
    }

}
