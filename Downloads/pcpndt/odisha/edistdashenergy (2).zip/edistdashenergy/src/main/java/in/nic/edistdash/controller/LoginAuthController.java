package in.nic.edistdash.controller;

import in.nic.edistdash.entities.UserLogin;
import in.nic.edistdash.repository.UserLoginRepository;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class LoginAuthController {

	

    private final AuthenticationManager authenticationManager;
    private final UserLoginRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    


    public LoginAuthController(AuthenticationManager authenticationManager, UserLoginRepository userRepository, PasswordEncoder passwordEncoder) {
        this.authenticationManager = authenticationManager;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/register")
    public String register(@RequestBody UserLogin user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);
        return "User registered successfully";
    }

    @PostMapping("/login")
    public String login(@RequestBody Map<String, String> loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.get("username"), loginRequest.get("password"))
        );
        SecurityContextHolder.getContext().setAuthentication(authentication);
        return "Login successful";
        //return "http://localhost:8090/Revenue";
    }
   
}