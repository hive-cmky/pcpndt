package in.nic.edistdash.entities;


import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import com.fasterxml.jackson.databind.JsonNode;

import jakarta.persistence.Column;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "energy_execution_data")
public class EnergyExecuteData {
	   @Id  
	    private String service_id;
	   private String baseservice_id;
	   private String appl_id;
	   private String user_id;
	   private String task_name;
	   private String user_name;
	   private String user_location;
	   private String receive_time;
	   private String execution_time;
	   private String status;
	   private String payment_date;
	   private String payment_amount;
	   private String payment_ref;

	   @Column(columnDefinition = "jsonb")
	    @JdbcTypeCode(SqlTypes.JSON)
	   private JsonNode executiondata;

}
