package in.nic.edistdash.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.nic.edistdash.entities.EnergyOffice;


public interface EnergyOfficeDao extends JpaRepository<EnergyOffice, String> {

}
