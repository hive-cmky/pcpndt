package in.nic.edistdash.services;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nic.edistdash.entities.PcpndtServiceData;
import in.nic.edistdash.repository.PcpndtFilteredExecDataDao;
import in.nic.edistdash.repository.PcpndtInitiatedataDao;
import in.nic.edistdash.repository.PcpndtServiceDao;

@Service
public class PcpndtService {

	@Autowired
	private PcpndtServiceDao pcpndtserviceDao;

	public List<PcpndtServiceData> getPcpndtserviceDetails() {
		return pcpndtserviceDao.findAll();
	}

	public List<Object> getPcpndtdistrictsDetails() {
		return pcpndtserviceDao.getPcpndtDistrictsDetails();
	}

	public List<Map<String, Object>> getPcpndtAllcountByService() {
		List<Map<String, Object>> result = pcpndtserviceDao.getEnergyAllcountByService();

//			    List<Map<String, Object>> cleanedResult = new ArrayList<>();
//			    
//			    for (Map<String, Object> map : result) {
//			        Map<String, Object> cleanedMap = new LinkedHashMap<>();
//			        
//			        for (Map.Entry<String, Object> entry : map.entrySet()) {
//			            String key = entry.getKey();
//			            Object value = entry.getValue();
		//
//			            if (key == null) {
//			                System.out.println("Null key found in result set: " + map);
//			                continue; // Skip null keys
//			            }
		//
//			            cleanedMap.put(key, value != null ? value : 0); // Replace null values with 0
//			        }
//			        
//			        cleanedResult.add(cleanedMap);
//			    }

		return result;
	}

	@Autowired
	private PcpndtInitiatedataDao pcpndtinitdataDao;

	public List<Map<String, Object>> findMaxMinTimeByServicePcpndt() {

		List<Map<String, Object>> list = null;
		list = pcpndtinitdataDao.findMaxMinTimeByServicePcpndt();
		return list;
	}

	@Autowired
	private PcpndtFilteredExecDataDao pcpndtfilterexecDistdao;

	public List<Map<String, Object>> getPcpndtDistinctCountByservicea(Map<String, Object> requestBody) {

		String serviceIds = (String) requestBody.get("serviceIds");
		List<String> main_lgd = (List<String>) requestBody.get("main_lgd");
		System.out.println(serviceIds);
		System.out.println(main_lgd);
		System.out.println(requestBody.get("serviceIds"));
		/*
		 * List<Object> resultList =
		 * energyofczonedao.getDistinctlgdCodeByserviceandmainZone(main_lgd);
		 * 
		 * 
		 * List<String> mergedList = resultList.stream() .flatMap(obj -> obj instanceof
		 * Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		 * .filter(Objects::nonNull) // Remove null values .map(Object::toString)
		 * .filter(str -> !str.trim().isEmpty()) // Remove empty strings .distinct()
		 * .collect(Collectors.toList());
		 */

		List<Map<String, Object>> applList = pcpndtfilterexecDistdao
				.getPcpndtForwardAndDeliverAndRejectAndPaymentCountByServiceAndDist(main_lgd);

		return applList;

	}

	public List<Map<String, Object>> getcountApplication(Map<String, Object> requestBody) {

		// String serviceIds = (String) requestBody.get("serviceIds");
		List<String> main_lgd = (List<String>) requestBody.get("adist");
		String sstartDate = (String) requestBody.get("startDate");
		String eendDate = (String) requestBody.get("endDate");
		System.out.println(main_lgd);
		System.out.println(sstartDate);
		System.out.println(eendDate);
		String startDate = null;;
		String endDate = null;;
		try {
			SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");

			// Parse the input dates into Date objects
			Date startParsedDate = inputFormat.parse(sstartDate);
			Date endParsedDate = inputFormat.parse(eendDate);

			// Format the Date objects into the desired "DD-MM-YYYY" format
			startDate = outputFormat.format(startParsedDate);
			endDate = outputFormat.format(endParsedDate);

			// Print the result
			System.out.println("Formatted Start Date: " + startDate); // Should print 01-01-2024
			System.out.println("Formatted End Date: " + endDate);
		} catch (Exception e) {
			e.printStackTrace();
		}

		List<Map<String, Object>> applList = pcpndtfilterexecDistdao.getcountApplication(main_lgd, startDate, endDate);

		return applList;

	}

	public List<Map<String, Object>> getpendingOrtpsDataByDistrictId(String id) {
		
		return pcpndtfilterexecDistdao.getpendingOrtpsDataByDistrictId(id);
	}
	
	/*
	 * public List<Map<String, Object>>
	 * getpendingOrtpsDataByDistrictstdtenddtId(Map<String, Object> requestBody) {
	 * 
	 * return pcpndtfilterexecDistdao.getpendingOrtpsDataByDistrictstdtenddtId(id);
	 * }
	 */
	
	public List<Map<String, Object>> getpendingOrtpsDataByDistrictstdtenddtId(Map<String, Object> requestBody) {

		// String serviceIds = (String) requestBody.get("serviceIds");
		String main_lgd = (String) requestBody.get("main_lgd");
		String sstartDate = (String) requestBody.get("startDate");
		String eendDate = (String) requestBody.get("endDate");
		System.out.println(main_lgd);
		System.out.println(sstartDate);
		System.out.println(eendDate);
		String startDate = null;;
		String endDate = null;;
		try {
			SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");

			// Parse the input dates into Date objects
			Date startParsedDate = inputFormat.parse(sstartDate);
			Date endParsedDate = inputFormat.parse(eendDate);

			// Format the Date objects into the desired "DD-MM-YYYY" format
			startDate = outputFormat.format(startParsedDate);
			endDate = outputFormat.format(endParsedDate);

			// Print the result
			System.out.println("Formatted Start Date: " + startDate); // Should print 01-01-2024
			System.out.println("Formatted End Date: " + endDate);
		} catch (Exception e) {
			e.printStackTrace();
		}

		List<Map<String, Object>> applList = pcpndtfilterexecDistdao.getpendingOrtpsDataByDistrictstdtenddtId(main_lgd, startDate, endDate);

		return applList;

	}

	public List<Map<String, Object>> getpendingDataByDistrictstdtenddtId(Map<String, Object> requestBody) {

		// String serviceIds = (String) requestBody.get("serviceIds");
		String main_lgd = (String) requestBody.get("main_lgd");
		String sstartDate = (String) requestBody.get("startDate");
		String eendDate = (String) requestBody.get("endDate");
		System.out.println(main_lgd);
		System.out.println(sstartDate);
		System.out.println(eendDate);
		String startDate = null;;
		String endDate = null;;
		try {
			SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");

			// Parse the input dates into Date objects
			Date startParsedDate = inputFormat.parse(sstartDate);
			Date endParsedDate = inputFormat.parse(eendDate);

			// Format the Date objects into the desired "DD-MM-YYYY" format
			startDate = outputFormat.format(startParsedDate);
			endDate = outputFormat.format(endParsedDate);

			// Print the result
			System.out.println("Formatted Start Date: " + startDate); // Should print 01-01-2024
			System.out.println("Formatted End Date: " + endDate);
		} catch (Exception e) {
			e.printStackTrace();
		}

		List<Map<String, Object>> applList = pcpndtfilterexecDistdao.getpendingDataByDistrictstdtenddtId(main_lgd, startDate, endDate);

		return applList;

	}
	
	public List<Map<String, Object>> getrejectingDataByDistrictstdtenddtId(Map<String, Object> requestBody) {

		// String serviceIds = (String) requestBody.get("serviceIds");
		String main_lgd = (String) requestBody.get("main_lgd");
		String sstartDate = (String) requestBody.get("startDate");
		String eendDate = (String) requestBody.get("endDate");
		System.out.println(main_lgd);
		System.out.println(sstartDate);
		System.out.println(eendDate);
		String startDate = null;;
		String endDate = null;;
		try {
			SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");

			// Parse the input dates into Date objects
			Date startParsedDate = inputFormat.parse(sstartDate);
			Date endParsedDate = inputFormat.parse(eendDate);

			// Format the Date objects into the desired "DD-MM-YYYY" format
			startDate = outputFormat.format(startParsedDate);
			endDate = outputFormat.format(endParsedDate);

			// Print the result
			System.out.println("Formatted Start Date: " + startDate); // Should print 01-01-2024
			System.out.println("Formatted End Date: " + endDate);
		} catch (Exception e) {
			e.printStackTrace();
		}

		List<Map<String, Object>> applList = pcpndtfilterexecDistdao.getrejectingDataByDistrictstdtenddtId(main_lgd, startDate, endDate);

		return applList;

	}
	
	public List<Map<String, Object>> getordelDataByDistrictstdtenddtId(Map<String, Object> requestBody) {

		// String serviceIds = (String) requestBody.get("serviceIds");
		String main_lgd = (String) requestBody.get("main_lgd");
		String sstartDate = (String) requestBody.get("startDate");
		String eendDate = (String) requestBody.get("endDate");
		System.out.println(main_lgd);
		System.out.println(sstartDate);
		System.out.println(eendDate);
		String startDate = null;;
		String endDate = null;;
		try {
			SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");

			// Parse the input dates into Date objects
			Date startParsedDate = inputFormat.parse(sstartDate);
			Date endParsedDate = inputFormat.parse(eendDate);

			// Format the Date objects into the desired "DD-MM-YYYY" format
			startDate = outputFormat.format(startParsedDate);
			endDate = outputFormat.format(endParsedDate);

			// Print the result
			System.out.println("Formatted Start Date: " + startDate); // Should print 01-01-2024
			System.out.println("Formatted End Date: " + endDate);
		} catch (Exception e) {
			e.printStackTrace();
		}

		List<Map<String, Object>> applList = pcpndtfilterexecDistdao.getordelDataByDistrictstdtenddtId(main_lgd, startDate, endDate);

		return applList;

	}
	
	public List<Map<String, Object>> gettapplordelDataByDistrictstdtenddtId(Map<String, Object> requestBody) {

		// String serviceIds = (String) requestBody.get("serviceIds");
		String main_lgd = (String) requestBody.get("main_lgd");
		String sstartDate = (String) requestBody.get("startDate");
		String eendDate = (String) requestBody.get("endDate");
		System.out.println(main_lgd);
		System.out.println(sstartDate);
		System.out.println(eendDate);
		String startDate = null;;
		String endDate = null;;
		try {
			SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");

			// Parse the input dates into Date objects
			Date startParsedDate = inputFormat.parse(sstartDate);
			Date endParsedDate = inputFormat.parse(eendDate);

			// Format the Date objects into the desired "DD-MM-YYYY" format
			startDate = outputFormat.format(startParsedDate);
			endDate = outputFormat.format(endParsedDate);

			// Print the result
			System.out.println("Formatted Start Date: " + startDate); // Should print 01-01-2024
			System.out.println("Formatted End Date: " + endDate);
		} catch (Exception e) {
			e.printStackTrace();
		}

		List<Map<String, Object>> applList = pcpndtfilterexecDistdao.gettapplordelDataByDistrictstdtenddtId(main_lgd, startDate, endDate);

		return applList;

	}
	
	public List<Map<String, Object>> gettotaldeliverByDistrictstdtenddtId(Map<String, Object> requestBody) {

		// String serviceIds = (String) requestBody.get("serviceIds");
		String main_lgd = (String) requestBody.get("main_lgd");
		String sstartDate = (String) requestBody.get("startDate");
		String eendDate = (String) requestBody.get("endDate");
		System.out.println(main_lgd);
		System.out.println(sstartDate);
		System.out.println(eendDate);
		String startDate = null;;
		String endDate = null;;
		try {
			SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");

			// Parse the input dates into Date objects
			Date startParsedDate = inputFormat.parse(sstartDate);
			Date endParsedDate = inputFormat.parse(eendDate);

			// Format the Date objects into the desired "DD-MM-YYYY" format
			startDate = outputFormat.format(startParsedDate);
			endDate = outputFormat.format(endParsedDate);

			// Print the result
			System.out.println("Formatted Start Date: " + startDate); // Should print 01-01-2024
			System.out.println("Formatted End Date: " + endDate);
		} catch (Exception e) {
			e.printStackTrace();
		}

		List<Map<String, Object>> applList = pcpndtfilterexecDistdao.gettotaldeliverByDistrictstdtenddtId(main_lgd, startDate, endDate);

		return applList;

	}
	
	public List<Map<String, Object>> getpendingDataByDistrictId(String id) {
		return pcpndtfilterexecDistdao.getPendingDataByDistrictId(id);
	}

	public List<Map<String, Object>> getrejeingDataByDistrictId(String id) {
		return pcpndtfilterexecDistdao.getrejectDataByDistrictId(id);
	}

	public List<Map<String, Object>> getordelDataByDistrictId(String id) {
		return pcpndtfilterexecDistdao.getordelDataByDistrictId(id);
	}

	public List<Map<String, Object>> gettapplordelDataByDistrictId(String id) {
		return pcpndtfilterexecDistdao.gettapplordelDataByDistrictId(id);
	}

	public List<Map<String, Object>> gettotaldeliverByDistrictId(String id) {
		return pcpndtfilterexecDistdao.gettotaldeliverByDistrictId(id);
	}
}
