package in.nic.edistdash.utils;

public enum Role {

    USER,
    ADMIN
}
