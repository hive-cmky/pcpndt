package in.nic.edistdash.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import in.nic.edistdash.entities.EnergyInitiatedData;

public interface EnergyInitiatedataDao extends JpaRepository<EnergyInitiatedData, String> {

	/*
	 * @Query("SELECT DISTINCT init.routinglocationid, init.routinglocationname from EnergyInitiatedData init WHERE init.serviceid IN :serviceid order by init.routinglocationname"
	 * ) List<Object> getDistinctOfcByservice(@Param("serviceid")List<String>
	 * serviceid);
	 */

	@Query("SELECT DISTINCT eo.office_lgd, eo.office_name " + "FROM EnergyInitiatedData init "
			+ "JOIN EnergyOffice eo ON init.routinglocationid = eo.office_lgd "
			+ "WHERE init.baseservice_id IN :serviceid " + "ORDER BY eo.office_name")
	List<Object> getDistinctOfcByservice(@Param("serviceid") List<String> serviceid);
	
//	@Query("SELECT DISTINCT eo.office_lgd, eo.office_name " + "FROM EnergyInitiatedData init "
//			+ "JOIN EnergyOffice eo ON init.routinglocationid = eo.office_lgd "
//			+ "JOIN EnergyZoneData ez ON eo.office_lgd = ez.zone_lgd "
//			+ "WHERE init.baseservice_id IN :serviceid AND ez.zone_lgd IN :zoneid " + "ORDER BY eo.office_name")
	@Query("SELECT DISTINCT eo.ofc_lgd_code, eo.ofc_office_name " + "FROM EnergyInitiatedData init "
			+ "JOIN EnergyOfcZoneData eo ON init.routinglocationid = eo.child_lgd_code "+  
			 "WHERE init.baseservice_id IN :serviceid AND eo.child_lgd_code IN :zoneid " + "ORDER BY eo.ofc_office_name")
	List<Object> getDistinctOfcByserviceAndZone(@Param("serviceid") List<String> serviceid,@Param("zoneid") List<String> zoneid);
	
	@Query("SELECT DISTINCT eo.grand_lgd_code, eo.grand_office_name " +
		       "FROM EnergyInitiatedData init " +
		       "JOIN EnergyOfcZoneData eo ON init.routinglocationid = eo.grand_lgd_code " +
		       "OR init.routinglocationid = eo.parent_lgd_code " +
		       "OR init.routinglocationid = eo.child_lgd_code " +
		       "OR init.routinglocationid = eo.ofc_lgd_code " +
		       "WHERE init.baseservice_id IN :serviceid AND eo.main_grand_lgd_code IN :zoneid " +
		       "ORDER BY eo.grand_office_name")
	List<Object> getDistinctGrandZoneByserviceAndMainzone(@Param("serviceid") List<String> serviceid,@Param("zoneid") List<String> zoneid);
	
	
	/*
	 * @Query("SELECT DISTINCT eo.main_grand_lgd_code, eo.main_grand_office_name " +
	 * "FROM EnergyInitiatedData init " +
	 * "JOIN EnergyOfcZoneData eo ON init.routinglocationid = eo.main_grand_lgd_code "
	 * + "OR init.routinglocationid = eo.grand_lgd_code " +
	 * "OR init.routinglocationid = eo.parent_lgd_code " +
	 * "OR init.routinglocationid = eo.child_lgd_code " +
	 * "OR init.routinglocationid = eo.ofc_lgd_code " +
	 * "WHERE init.baseservice_id IN :serviceid " +
	 * "ORDER BY eo.main_grand_office_name") List<Object>
	 * getDistinctMainGrandZoneByservice(@Param("serviceid") List<String>
	 * serviceid);
	 */
	@Query("SELECT DISTINCT eo.child_lgd_code, eo.child_office_name " + "FROM EnergyInitiatedData init "
			+ "JOIN EnergyOfcZoneData eo ON init.routinglocationid = eo.child_lgd_code "+
		       "OR init.routinglocationid = eo.ofc_lgd_code " 
			+ "WHERE init.baseservice_id IN :serviceid AND eo.parent_lgd_code IN :parent_lgd " + "ORDER BY eo.child_office_name")
	List<Object> getDistinctChildZoneByserviceAndparentLgd(@Param("serviceid") List<String> serviceid,@Param("parent_lgd") List<String> parent_lgd);
	
	@Query("SELECT DISTINCT eo.parent_lgd_code, eo.parent_office_name " + "FROM EnergyInitiatedData init "
			+ "JOIN EnergyOfcZoneData eo ON init.routinglocationid = eo.parent_lgd_code "+
		       "OR init.routinglocationid = eo.child_lgd_code " +
		       "OR init.routinglocationid = eo.ofc_lgd_code " 
			+ "WHERE init.baseservice_id IN :serviceid AND eo.grand_lgd_code IN :grand_lgd " + "ORDER BY eo.parent_office_name")
	List<Object> getDistinctParentZoneByserviceAndgrandLgd(@Param("serviceid") List<String> serviceid,@Param("grand_lgd") List<String> grand_lgd);

//	@Query(value = "SELECT DISTINCT COALESCE(init.baseservice_id, exec.baseservice_id) AS baseservice_id, COALESCE(init.applicationid, exec.appl_id) AS application_id, init.paymentamount AS initiate_payment_amount, exec.payment_amount AS execution_payment_amount FROM energy_initiate_data init FULL OUTER JOIN energy_execution_data exec ON init.baseservice_id = exec.baseservice_id AND init.applicationid = exec.appl_id WHERE init.paymentamount IS NOT NULL AND exec.payment_amount IS NOT NULL", nativeQuery = true)
//	List<Object> getEnergyPaymentCount();
	 @Query(value = "SELECT DISTINCT COALESCE(init.baseservice_id, exec.baseservice_id) AS baseservice_id, COALESCE(init.applicationid, exec.appl_id) AS application_id, SUM(CAST(init.paymentamount AS DECIMAL)) AS total_initiate_payment_amount, SUM(CAST(exec.payment_amount AS DECIMAL)) AS total_execution_payment_amount FROM energy_initiate_data init FULL OUTER JOIN energy_execution_data exec ON init.baseservice_id = exec.baseservice_id AND init.applicationid = exec.appl_id GROUP BY COALESCE(init.baseservice_id, exec.baseservice_id), COALESCE(init.applicationid, exec.appl_id)", nativeQuery = true)
	    List<Object> getEnergyPaymentCount();
	 
	 @Query(value = "SELECT DISTINCT COALESCE(init.baseservice_id, exec.baseservice_id) AS baseservice_id, " +
             "COALESCE(init.applicationid, exec.appl_id) AS application_id, " +
             "SUM(CAST(init.paymentamount AS DECIMAL)) AS total_initiate_payment_amount, " +
             "SUM(CAST(exec.payment_amount AS DECIMAL)) AS total_execution_payment_amount " +
             "FROM energy_initiate_data init " +
             "FULL OUTER JOIN energy_execution_data exec " +
             "ON init.baseservice_id = exec.baseservice_id " +
             "AND init.applicationid = exec.appl_id " +
             "WHERE COALESCE(init.baseservice_id, exec.baseservice_id) IN :serviceIds " +
             "GROUP BY COALESCE(init.baseservice_id, exec.baseservice_id), " +
             "COALESCE(init.applicationid, exec.appl_id)", nativeQuery = true)
List<Object> getEnergyPaymentCountByservice(@Param("serviceIds") List<String> serviceIds);
	 
	 @Query(value = "SELECT efd.status, COUNT(*) AS status_count FROM energy_initiate_data eid JOIN energy_filtered_execution efd ON eid.baseservice_id = efd.baseservice_id AND eid.applicationid = efd.appl_id WHERE eid.routinglocationid IN :main_lgd AND eid.baseservice_id IN :serviceIds GROUP BY efd.status", nativeQuery = true)
	 List<Object> getEnergyAllCountByserviceAndMainzone(@Param("serviceIds") List<String> serviceIds, @Param("main_lgd") List<String> main_lgd);
	 
	 @Query(value = "SELECT efd.status, COUNT(*) AS status_count FROM energy_initiate_data eid JOIN energy_filtered_execution efd ON eid.baseservice_id = efd.baseservice_id AND eid.applicationid = efd.appl_id WHERE eid.routinglocationid IN :grand_lgd AND eid.baseservice_id IN :serviceIds GROUP BY efd.status", nativeQuery = true)
	 List<Object> getEnergyAllCountByserviceAndGrandzone(@Param("serviceIds") List<String> serviceIds, @Param("grand_lgd") List<String> grand_lgd);
	 
	 @Query(value = "SELECT efd.status, COUNT(*) AS status_count FROM energy_initiate_data eid JOIN energy_filtered_execution efd ON eid.baseservice_id = efd.baseservice_id AND eid.applicationid = efd.appl_id WHERE eid.routinglocationid IN :parent_lgd AND eid.baseservice_id IN :serviceIds GROUP BY efd.status", nativeQuery = true)
	 List<Object> getEnergyAllCountByserviceAndParentzone(@Param("serviceIds") List<String> serviceIds, @Param("parent_lgd") List<String> parent_lgd);

	 @Query(value = "SELECT efd.status, COUNT(*) AS status_count FROM energy_initiate_data eid JOIN energy_filtered_execution efd ON eid.baseservice_id = efd.baseservice_id AND eid.applicationid = efd.appl_id WHERE eid.routinglocationid IN :child_lgd AND eid.baseservice_id IN :serviceIds GROUP BY efd.status", nativeQuery = true)
	 List<Object> getEnergyAllCountByserviceAndChildzone(@Param("serviceIds") List<String> serviceIds, @Param("child_lgd") List<String> child_lgd);
	 
	 @Query(value = "SELECT efd.status, COUNT(*) AS status_count FROM energy_initiate_data eid JOIN energy_filtered_execution efd ON eid.baseservice_id = efd.baseservice_id AND eid.applicationid = efd.appl_id WHERE eid.routinglocationid IN :ofc_lgd AND eid.baseservice_id IN :serviceIds GROUP BY efd.status", nativeQuery = true)
	 List<Object> getEnergyAllCountByserviceAndOfczone(@Param("serviceIds") List<String> serviceIds, @Param("ofc_lgd") List<String> ofc_lgd);
	 
	@Query("SELECT applicationid from EnergyInitiatedData where applicationrefno IN :applicationIds")
	 List<Object> getApplicationByAppRefNO(@Param("applicationIds") List<String> applicationIds);
	
	@Query("SELECT applicationid from EnergyInitiatedData where routinglocationid IN :locationIds")
	 List<Object> getApplicationByLocationid(@Param("locationIds") List<String> locationIds);
	
	@Query("SELECT e FROM EnergyInitiatedData e where e.applicationid IN :applid")
	List<Object>getApplicationByApplicationId(@Param("applid") List<String> applid);
	@Query(value = "WITH diff_calculation AS (SELECT (to_timestamp(e.execution_time, 'DD-MM-YYYY')\\:\\:date - to_timestamp(i.submissiondate, 'DD-MM-YYYY')\\:\\:date) AS diff, i.baseservice_id FROM energy_initiate_data AS i INNER JOIN energy_filtered_execution AS e ON i.applicationid = e.appl_id WHERE e.status IS NOT NULL), status_counts AS (SELECT i.baseservice_id, COUNT(CASE WHEN e.status = 'Deliver' THEN 1 END) AS delivercount, COUNT(CASE WHEN e.status = 'Forward' THEN 1 END) AS forwardcount, COUNT(CASE WHEN e.status = 'Reject' THEN 1 END) AS rejectcount FROM energy_initiate_data AS i INNER JOIN energy_filtered_execution AS e ON i.applicationid = e.appl_id WHERE e.status IS NOT NULL GROUP BY i.baseservice_id) SELECT s.baseservice_id, es.servicename, MAX(d.diff) AS max_diff, MIN(d.diff) AS min_diff, ROUND(AVG(d.diff), 2)\\:\\:double precision AS avg_diff, PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY d.diff) AS median_diff, s.delivercount, s.forwardcount, s.rejectcount FROM status_counts AS s JOIN diff_calculation AS d ON s.baseservice_id = d.baseservice_id JOIN energy_service es ON es.baseservice_id = s.baseservice_id GROUP BY s.baseservice_id, es.servicename, s.delivercount, s.forwardcount, s.rejectcount", nativeQuery = true)
	List<Map<String, Object>> findMaxMinTimeByService();

	 
	 
}
