package in.nic.edistdash.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import in.nic.edistdash.entities.PcpndtOfcZoneData;


public interface PcpndtOfcZoneDao extends JpaRepository<PcpndtOfcZoneData, String> {

	@Query(value="SELECT DISTINCT routinglocationid FROM pcpndt_districtnmlgd where routinglocationid IN :main_lgd",nativeQuery=true)
	 List<Object> getDistinctlgdCodeByserviceandofcZone(@Param("main_lgd") List<String> main_lgd);
}
