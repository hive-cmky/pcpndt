package in.nic.edistdash.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import in.nic.edistdash.datamodel.DistrictModel;
import in.nic.edistdash.entities.EnergyExecuteData;
import in.nic.edistdash.entities.EnergyInitiatedData;
import in.nic.edistdash.entities.EnergyServiceData;
import in.nic.edistdash.services.EnergyService;

@RestController
public class EnergyController {

	@Autowired
	private EnergyService energyservice;
	
    @GetMapping("/getpendingDataByserviceId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getpendingDataByserviceId(@PathVariable String id) {
        return energyservice.getpendingDataByserviceId(id);
    }
    @GetMapping("/getpendingOrtpsDataByserviceId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getpendingOrtpsDataByserviceId(@PathVariable String id) {
        return energyservice.getpendingOrtpsDataByserviceId(id);
    }

    @GetMapping("/getDrawingApprovalDataByserviceId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getDrawingApprovalDataByserviceId(@PathVariable String id) {
        return energyservice.getDrawingApprovalDataByserviceId(id);
    }
    @GetMapping("/getDeliverDrawingApprovalDataByserviceId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getDeliverDrawingApprovalDataByserviceId(@PathVariable String id) {
        return energyservice.getDeliverDrawingApprovalDataByserviceId(id);
    }
    @GetMapping("/getRejectDrawingApprovalDataByserviceId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getRejectDrawingApprovalDataByserviceId(@PathVariable String id) {
        return energyservice.getRejectDrawingApprovalDataByserviceId(id);
    }
    @GetMapping("/getPendingDrawingApprovalDataByserviceId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getPendingDrawingApprovalDataByserviceId(@PathVariable String id) {
        return energyservice.getPendingDrawingApprovalDataByserviceId(id);
    }
    @GetMapping("/getDGsetDataByserviceId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getDGsetDataByserviceId(@PathVariable String id) {
        return energyservice.getDGsetDataByserviceId(id);
    }
    @GetMapping("/getPendingDGsetDataByserviceId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getPendingDGsetDataByserviceId(@PathVariable String id) {
        return energyservice.getPendingDGsetDataByserviceId(id);
    }
    @GetMapping("/getDeliverDGsetDataByserviceId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getDeliverDGsetDataByserviceId(@PathVariable String id) {
        return energyservice.getDeliverDGsetDataByserviceId(id);
    }
    @GetMapping("/getOrtpsDGsetDataByserviceId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getOrtpsDGsetDataByserviceId(@PathVariable String id) {
        return energyservice.getOrtpsDGsetDataByserviceId(id);
    }
    @GetMapping("/getBeyondDeliverDGsetDataByserviceId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getBeyondDeliverDGsetDataByserviceId(@PathVariable String id) {
        return energyservice.getBeyondDeliverDGsetDataByserviceId(id);
    }
    @GetMapping("/getOrtpsDrawingApprovalDataByserviceId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getOrtpsDrawingApprovalDataByserviceId(@PathVariable String id) {
        return energyservice.getOrtpsDrawingApprovalDataByserviceId(id);
    }
    @GetMapping("/getBeyondDeliverDrawingApprovalDataByserviceId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getBeyondDeliverDrawingApprovalDataByserviceId(@PathVariable String id) {
        return energyservice.getBeyondDeliverDrawingApprovalDataByserviceId(id);
    }
    @GetMapping("/getRejectDGsetDataByserviceId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getRejectDGsetDataByserviceId(@PathVariable String id) {
        return energyservice.getRejectDGsetDataByserviceId(id);
    }
	@PostMapping("/getpendingDataByserviceIdAndMainZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingDataByserviceIdAndMainZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingDataByserviceIdAndMainZone(requestBody);
    }

	@PostMapping("/getpendingDataByserviceIdAndGrandZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingDataByserviceIdAndGrandZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingDataByserviceIdAndGrandZone(requestBody);
    }
	@PostMapping("/getpendingDataByserviceIdAndParentZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingDataByserviceIdAndParentZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingDataByserviceIdAndParentZone(requestBody);
    }
	@PostMapping("/getpendingDataByserviceIdAndChildZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingDataByserviceIdAndChildZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingDataByserviceIdAndChildZone(requestBody);
    }
	@PostMapping("/getpendingDataByserviceIdAndOfcZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingDataByserviceIdAndOfcZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingDataByserviceIdAndOfcZone(requestBody);
    }
	@PostMapping("/getpendingOrtpsDataByserviceIdAndMainZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndMainZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingOrtpsDataByserviceIdAndMainZone(requestBody);
    }
	@PostMapping("/getpendingOrtpsDataByserviceIdAndGrandZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndGrandZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingOrtpsDataByserviceIdAndGrandZone(requestBody);
    }
	@PostMapping("/getpendingOrtpsDataByserviceIdAndParentZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndParentZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingOrtpsDataByserviceIdAndParentZone(requestBody);
    }
	@PostMapping("/getPendingTaskDataByUsername")
    @ResponseBody
    public List<Map<String, Object>> getPendingTaskDataByUsername(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getPendingTaskDataByUsername(requestBody);
    }
	@PostMapping("/getPendingOrtpsTaskDataByUsername")
    @ResponseBody
    public List<Map<String, Object>> getPendingOrtpsTaskDataByUsername(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getPendingOrtpsTaskDataByUsername(requestBody);
    }
	@PostMapping("/getpendingTaskDataByserviceIdAndUsernameAndMainZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingTaskDataByserviceIdAndUsernameAndMainZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingTaskDataByserviceIdAndUsernameAndMainZone(requestBody);
    }
	@PostMapping("/getpendingTaskDataByserviceIdAndUsernameAndGrandZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingTaskDataByserviceIdAndUsernameAndGrandZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingTaskDataByserviceIdAndUsernameAndGrandZone(requestBody);
    }
	@PostMapping("/getpendingTaskDataByserviceIdAndUsernameAndParentZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingTaskDataByserviceIdAndUsernameAndParentZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingTaskDataByserviceIdAndUsernameAndParentZone(requestBody);
    }
	@PostMapping("/getpendingTaskDataByserviceIdAndUsernameAndChildZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingTaskDataByserviceIdAndUsernameAndChildZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingTaskDataByserviceIdAndUsernameAndChildZone(requestBody);
    }
	@PostMapping("/getpendingTaskDataByserviceIdAndUsernameAndOfcZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingTaskDataByserviceIdAndUsernameAndOfcZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingTaskDataByserviceIdAndUsernameAndOfcZone(requestBody);
    }
	@PostMapping("/getpendingOrtpsDataByserviceIdAndUsernameAndMainZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndUsernameAndMainZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingOrtpsDataByserviceIdAndUsernameAndMainZone(requestBody);
    }
	@PostMapping("/getpendingOrtpsDataByserviceIdAndUsernameAndGrandZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndUsernameAndGrandZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingOrtpsDataByserviceIdAndUsernameAndGrandZone(requestBody);
    }
	@PostMapping("/getpendingOrtpsDataByserviceIdAndUsernameAndParentZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndUsernameAndParentZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingOrtpsDataByserviceIdAndUsernameAndParentZone(requestBody);
    }
	@PostMapping("/getpendingOrtpsDataByserviceIdAndUsernameAndChildZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndUsernameAndChildZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingOrtpsDataByserviceIdAndUsernameAndChildZone(requestBody);
    }
	@PostMapping("/getpendingOrtpsDataByserviceIdAndUsernameAndOfcZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndUsernameAndOfcZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingOrtpsDataByserviceIdAndUsernameAndOfcZone(requestBody);
    }
	@PostMapping("/getpendingOrtpsDataByserviceIdAndChildZone")
    @ResponseBody
    public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndChildZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getpendingOrtpsDataByserviceIdAndChildZone(requestBody);
    }
	/*
	 * @PostMapping("/getpendingOrtpsDataByserviceIdAndOfcZone")
	 * 
	 * @ResponseBody public List<Map<String, Object>>
	 * getpendingOrtpsDataByserviceIdAndOfcZone(@RequestBody Map<String, Object>
	 * requestBody) { return
	 * energyservice.getpendingOrtpsDataByserviceIdAndOfcZone(requestBody); }
	 */
	
	@GetMapping("/getEnergyserviceDetails")
    @ResponseBody
    public List<Object> getEnergyserviceDetails() {
        return energyservice.getEnergyserviceDetails();
    }
	@GetMapping("/getEnergyAllcountByService")
    @ResponseBody
    public List<Map<String, Object>> getEnergyAllcountByService() {
        return energyservice.getEnergyAllcountByService();
    }
	@GetMapping("/getEnergyRejectCount")
    @ResponseBody
    public List<EnergyExecuteData> getEnergyrejectCount() {
        return energyservice.getEnergyrejectCount();
    }
	
	@GetMapping("/getEnergyForwardCount")
    @ResponseBody
    public List<EnergyExecuteData> getEnergyForwardCount() {
        return energyservice.getEnergyForwardCount();
    }
	
	@GetMapping("/getEnergyDeliverCount")
    @ResponseBody
    public List<EnergyExecuteData> getEnergyDeliverCount() {
        return energyservice.getEnergyDeliverCount();
    }
	
	@GetMapping("/getEnergyForwardAndDeliverAndRejectCount")
    @ResponseBody
    public List<Object> getEnergyForwardAndDeliverAndRejectCount() {
        return energyservice.getEnergyForwardAndDeliverAndRejectCount();
    }
	@PostMapping("/findApplication")
    @ResponseBody
    public Map<String, Object> findApplication(@RequestBody Map<String, Object> requestBody) {
        return energyservice.findApplication(requestBody);
    }
	@GetMapping("/findMaxMinTimeByService")
    @ResponseBody
    public List<Map<String, Object>> findMaxMinTimeByService() {
        return energyservice.findMaxMinTimeByService();
    }
	@PostMapping("/getMaxMinCountByServiceAndMainzone")
    @ResponseBody
    public List<Map<String, Object>> getMaxMinCountByServiceAndLgd(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getMaxMinCountByServiceAndLgd(requestBody);
    }
	@PostMapping("/getMaxMinCountByServiceAndGrandzone")
    @ResponseBody
    public List<Map<String, Object>> getMaxMinCountByServiceAndgrandZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getMaxMinCountByServiceAndgrandZone(requestBody);
    }
	@PostMapping("/getMaxMinCountByServiceAndParentzone")
    @ResponseBody
    public List<Map<String, Object>> getMaxMinCountByServiceAndparentZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getMaxMinCountByServiceAndparentZone(requestBody);
    }
	@PostMapping("/getMaxMinCountByServiceAndChildzone")
    @ResponseBody
    public List<Map<String, Object>> getMaxMinCountByServiceAndchildZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getMaxMinCountByServiceAndchildZone(requestBody);
    }
	@PostMapping("/getMaxMinCountByServiceAndOfczone")
    @ResponseBody
    public List<Map<String, Object>> getMaxMinCountByServiceAndofcZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getMaxMinCountByServiceAndofcZone(requestBody);
    }
	
	@PostMapping("/getEnergyForwardAndDeliverAndRejectCountByService")
    @ResponseBody
    public List<Object> getEnergyForwardAndDeliverAndRejectCountByService(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getEnergyForwardAndDeliverAndRejectCountByService(requestBody);
    }
	
	@PostMapping("/getDistinctOfcByservice")
    @ResponseBody
    public List<Object> getDistinctOfcByservice(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getDistinctOfcByservice(requestBody);
    }
	@PostMapping("/getDistinctParentZoneByserviceAndgrandLgd")
    @ResponseBody
    public List<Object> getDistinctParentZoneByserviceAndgrandLgd(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getDistinctParentZoneByserviceAndgrandLgd(requestBody);
    }
	@PostMapping("/getDistinctChildZoneByserviceAndparentLgd")
    @ResponseBody
    public List<Object> getDistinctChildZoneByserviceAndparentLgd(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getDistinctChildZoneByserviceAndparentLgd(requestBody);
    }
	@PostMapping("/getDistinctGrandZoneByserviceAndMainzone")
    @ResponseBody
    public List<Object> getDistinctGrandZoneByserviceAndMainzone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getDistinctGrandZoneByserviceAndMainzone(requestBody);
    }
	
	/*
	 * @PostMapping("/getDistinctMainGrandZoneByservice")
	 * 
	 * @ResponseBody public List<Object>
	 * getDistinctMainGrandZoneByservice(@RequestBody Map<String, Object>
	 * requestBody) { return
	 * energyservice.getDistinctMainGrandZoneByservice(requestBody); }
	 */
	
	@PostMapping("/getDistinctOfcByserviceAndZone")
    @ResponseBody
    public List<Object> getDistinctOfcByserviceAndZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getDistinctOfcByserviceAndZone(requestBody);
    }
	@PostMapping("/getEnergyAllCountByserviceAndMainzone")
    @ResponseBody
    public List<Object> getEnergyAllCountByserviceAndMainzone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getEnergyAllCountByserviceAndMainzone(requestBody);
    }
	@PostMapping("/getDistinctCountByserviceandmainZone")
    @ResponseBody
    public List<Map<String, Object>> getDistinctCountByserviceandmainZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getDistinctCountByserviceandmainZone(requestBody);
    }
	@PostMapping("/getDistinctCountByserviceandgrandZone")
    @ResponseBody
    public List<Map<String, Object>> getDistinctCountByserviceandgrandZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getDistinctCountByserviceandgrandZone(requestBody);
    }
	@PostMapping("/getDistinctCountByserviceandparentZone")
    @ResponseBody
    public List<Map<String, Object>> getDistinctCountByserviceandparentZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getDistinctCountByserviceandparentZone(requestBody);
    }
	@PostMapping("/getDistinctCountByserviceandchildZone")
    @ResponseBody
    public List<Map<String, Object>> getDistinctCountByserviceandchildZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getDistinctCountByserviceandchildZone(requestBody);
    }
	@PostMapping("/getDistinctCountByserviceandofcZone")
    @ResponseBody
    public List<Map<String, Object>> getDistinctCountByserviceandofcZone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getDistinctCountByserviceandofcZone(requestBody);
    }
	@PostMapping("/getEnergyAllCountByserviceAndGrandzone")
    @ResponseBody
    public List<Object> getEnergyAllCountByserviceAndGrandzone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getEnergyAllCountByserviceAndGrandzone(requestBody);
    }
	@PostMapping("/getEnergyAllCountByserviceAndParentzone")
    @ResponseBody
    public List<Object> getEnergyAllCountByserviceAndParentzone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getEnergyAllCountByserviceAndParentzone(requestBody);
    }
	@PostMapping("/getEnergyAllCountByserviceAndChildzone")
    @ResponseBody
    public List<Object> getEnergyAllCountByserviceAndChildzone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getEnergyAllCountByserviceAndChildzone(requestBody);
    }
	@PostMapping("/getEnergyAllCountByserviceAndOfczone")
    @ResponseBody
    public List<Object> getEnergyAllCountByserviceAndOfczone(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getEnergyAllCountByserviceAndOfczone(requestBody);
    }
	@GetMapping("/getEnergyPaymentCount")
    @ResponseBody
    public List<Object> getEnergyPaymentCount() {
        return energyservice.getEnergyPaymentCount();
    }
	@PostMapping("/getEnergyPaymentCountByservice")
    @ResponseBody
    public List<Object> getEnergyPaymentCountByservice(@RequestBody Map<String, Object> requestBody) {
        return energyservice.getEnergyPaymentCountByservice(requestBody);
    }
}
