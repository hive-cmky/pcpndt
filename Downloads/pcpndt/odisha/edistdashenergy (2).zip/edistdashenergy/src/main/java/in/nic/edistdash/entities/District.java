package in.nic.edistdash.entities;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class District {
    @Id
    private Integer distadmin;

    private String distname;

    private String distlgd;

    private String rdclgd;

}
