package in.nic.edistdash.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import in.nic.edistdash.entities.EnergyServiceData;


public interface EnergyServiceDao extends JpaRepository<EnergyServiceData, String>{

    @Query("SELECT DISTINCT e.baseservice_id,e.servicename FROM EnergyServiceData e")
	//@Query("select distinct baseservice_id from EnergyServiceData")
	List<Object>getEnergyserviceDetails();
    @Query(value="SELECT es.baseservice_id AS serviceId, es.servicename AS service, COUNT(DISTINCT efd.appl_id) AS total_applications, COUNT(DISTINCT CASE WHEN efd.status = 'Deliver' THEN efd.appl_id END) AS delivercount, COUNT(DISTINCT CASE WHEN efd.status = 'Forward' THEN efd.appl_id END) AS forwardcount, COUNT(DISTINCT CASE WHEN efd.status = 'Reject' THEN efd.appl_id END) AS rejectcount, COUNT(DISTINCT CASE WHEN efd.status IN ('Deliver', 'Forward', 'Reject') THEN efd.appl_id END) AS appliedcount, (SUM(COALESCE(CAST(a.paymentamount AS NUMERIC), 0)) + SUM(COALESCE(CAST(efd.payment_amount AS NUMERIC), 0))) AS total_payment_amount, COUNT(DISTINCT CASE WHEN (efd.status = 'Forward' AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS')) THEN efd.appl_id END) AS ortpscount,COUNT(DISTINCT CASE WHEN (efd.status = 'Deliver' AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS')) THEN efd.appl_id END) AS ortpsdelivercount, CASE WHEN COUNT(DISTINCT CASE WHEN efd.status = 'Forward' THEN efd.appl_id END) > 0 AND COUNT(DISTINCT CASE WHEN (efd.status = 'Forward' AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS')) THEN efd.appl_id END) > 0 THEN ROUND(COUNT(DISTINCT CASE WHEN (efd.status = 'Forward' AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS')) THEN efd.appl_id END) * 100.0 / COUNT(DISTINCT CASE WHEN efd.status = 'Forward' THEN efd.appl_id END), 2) ELSE 0.0 END AS ortps_percentage FROM (SELECT DISTINCT ON (appl_id) * FROM energy_filtered_execution ORDER BY appl_id) efd JOIN energy_initiate_data a ON a.applicationid = efd.appl_id JOIN energy_service es ON es.baseservice_id = efd.baseservice_id GROUP BY es.baseservice_id, es.servicename ORDER BY total_applications DESC",nativeQuery=true)
    List<Map<String, Object>>getEnergyAllcountByService();
}
