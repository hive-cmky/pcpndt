package in.nic.edistdash.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "energy_zone_data")
public class EnergyZoneData {
	 @Id  
		private String sl_no;
		 private String zone_name;
	    private String zone_lgd;
	    private String office_name;
	    private String office_lgd_code;
	    private String office_type;
	    private String user_id;
	    private String user_name;
}
