package in.nic.edistdash.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.nic.edistdash.entities.auth.UserInfo;


public interface UserInfoDao extends JpaRepository<UserInfo, Long>{

//	UserInfo findByUsrId(long id);
//
//	List<UserInfo> findAllByDistrict(District district);
//
//	List<UserInfo> findAllByDepartmentAndDistrict(Department department, District district);
//
//	List<UserInfo> findAllByDepartment(Department department);
//
//	List<UserInfo> findAllByOfficeId(Long id);
}
