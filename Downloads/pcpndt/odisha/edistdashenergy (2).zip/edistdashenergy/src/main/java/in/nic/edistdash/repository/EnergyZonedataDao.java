package in.nic.edistdash.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import in.nic.edistdash.entities.EnergyZoneData;

public interface EnergyZonedataDao extends JpaRepository<EnergyZoneData, String> {

}
