package in.nic.edistdash.repository;

public interface PendingDataProjection {
	
	String getUserName();
    String getTaskName();
    Long getCount();

}
