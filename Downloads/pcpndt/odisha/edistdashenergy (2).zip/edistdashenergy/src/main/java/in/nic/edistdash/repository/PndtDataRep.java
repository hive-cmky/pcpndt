package in.nic.edistdash.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import in.nic.edistdash.entities.PndtData;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.parameters.P;

public interface PndtDataRep extends JpaRepository<PndtData, Long> {

	@Query("SELECT pnd FROM PndtData pnd WHERE pnd.status = 'Under Process'")

	List<PndtData> findPendingPndData();

	@Query("SELECT COUNT(*) FROM PndtData pnd WHERE pnd.status = 'Under Process' ")
	Object countPendingPndData();

	@Query("SELECT pnd FROM PndtData pnd WHERE pnd.status = 'Rejected'")
	List<PndtData> findRejectPndData();

	@Query("SELECT COUNT(*) FROM PndtData pnd WHERE pnd.status = 'Rejected' ")
	Object countRejectPndData();

	@Query("SELECT pnd FROM PndtData pnd WHERE pnd.status = 'Delivered'")
	List<PndtData> findApprovedPndData();

	@Query("SELECT COUNT(*) FROM PndtData pnd WHERE pnd.status = 'Delivered' ")
	Object countApprovedPndData();

	// Shaswat starts

	@Query("SELECT pnd FROM PndtData pnd WHERE pnd.appl_type = 'Renewal'")
	List<PndtData> findRenewalPndData();

	@Query("SELECT COUNT(*) FROM PndtData pnd where pnd.appl_type = 'Renewal'")
	Object countRenewalPndData();

	@Query("SELECT pnd FROM PndtData pnd WHERE pnd.appl_type = 'New Registration'")
	List<PndtData> findNewRegistrationPndData();

	@Query("SELECT COUNT(*) FROM PndtData pnd where pnd.appl_type = 'New Registration'")
	Object countNewRegistrationPndData();

	@Query("SELECT pnd FROM PndtData pnd WHERE pnd.appl_type = 'Fresh Application'")
	List<PndtData> findFreshApplicationPndData();

	@Query("SELECT COUNT(*) FROM PndtData pnd where pnd.appl_type = 'Fresh Application'")
	Object countFreshApplicationPndData();

	@Query("SELECT pnd FROM PndtData pnd WHERE pnd.appl_type = 'Re- Apply'")
	List<PndtData> findReapplyPndData();

	@Query("SELECT COUNT(*) FROM PndtData pnd where pnd.appl_type = 'Re- Apply'")
	Object countReapplyPndData();

	@Query("SELECT pnd FROM PndtData pnd WHERE pnd.appl_type = 'Applied (Form B to be Issued)'")
	List<PndtData> findapplyFormBPndData();

	@Query("SELECT COUNT(*) FROM PndtData pnd where pnd.appl_type = 'Applied (Form B to be Issued)'")
	Object countapplyFormBPndData();

	@Query("SELECT pnd FROM PndtData pnd WHERE pnd.appl_type = 'Registered (Form B Issued )'")
	List<PndtData> findRegisterPndData();

	@Query("SELECT COUNT(*) FROM PndtData pnd where pnd.appl_type = 'Registered (Form B Issued )'")
	Object countRegisterPndData();

	@Query(value = "select district, distadmin, status, count(status) as count from pndt group by district, distadmin, status order by district;" , nativeQuery = true)
	List<Map<String, Object>> findStatusDistrictWise();

	@Query(value = "select district, distadmin, status, count(status) as count from pndt where status = 'Delivered' group by district, distadmin, status order by district;" , nativeQuery = true)
	List<Map<String, Object>> findStatusDeliveredDistrictWise();

	@Query(value = "select district, distadmin, status, count(status) as count from pndt where status = 'Under Process' group by district, distadmin, status order by district;" , nativeQuery = true)
	List<Map<String, Object>> findStatusUnderProcessDistrictWise();

	@Query(value = "select district, distadmin, status, count(status) as count from pndt where status = 'Rejected' group by district, distadmin, status order by district;" , nativeQuery = true)
	List<Map<String, Object>> findStatusRejectedDistrictWise();

	//TotalStatusWIse
	@Query(value = "\n" +
			"select a.district, a.distadmin, count(a.district) as totalapplied,b.countrjct,c.countDel,d.countPen from pndt a" +
			" left join (select district, count(district) as countrjct from pndt where status = 'Rejected' group by district) b on a.district = b.district" +
			" left join (select district, count(district) as countDel from pndt where status = 'Delivered' group by district) c on a.district = c.district" +
			" left join (select district, count(district) as countPen from pndt where status = 'Under Process' group by district) d on a.district = d.district" +
			" group by a.district, a.distadmin, b.countrjct, c.countDel, d.countPen order by a.district;", nativeQuery = true)
	List<Map<String, Object>> countTotalAppliedRejectedPendingApproved();

	@Query(value = "select a.district, a.distadmin, count(a.district) as totalapplied, c.countDel from pndt a" +
			" left join (select district, count(district) as countDel from pndt where status = 'Delivered' group by district) c on a.district = c.district" +
			" group by a.district, a.distadmin, c.countDel order by a.district", nativeQuery = true)
	List<Map<String, Object>> countApprovedByDistrictWise();

	@Query(value = "select a.district, a.distadmin, count(a.district) as totalapplied, c.countPen from pndt a" +
			" left join (select district, count(district) as countPen from pndt where status = 'Under Process' group by district) c on a.district = c.district" +
			" group by a.district, a.distadmin, c.countPen order by a.district", nativeQuery = true)
	List<Map<String, Object>>counUnderProcessByDistrictWise();

	@Query(value = "select a.district, a.distadmin, count(a.district) as totalapplied, c.countReject from pndt a" +
			" left join (select district, count(district) as countReject from pndt where status = 'Rejected' group by district) c on a.district = c.district" +
			" group by a.district, a.distadmin, c.countReject order by a.district", nativeQuery = true)
	List<Map<String, Object>>countrjctbydistrictwise();


//By Using distadmin we can get the district by status list of type(Under Process, Rejected and Delivered)
	@Query("SELECT pnd FROM PndtData pnd WHERE pnd.status = 'Delivered' and pnd.distadmin = :distadmin")
	List<PndtData> findTotalapplieddistrict(@Param("distadmin") int distadmin);

	@Query("SELECT pnd FROM PndtData pnd WHERE pnd.status = 'Under Process' and pnd.distadmin = :distadmin")
	List<PndtData> findTotalPendbyDistrict(@Param("distadmin") int distadmin);

	@Query("SELECT pnd FROM PndtData pnd WHERE pnd.status = 'Rejected' and pnd.distadmin = :distadmin")
	List<PndtData> findRejectPndData(@Param("distadmin") int distadmin);

	@Query("SELECT pnd FROM PndtData pnd WHERE pnd.distadmin = :distadmin")
	List<PndtData> findAppliedList(@Param("distadmin") int distadmin);

}
