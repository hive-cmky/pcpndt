package in.nic.edistdash.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import in.nic.edistdash.entities.PcpndtServiceData;
import in.nic.edistdash.services.PcpndtService;

@RestController
public class PcpndtController {

	
	@Autowired
	private PcpndtService pcndtservice;
	
	@GetMapping("/getPcpndtserviceDetails")
    @ResponseBody
    public List<PcpndtServiceData> getPcpndtserviceDetails() {
        return pcndtservice.getPcpndtserviceDetails();
    }
	
	@GetMapping("/getPcpndtAllcountByService")
    @ResponseBody
    public List<Map<String, Object>> getPcpndtAllcountByService() {
        return pcndtservice.getPcpndtAllcountByService();
    }
	
	@GetMapping("/getPcpndtDistrictDetails")
    @ResponseBody
    public List<Object> getPcpndtDistrictDetails() {
        return pcndtservice.getPcpndtdistrictsDetails();
    }
	
	@GetMapping("/findMaxMinTimeByServicePcpndt")
    @ResponseBody
    public List<Map<String, Object>> findMaxMinTimeByServicePcpndt() {
        return pcndtservice.findMaxMinTimeByServicePcpndt();
    }
	
	@PostMapping("/getPcpndtDistinctCountByservicea")
    @ResponseBody
    public List<Map<String, Object>> getPcpndtDistinctCountByservicea(@RequestBody Map<String, Object> requestBody) {
        return pcndtservice.getPcpndtDistinctCountByservicea(requestBody);
    }
	
	@PostMapping("/getcountApplication")
    @ResponseBody
    public List<Map<String, Object>> getcountApplication(@RequestBody Map<String, Object> requestBody) {
        return pcndtservice.getcountApplication(requestBody);
    }
	
	
	
	
	  @GetMapping("/getpendingOrtpsDataByDistrictId/{id}")
	  @ResponseBody public List<Map<String, Object>>
	  getpendingOrtpsDataByDistrictId(@PathVariable String id) { return
	  pcndtservice.getpendingOrtpsDataByDistrictId(id); }
	  
	/*
	 * @GetMapping("/getpendingOrtpsDataByDistrictstdtenddtId/{id}")
	 * 
	 * @ResponseBody public List<Map<String, Object>>
	 * getpendingOrtpsDataByDistrictstdtenddtId(@PathVariable String id) { return
	 * pcndtservice.getpendingOrtpsDataByDistrictId(id); }
	 */
	  
	  @PostMapping("/getpendingOrtpsDataByDistrictstdtenddtId")
	  @ResponseBody
	  public List<Map<String, Object>> getpendingOrtpsDataByDistrictstdtenddtId(@RequestBody Map<String, Object> requestBody) {
	        return pcndtservice.getpendingOrtpsDataByDistrictstdtenddtId(requestBody);
	  }
	 
	  @PostMapping("/getpendingDataByDistrictstdtenddtId")
	  @ResponseBody
	  public List<Map<String, Object>> getpendingDataByDistrictstdtenddtId(@RequestBody Map<String, Object> requestBody) {
	        return pcndtservice.getpendingDataByDistrictstdtenddtId(requestBody);
	  }
	  
	  @PostMapping("/getrejectingDataByDistrictstdtenddtId")
	  @ResponseBody
	  public List<Map<String, Object>> getrejectingDataByDistrictstdtenddtId(@RequestBody Map<String, Object> requestBody) {
	        return pcndtservice.getrejectingDataByDistrictstdtenddtId(requestBody);
	  }
	  
	  @PostMapping("/gettotaldeliverByDistrictstdtenddtId")
	  @ResponseBody
	  public List<Map<String, Object>> gettotaldeliverByDistrictstdtenddtId(@RequestBody Map<String, Object> requestBody) {
	        return pcndtservice.gettotaldeliverByDistrictstdtenddtId(requestBody);
	  }
	  
	  @PostMapping("/gettapplordelDataByDistrictstdtenddtId")
	  @ResponseBody
	  public List<Map<String, Object>> gettapplordelDataByDistrictstdtenddtId(@RequestBody Map<String, Object> requestBody) {
	        return pcndtservice.gettapplordelDataByDistrictstdtenddtId(requestBody);
	  }
	  
	  @PostMapping("/getordelDataByDistrictstdtenddtId")
	  @ResponseBody
	  public List<Map<String, Object>> getordelDataByDistrictstdtenddtId(@RequestBody Map<String, Object> requestBody) {
	        return pcndtservice.getordelDataByDistrictstdtenddtId(requestBody);
	  }
	  
	  @GetMapping("/getpendingDataByDistrictId/{id}")
	  public List<Map<String, Object>> getPendingDataByDistrictId(@PathVariable String id) {
		    return pcndtservice.getpendingDataByDistrictId(id);
		    
		}
	 
	
	@GetMapping("/getrejectingDataByDistrictId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getrejectingDataByDistrictId(@PathVariable String id) {
        return pcndtservice.getrejeingDataByDistrictId(id);
    }
	
	@GetMapping("/getordelDataByDistrictId/{id}")
    @ResponseBody
    public List<Map<String, Object>> getordelDataByDistrictId(@PathVariable String id) {
        return pcndtservice.getordelDataByDistrictId(id);
    }
	
	@GetMapping("/gettapplordelDataByDistrictId/{id}")
    @ResponseBody
    public List<Map<String, Object>> gettapplordelDataByDistrictId(@PathVariable String id) {
        return pcndtservice.gettapplordelDataByDistrictId(id);
    }
	
	@GetMapping("/gettotaldeliverByDistrictId/{id}")
    @ResponseBody
    public List<Map<String, Object>> gettotaldeliverByDistrictId(@PathVariable String id) {
        return pcndtservice.gettotaldeliverByDistrictId(id);
    }
	
}
