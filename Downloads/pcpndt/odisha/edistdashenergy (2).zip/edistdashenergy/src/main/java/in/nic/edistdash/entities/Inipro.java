package in.nic.edistdash.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "inipro")
public class Inipro {

    @Id
    private String application_id;

    private String applicationref;
    private String serviceid;
    private String servicename;
    private String district;
    private String tehasil;
    private String submimonth;
    private String submiyear;
    private String submissiondate;
    private String duedate;
    private String districtlgd;
    private String tehasillgd;
}
