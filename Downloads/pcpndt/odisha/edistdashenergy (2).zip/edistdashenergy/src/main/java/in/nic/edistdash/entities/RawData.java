package in.nic.edistdash.entities;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;


import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
public class RawData {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    private long id;
    @Column(columnDefinition = "TEXT")
    private String userData;

    @Column(columnDefinition = "boolean default false")
    private boolean isProcessed;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date creation;

    public RawData(String sometext) {
        userData = sometext;
    }
}
