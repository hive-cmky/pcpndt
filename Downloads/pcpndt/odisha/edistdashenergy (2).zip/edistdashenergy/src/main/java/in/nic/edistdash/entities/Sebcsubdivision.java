package in.nic.edistdash.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Sebcsubdivision {

	
	private String district;
	private String subdivision;
	private String tehasil;
	@Id
	private String applrefno;
	private String applname;
	private String mobileno;
	private String age;
	private String gender;
	private String caste;
	private String subcaste;
	private String status;
	private String submission;

}
