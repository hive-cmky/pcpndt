package in.nic.edistdash.controller;

import in.nic.edistdash.datamodel.*;
import in.nic.edistdash.entities.Inipro;
import in.nic.edistdash.entities.PndtData;
import in.nic.edistdash.services.RevenueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

@RestController
public class RevenueController {

    @Autowired
    private RevenueService revenueService;

    @GetMapping("/getalldistrictlist")
    @ResponseBody
    public List<DistrictModel> distlist() {
        return revenueService.finddistrict();
    }

    @GetMapping("/getservicelist")
    @ResponseBody
    public List<ServiceModel> servicelist() {
        return revenueService.findservice();
    }

    @GetMapping("/getservicenamebystatuscount")
    @ResponseBody
    public List<ServiceNameModel> servicenamebystatuscount() {
        return revenueService.findservicenamecout();
    }

    @PostMapping("/getcountbyStartDate")
    @ResponseBody
    public List<ServiceNameModel> findcountbyStartDate(@RequestBody Map<String, Object> requestBody) throws ParseException {
        return revenueService.findcountbyStartDate(requestBody);
    }

    @PostMapping("/findcountByserviceId")
    @ResponseBody
    public List<ServiceNameModel> findcountByserviceId(@RequestBody Map<String, Object> requestBody) {
        return revenueService.findcountByserviceId(requestBody);
    }

    @PostMapping("/findtopperformercountbyStartDate")
    @ResponseBody
    public List<percentageModel> findtopperformercountbyStartDate(@RequestBody Map<String, Object> requestBody) throws ParseException {
        return revenueService.findtopperformercountbyStartdate(requestBody);
    }

    @PostMapping("/findtopperformercountbyserviceid")
    @ResponseBody
    public List<percentageModel> findtopperformercountbyserviceid(@RequestBody Map<String, Object> requestBody) {
        return revenueService.findtopperformercountbyserviceid(requestBody);
    }

    @PostMapping("/findtopperformerbyserviceIdandDistrict")
    @ResponseBody
    public List<percentageModel> findtopperformerbyserviceIdanddistrict(@RequestBody Map<String, Object> requestBody){
        return revenueService.topperformerbyServiceIdAndDistrict(requestBody);
    }

    @PostMapping("/findBottomperformerbyserviceId")
    @ResponseBody
    public List<percentageModel> findBottomperformerbyserviceId(@RequestBody Map<String, Object> requestBody) {
        return revenueService.findBottomperformerbyserviceId(requestBody);
    }

    @PostMapping("/findBottomperformerbyserviceIdanddistrict")
    @ResponseBody
    public List<percentageModel> BottomperformerbyserviceIdanddistrict(@RequestBody Map<String, Object> requestBody){
        return revenueService.BottomperformerbyserviceIdanddistrict(requestBody);
    }
    @PostMapping("/findcountByserviceIdAndDistrict")
    @ResponseBody
    public List<ServiceNameModel> findcountByserviceIdAndDistrict(@RequestBody Map<String, Object> requestBody) {
        return revenueService.findcountByserviceIdAndDistrict(requestBody);
    }

    @PostMapping("/districtlist")
    @ResponseBody
    public List<Object> getDistrictlist(@RequestBody Map<String, Object> requestBody) {
        return revenueService.getDistrictlist(requestBody);
    }

    @GetMapping("/findapplicationstatuscountbydistrictwise")
    @ResponseBody
    public List<DistrictStatusModel> applicationstatuscountbydistrictwise() {
        return revenueService.getapplicationstatusbydistrictwisecount();
    }
    @GetMapping("/findapplicationstatuscountbytehasilwise")
    @ResponseBody
    public List<DistrictStatusModel> applicationstatuscountbytehasilwise() {
        return revenueService.getapplicationstatusbytehasilwisecount();
    }
    
    @GetMapping("/getCountDeliverData")
    @ResponseBody
    public Object getCountDeliverData() {
        return revenueService.getCountDeliverData();
    }

    @GetMapping("/getCountForwardData")
    @ResponseBody
    public Object getCountForwardData() {
        return revenueService.getCountForwardData();
    }

    @GetMapping("/getCountRejectData")
    @ResponseBody
    public Object getCountRejectData() {
        return revenueService.getCountRejectData();
    }

    @GetMapping("/getyearwisecount")
    @ResponseBody
    public List<YearWiseStatusModel> findyearwisestatuscount() {
        return revenueService.findyearwisestatuscount();
    }

    @GetMapping("/findaggregatefunc")
    @ResponseBody
    public List<AggregateFuncModel> findaggregatefuncvalue() {
        return revenueService.findaggregatefuncvalue();
    }

    @GetMapping("/gettopperformerbydistrictwise")
    @ResponseBody
    public List<percentageModel> finddistrictwisetopperformercount() {
        return revenueService.findtopperformercountbydistrictwise();
    }


    @GetMapping("/getbottomformerbydistrictwise")
    @ResponseBody
    public List<percentageModel> finddistrictwisebottomformercount() {
        return revenueService.findbottomperformercountbydistrict();
    }

    @GetMapping("/gettopPerformerByTehasil")
    @ResponseBody
    public List<percentageModel> topPerformerByTehasil() {
        return revenueService.topPerformerByTehasil();
    }

    @PostMapping("/getTopPerformerbyTehasilbyStartDate")
    @ResponseBody
    public List<percentageModel> findTopPerformerbyTehasilbyStartDate(@RequestBody Map<String, Object> requestBody) throws ParseException {
        return revenueService.TopPerformerbyTehasilbyStartDate(requestBody);
    }

    @PostMapping("/getTopPerformerbyTehasilbyServiceId")
    @ResponseBody
    public List<percentageModel> findTopPerformerbyTehasilbyServiceId(@RequestBody Map<String, Object> requestBody) {
        return revenueService.TopPerformerbyTehasilbyServiceId(requestBody);
    }

    @PostMapping("/getTopPerformerbyTehasilbyServiceIdandDistrict")
    @ResponseBody
    public List<percentageModel> findTopPerformerbyTehasilbyServiceIdandDistrict(@RequestBody Map<String, Object> requestBody) {
        return revenueService.TopPerformerbyTehasilbyserviceIdandDistrict(requestBody);
    }

    @GetMapping("/getBottomPerformerByTehasil")
    @ResponseBody
    public List<percentageModel> BottomPerformerByTehasil() {
        return revenueService.BottomPerformerByTehasil();
    }

    @PostMapping("/getBottomPerformerbyTehasilbyServiceId")
    @ResponseBody
    public List<percentageModel> findBottomPerformerbyTehasilbyServiceId(@RequestBody Map<String, Object> requestBody) {
        return revenueService.BottomPerformerbyTehasilbyServiceId(requestBody);
    }

    @PostMapping("/findBottomPerformerbyTehasilbyServiceIdandDistrict")
    @ResponseBody
    public List<percentageModel> findBottomPerformerbyTehasilbyServiceIdandDistrict(@RequestBody Map<String, Object> requestBody) {
        return revenueService.BottomPerformerbyTehasilbyServiceIdandDistrict(requestBody);
    }

    @GetMapping("/getstatuscountbydistrictwise")
    @ResponseBody
    public List<DistrictStatusCountModel> finddistrictwisestatuscount() {
        return revenueService.finddistrictwisecountstatus();
    }

    @GetMapping("/getalltimetakenvalue")
    @ResponseBody
    public Object findalltimetakenvalue() {
        return revenueService.getalltimetakenvalue();
    }

    @PostMapping("/getalltimetakenvaluebyStartdate")
    @ResponseBody
    public Object findalltimetakenvaluebyStartdate(@RequestBody Map<String, Object> requestBody) throws ParseException {
        return revenueService.getalltimetakenvaluebyStartdate(requestBody);
    }

    @PostMapping("/getalltimetakenvaluebyServiceId")
    @ResponseBody
    public Object findalltimetakenvaluebyServiceId(@RequestBody Map<String, Object> requestBody) {
        return revenueService.getalltimetakenvaluebyServiceid(requestBody);
    }

    @PostMapping("/getalltimetakenvaluebyServiceIdandDistrict")
    @ResponseBody
    public Object findalltimetakenvaluebyServiceIdandDistrict(@RequestBody Map<String, Object> requestBody){
        return revenueService.getalltimetakenvaluebyServiceidanddistrict(requestBody);
    }

    @PostMapping("/getortpscountbyStartDate")
    @ResponseBody
    public List<DistrictStatusModel> findortpscountbyStartDate(@RequestBody Map<String, Object> requestBody) throws ParseException {
        return revenueService.findortpscountbystartdate(requestBody);
    }

    @PostMapping("/findortpscountbyserviceId")
    @ResponseBody
    public List<DistrictStatusModel> findortpscountbyserviceId(@RequestBody Map<String, Object> requestBody) {
        return revenueService.findortpscountbyserviceId(requestBody);
    }
    @PostMapping("/findortpsTehasilcountbyserviceId")
    @ResponseBody
    public List<DistrictStatusModel> findortpsTehasilcountbyserviceId(@RequestBody Map<String, Object> requestBody) {
        return revenueService.findortpsTehasilcountbyserviceId(requestBody);
    }

    @PostMapping("/getOrtpscountbyServiceIdandDistrict")
    @ResponseBody
    public List<DistrictStatusModel> findOrtpscountbyServiceIdandDistrict(@RequestBody Map<String, Object> requestBody){
        return revenueService.findOrtpscountbyServiceIdandDistrict(requestBody);
    }
    @PostMapping("/getOrtpsTehasilcountbyServiceIdandDistrict")
    @ResponseBody
    public List<DistrictStatusModel> findOrtpsTehasilcountbyServiceIdandDistrict(@RequestBody Map<String, Object> requestBody){
        return revenueService.findOrtpsTehasilcountbyServiceIdandDistrict(requestBody);
    }

    @PostMapping("/getOrtpscountbymonthandyear")
    @ResponseBody
    public List<allCountModel> findOrtpscountbymonthandyear(@RequestBody Map<String, Object> requestBody) throws ParseException {
        return revenueService.findOrtpscountbySubmissionmonthandyear(requestBody);
    }

    @GetMapping("/getAppliedPendingRejectOrtpsCountOrtpspercentagebytehasil/{id}")
    @ResponseBody
    public List<percentageModel> getAppliedPendingRejectOrtpscountOrtpspercentagebyTehasil(@PathVariable String id) {
        return revenueService.findAppliedPendingRejectOrtpscountOrtpspercentagebyTehasil(id);
    }

    @GetMapping("/findofficenamebypendingcountoftehasil/{id}")
    @ResponseBody
    public List<Object> findofficenamebypendingcountoftehasil(@PathVariable String id) {
        return revenueService.findofficenamebypendingcountoftehasil(id);
    }

    @GetMapping("/getofficebyortpscount/{id}")
    @ResponseBody
    public List<Object> findOfficebyOrtpsCount(@PathVariable String id){
        return revenueService.findOfficebyOrtpsCount(id);
    }

    @GetMapping("/getofficebytehasilortpscount/{id}")
    @ResponseBody
    public List<Object> findofficebytehasilortpscount(@PathVariable String id){
        return revenueService.FindOfficebyTehasilOrtpscount(id);
    }

    @GetMapping("/getofficenamebypendingcount/{id}")
    @ResponseBody
    public List<Object> findofficenamebypendingcount(@PathVariable String id){
        return revenueService.findofficenamebypendingcount(id);
    }



    @GetMapping("/findusernameandtaskidbyofficetype/{id}")
    @ResponseBody
    public List<Object> findusernameandtaskidbyofficetype(@PathVariable String id){
        return revenueService.findusernameandtaskidbyofficetype(id);
    }

    @GetMapping("/findusernameandtaskidbyortpscount/{id}")
    @ResponseBody
    public List<Object> findusernameandtaskidbyortpscount(@PathVariable String id){
        return revenueService.findusernameandtaskidbyortpscount(id);
    }

}

