package in.nic.edistdash.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import in.nic.edistdash.entities.EnergyfilteredExecutionData;


public interface EnergyFilteredExecDataDao extends JpaRepository<EnergyfilteredExecutionData, String> {

	@Query(value = "SELECT a.routinglocationid, a.routinglocationname, "
			+ "SUM(CAST(a.paymentamount AS NUMERIC)) AS total_initiate_payment_amount, "
			+ "SUM(CAST(efd.payment_amount AS NUMERIC)) AS total_execution_payment_amount, "
			+ "COUNT(CASE WHEN efd.status = 'Deliver' THEN 1 END) AS delivercount, "
			+ "COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END) AS forwardcount, "
			+ "COUNT(CASE WHEN efd.status = 'Reject' THEN 1 END) AS rejectcount, "
			+ "COUNT(CASE WHEN efd.status IN ('Deliver', 'Forward', 'Reject') THEN 1 END) AS appliedcount, "
			+ "COUNT(CASE WHEN (efd.status = 'Forward' "
			+ "AND to_date(a.duedate, 'YYYY-MM-DD')::date < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS')::timestamp) "
			+ "THEN 1 END) AS ortpscount, " + "CASE " + "WHEN COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END) > 0 "
			+ "AND COUNT(CASE WHEN (efd.status = 'Forward' "
			+ "AND to_date(a.duedate, 'YYYY-MM-DD')::date < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS')::timestamp) "
			+ "THEN 1 END) > 0 " + "THEN CAST(ROUND(" + "CAST(COUNT(CASE WHEN (efd.status = 'Forward' "
			+ "AND to_date(a.duedate, 'YYYY-MM-DD')::date < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS')::timestamp) "
			+ "THEN 1 END) " + "AS NUMERIC) " + "/ COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END) * 100, 2) "
			+ "AS FLOAT) " + "ELSE 0.0 " + "END AS ortps_percentage " + "FROM energy_initiate_data a "
			+ "JOIN (SELECT DISTINCT ON (appl_id) * FROM energy_filtered_execution ORDER BY appl_id) efd "
			+ "ON a.baseservice_id = efd.baseservice_id " + "AND a.applicationid = efd.appl_id "
			+ "WHERE a.baseservice_id IN :serviceid " + "AND a.applicationid IN :applicationid "
			+ "AND efd.status IN ('Deliver', 'Forward', 'Reject') "
			+ "GROUP BY a.routinglocationid, a.routinglocationname "
			+ "ORDER BY a.routinglocationid, a.routinglocationname", nativeQuery = true)
	List<String> getEnergyForwardAndDeliverAndRejectAndPaymentCountBySer(@Param("serviceid") List<String> serviceid,
			@Param("applicationid") List<String> applicationid);

	@Query(value = """
				    WITH ZoneData AS (
				        SELECT DISTINCT ON (subquery.routinglocationid)
				            subquery.routinglocationid,
				            subquery.main_grand_lgd_code AS lgd_code,
				            subquery.main_grand_office_name AS zone_name
				        FROM (
				            SELECT
				                zofc.main_grand_office_name,
				                zofc.main_grand_lgd_code,
				                unnest(ARRAY[zofc.main_grand_lgd_code, zofc.grand_lgd_code, zofc.parent_lgd_code, zofc.child_lgd_code, zofc.ofc_lgd_code])
				                AS routinglocationid
				            FROM energy_ofc_zone_data zofc
				        ) subquery
				    )

				    SELECT
				        zd.zone_name,
				        zd.lgd_code,
				       (SUM(COALESCE(CAST(a.paymentamount AS NUMERIC), 0)) +
			SUM(COALESCE(CAST(efd.payment_amount AS NUMERIC), 0))) AS total_payment_amount,

				        COUNT(CASE WHEN efd.status = 'Deliver' THEN 1 END) AS delivercount,
				        COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END) AS forwardcount,
				        COUNT(CASE WHEN efd.status = 'Reject' THEN 1 END) AS rejectcount,
				        COUNT(CASE WHEN efd.status IN ('Deliver', 'Forward', 'Reject') THEN 1 END) AS appliedcount,

				        COUNT(CASE WHEN (efd.status = 'Forward'
				                    AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				            THEN 1 END) AS ortpscount,
			 COUNT(CASE WHEN (efd.status = 'Deliver'
				                    AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				            THEN 1 END) AS ortpsdelivercount,
				        CASE
				            WHEN COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END) > 0
				            AND COUNT(CASE WHEN (efd.status = 'Forward'
				                                AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				                        THEN 1 END) > 0
				            THEN ROUND(
				                    COUNT(CASE WHEN (efd.status = 'Forward'
				                                    AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				                            THEN 1 END)
				                    * 100.0 / COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END), 2)
				            ELSE 0.0
				        END AS ortps_percentage

				    FROM energy_initiate_data a

				    JOIN (
				        SELECT DISTINCT ON (appl_id) *
				        FROM energy_filtered_execution
				        ORDER BY appl_id
				    ) efd
				    ON a.baseservice_id = efd.baseservice_id
				    AND a.applicationid = efd.appl_id

				    LEFT JOIN ZoneData zd
				    ON a.routinglocationid = zd.routinglocationid

				    WHERE a.baseservice_id IN (:serviceIds)
				    AND a.routinglocationid IN (:zoneIds)
				    AND efd.status IN ('Deliver', 'Forward', 'Reject')

				    GROUP BY zd.zone_name, zd.lgd_code
				    ORDER BY zd.zone_name
				    """, nativeQuery = true)
	List<Map<String, Object>> getEnergyForwardAndDeliverAndRejectAndPaymentCountByServiceAndZone(
			@Param("serviceIds") List<String> serviceIds, @Param("zoneIds") List<String> zoneIds);

	@Query(value = """
				    WITH ZoneData AS (
				        SELECT DISTINCT ON (subquery.routinglocationid)
				            subquery.routinglocationid,
				            subquery.grand_lgd_code AS lgd_code,
				            subquery.grand_office_name AS zone_name
				        FROM (
				            SELECT
				                zofc.grand_office_name,
				                zofc.grand_lgd_code,
				                unnest(ARRAY[zofc.grand_lgd_code, zofc.parent_lgd_code, zofc.child_lgd_code, zofc.ofc_lgd_code])
				                AS routinglocationid
				            FROM energy_ofc_zone_data zofc
				        ) subquery
				    )

				    SELECT
				        zd.zone_name,
				        zd.lgd_code,

				         (SUM(COALESCE(CAST(a.paymentamount AS NUMERIC), 0)) +
			SUM(COALESCE(CAST(efd.payment_amount AS NUMERIC), 0))) AS total_payment_amount,

				        COUNT(CASE WHEN efd.status = 'Deliver' THEN 1 END) AS delivercount,
				        COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END) AS forwardcount,
				        COUNT(CASE WHEN efd.status = 'Reject' THEN 1 END) AS rejectcount,
				        COUNT(CASE WHEN efd.status IN ('Deliver', 'Forward', 'Reject') THEN 1 END) AS appliedcount,

				        COUNT(CASE WHEN (efd.status = 'Forward'
				                    AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				            THEN 1 END) AS ortpscount,
				            COUNT(CASE WHEN (efd.status = 'Deliver'
				                    AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				            THEN 1 END) AS ortpsdelivercount,

				        CASE
				            WHEN COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END) > 0
				            AND COUNT(CASE WHEN (efd.status = 'Forward'
				                                AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				                        THEN 1 END) > 0
				            THEN ROUND(
				                    COUNT(CASE WHEN (efd.status = 'Forward'
				                                    AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				                            THEN 1 END)
				                    * 100.0 / COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END), 2)
				            ELSE 0.0
				        END AS ortps_percentage

				    FROM energy_initiate_data a

				    JOIN (
				        SELECT DISTINCT ON (appl_id) *
				        FROM energy_filtered_execution
				        ORDER BY appl_id
				    ) efd
				    ON a.baseservice_id = efd.baseservice_id
				    AND a.applicationid = efd.appl_id

				    LEFT JOIN ZoneData zd
				    ON a.routinglocationid = zd.routinglocationid

				    WHERE a.baseservice_id IN (:serviceIds)
				    AND a.routinglocationid IN (:zoneIds)
				    AND efd.status IN ('Deliver', 'Forward', 'Reject')

				    GROUP BY zd.zone_name, zd.lgd_code
				    ORDER BY zd.zone_name
				    """, nativeQuery = true)
	List<Map<String, Object>> getEnergyForwardAndDeliverAndRejectAndPaymentCountByServiceAndgrandZone(
			@Param("serviceIds") List<String> serviceIds, @Param("zoneIds") List<String> zoneIds);

	@Query(value = """
				    WITH ZoneData AS (
				        SELECT DISTINCT ON (subquery.routinglocationid)
				            subquery.routinglocationid,
				            subquery.parent_lgd_code AS lgd_code,
				            subquery.parent_office_name AS zone_name
				        FROM (
				            SELECT
				                zofc.parent_office_name,
				                zofc.parent_lgd_code,
				                unnest(ARRAY[zofc.parent_lgd_code, zofc.child_lgd_code, zofc.ofc_lgd_code])
				                AS routinglocationid
				            FROM energy_ofc_zone_data zofc
				        ) subquery
				    )

				    SELECT
				        zd.zone_name,
				        zd.lgd_code,
				        (SUM(COALESCE(CAST(a.paymentamount AS NUMERIC), 0)) +
			SUM(COALESCE(CAST(efd.payment_amount AS NUMERIC), 0))) AS total_payment_amount,

				        COUNT(CASE WHEN efd.status = 'Deliver' THEN 1 END) AS delivercount,
				        COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END) AS forwardcount,
				        COUNT(CASE WHEN efd.status = 'Reject' THEN 1 END) AS rejectcount,
				        COUNT(CASE WHEN efd.status IN ('Deliver', 'Forward', 'Reject') THEN 1 END) AS appliedcount,

				        COUNT(CASE WHEN (efd.status = 'Forward'
				                    AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				            THEN 1 END) AS ortpscount,
				            COUNT(CASE WHEN (efd.status = 'Deliver'
				                    AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				            THEN 1 END) AS ortpsdelivercount,

				        CASE
				            WHEN COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END) > 0
				            AND COUNT(CASE WHEN (efd.status = 'Forward'
				                                AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				                        THEN 1 END) > 0
				            THEN ROUND(
				                    COUNT(CASE WHEN (efd.status = 'Forward'
				                                    AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				                            THEN 1 END)
				                    * 100.0 / COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END), 2)
				            ELSE 0.0
				        END AS ortps_percentage

				    FROM energy_initiate_data a

				    JOIN (
				        SELECT DISTINCT ON (appl_id) *
				        FROM energy_filtered_execution
				        ORDER BY appl_id
				    ) efd
				    ON a.baseservice_id = efd.baseservice_id
				    AND a.applicationid = efd.appl_id

				    LEFT JOIN ZoneData zd
				    ON a.routinglocationid = zd.routinglocationid

				    WHERE a.baseservice_id IN (:serviceIds)
				    AND a.routinglocationid IN (:zoneIds)
				    AND efd.status IN ('Deliver', 'Forward', 'Reject')

				    GROUP BY zd.zone_name, zd.lgd_code
				    ORDER BY zd.zone_name
				    """, nativeQuery = true)
	List<Map<String, Object>> getEnergyForwardAndDeliverAndRejectAndPaymentCountByServiceAndparentZone(
			@Param("serviceIds") List<String> serviceIds, @Param("zoneIds") List<String> zoneIds);

	@Query(value = """
				    WITH ZoneData AS (
				        SELECT DISTINCT ON (subquery.routinglocationid)
				            subquery.routinglocationid,
				            subquery.child_lgd_code AS lgd_code,
				            subquery.child_office_name AS zone_name
				        FROM (
				            SELECT
				                zofc.child_office_name,
				                zofc.child_lgd_code,
				                unnest(ARRAY[zofc.child_lgd_code, zofc.ofc_lgd_code])
				                AS routinglocationid
				            FROM energy_ofc_zone_data zofc
				        ) subquery
				    )

				    SELECT
				        zd.zone_name,
				        zd.lgd_code,
				         (SUM(COALESCE(CAST(a.paymentamount AS NUMERIC), 0)) +
			SUM(COALESCE(CAST(efd.payment_amount AS NUMERIC), 0))) AS total_payment_amount,

				        COUNT(CASE WHEN efd.status = 'Deliver' THEN 1 END) AS delivercount,
				        COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END) AS forwardcount,
				        COUNT(CASE WHEN efd.status = 'Reject' THEN 1 END) AS rejectcount,
				        COUNT(CASE WHEN efd.status IN ('Deliver', 'Forward', 'Reject') THEN 1 END) AS appliedcount,

				        COUNT(CASE WHEN (efd.status = 'Forward'
				                    AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				            THEN 1 END) AS ortpscount,
				            COUNT(CASE WHEN (efd.status = 'Deliver'
				                    AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				            THEN 1 END) AS ortpsdelivercount,

				        CASE
				            WHEN COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END) > 0
				            AND COUNT(CASE WHEN (efd.status = 'Forward'
				                                AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				                        THEN 1 END) > 0
				            THEN ROUND(
				                    COUNT(CASE WHEN (efd.status = 'Forward'
				                                    AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				                            THEN 1 END)
				                    * 100.0 / COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END), 2)
				            ELSE 0.0
				        END AS ortps_percentage

				    FROM energy_initiate_data a

				    JOIN (
				        SELECT DISTINCT ON (appl_id) *
				        FROM energy_filtered_execution
				        ORDER BY appl_id
				    ) efd
				    ON a.baseservice_id = efd.baseservice_id
				    AND a.applicationid = efd.appl_id

				    LEFT JOIN ZoneData zd
				    ON a.routinglocationid = zd.routinglocationid

				    WHERE a.baseservice_id IN (:serviceIds)
				    AND a.routinglocationid IN (:zoneIds)
				    AND efd.status IN ('Deliver', 'Forward', 'Reject')

				    GROUP BY zd.zone_name, zd.lgd_code
				    ORDER BY zd.zone_name
				    """, nativeQuery = true)
	List<Map<String, Object>> getEnergyForwardAndDeliverAndRejectAndPaymentCountByServiceAndchildZone(
			@Param("serviceIds") List<String> serviceIds, @Param("zoneIds") List<String> zoneIds);

	@Query(value = """
				    WITH ZoneData AS (
				        SELECT DISTINCT ON (subquery.routinglocationid)
				            subquery.routinglocationid,
				            subquery.ofc_lgd_code AS lgd_code,
				            subquery.ofc_office_name AS zone_name
				        FROM (
				            SELECT
				                zofc.ofc_office_name,
				                zofc.ofc_lgd_code,
				                unnest(ARRAY[zofc.ofc_lgd_code])
				                AS routinglocationid
				            FROM energy_ofc_zone_data zofc
				        ) subquery
				    )

				    SELECT
				        zd.zone_name,
				        zd.lgd_code,
				        (SUM(COALESCE(CAST(a.paymentamount AS NUMERIC), 0)) +
			SUM(COALESCE(CAST(efd.payment_amount AS NUMERIC), 0))) AS total_payment_amount,

				        COUNT(CASE WHEN efd.status = 'Deliver' THEN 1 END) AS delivercount,
				        COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END) AS forwardcount,
				        COUNT(CASE WHEN efd.status = 'Reject' THEN 1 END) AS rejectcount,
				        COUNT(CASE WHEN efd.status IN ('Deliver', 'Forward', 'Reject') THEN 1 END) AS appliedcount,

				        COUNT(CASE WHEN (efd.status = 'Forward'
				                    AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				            THEN 1 END) AS ortpscount,
				            COUNT(CASE WHEN (efd.status = 'Deliver'
				                    AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				            THEN 1 END) AS ortpsdelivercount,

				        CASE
				            WHEN COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END) > 0
				            AND COUNT(CASE WHEN (efd.status = 'Forward'
				                                AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				                        THEN 1 END) > 0
				            THEN ROUND(
				                    COUNT(CASE WHEN (efd.status = 'Forward'
				                                    AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS'))
				                            THEN 1 END)
				                    * 100.0 / COUNT(CASE WHEN efd.status = 'Forward' THEN 1 END), 2)
				            ELSE 0.0
				        END AS ortps_percentage

				    FROM energy_initiate_data a

				    JOIN (
				        SELECT DISTINCT ON (appl_id) *
				        FROM energy_filtered_execution
				        ORDER BY appl_id
				    ) efd
				    ON a.baseservice_id = efd.baseservice_id
				    AND a.applicationid = efd.appl_id

				    LEFT JOIN ZoneData zd
				    ON a.routinglocationid = zd.routinglocationid

				    WHERE a.baseservice_id IN (:serviceIds)
				    AND a.routinglocationid IN (:zoneIds)
				    AND efd.status IN ('Deliver', 'Forward', 'Reject')

				    GROUP BY zd.zone_name, zd.lgd_code
				    ORDER BY zd.zone_name
				    """, nativeQuery = true)
	List<Map<String, Object>> getEnergyForwardAndDeliverAndRejectAndPaymentCountByServiceAndofcZone(
			@Param("serviceIds") List<String> serviceIds, @Param("zoneIds") List<String> zoneIds);

	@Query("select distinct efe.appl_id from EnergyfilteredExecutionData efe join EnergyInitiatedData ei ON ei.baseservice_id= efe.baseservice_id AND ei.applicationid = efe.appl_id where efe.baseservice_id IN :serviceid  AND ei.routinglocationid IN :zoneid")
	List<String> getApllicationIdByServiceAndZone(@Param("serviceid") List<String> serviceid,
			@Param("zoneid") List<String> zoneid);

	@Query(value = """
			WITH diff_calculation AS (
			    SELECT (to_timestamp(e.execution_time, 'DD-MM-YYYY')\\:\\:date - to_timestamp(i.submissiondate, 'DD-MM-YYYY')\\:\\:date) AS diff,
			           i.baseservice_id, i.applicationid ,i.routinglocationid
			    FROM energy_initiate_data AS i
			    INNER JOIN energy_filtered_execution AS e ON i.applicationid = e.appl_id
			    WHERE e.baseservice_id IN (:serviceid) AND i.routinglocationid IN (:appid)
			),
			status_counts AS (
			    SELECT i.baseservice_id,
			           COUNT(CASE WHEN e.status = 'Deliver' THEN 1 END) AS delivercount,
			           COUNT(CASE WHEN e.status = 'Forward' THEN 1 END) AS forwardcount,
			           COUNT(CASE WHEN e.status = 'Reject' THEN 1 END) AS rejectcount
			    FROM energy_initiate_data AS i
			    INNER JOIN energy_filtered_execution AS e ON i.applicationid = e.appl_id
			      WHERE e.baseservice_id IN (:serviceid)
			    AND i.routinglocationid IN (:appid)
			    GROUP BY i.baseservice_id
			)
			SELECT s.baseservice_id, es.servicename, MAX(d.diff) AS max_diff, MIN(d.diff) AS min_diff,
			       ROUND(AVG(d.diff), 2)\\:\\:double precision AS avg_diff,
			       PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY d.diff) AS median_diff,
			       s.delivercount, s.forwardcount, s.rejectcount
			FROM status_counts AS s
			JOIN diff_calculation AS d ON s.baseservice_id = d.baseservice_id
			JOIN energy_service es ON es.baseservice_id = s.baseservice_id
			WHERE s.baseservice_id IN (:serviceid) AND d.routinglocationid IN (:appid)
			GROUP BY s.baseservice_id, es.servicename, s.delivercount, s.forwardcount, s.rejectcount
			""", nativeQuery = true)
	List<Map<String, Object>> getMaxMinCountByServiceAndApplicationId(@Param("serviceid") List<String> serviceid,
			@Param("appid") List<String> appid);

	@Query(value = "SELECT e FROM energy_filtered_execution e WHERE e.appl_id IN :applid ORDER BY e.execution_time DESC", nativeQuery = true)
	List<Object> getApplicationByApplicationId(@Param("applid") List<String> applid);

	@Query(value = "SELECT user_name, COUNT(*) AS count FROM public.energy_filtered_execution WHERE baseservice_id = :serviceid AND status = 'Forward' GROUP BY user_name", nativeQuery = true)
	List<Map<String, Object>> getpendingDataByserviceId(@Param("serviceid") String serviceid);

	@Query(value = "SELECT efd.user_name, count(efd.user_name) FROM (SELECT DISTINCT ON (appl_id) * FROM energy_filtered_execution ORDER BY appl_id) efd JOIN energy_initiate_data a ON a.applicationid = efd.appl_id WHERE a.baseservice_id = :serviceId AND efd.status = 'Forward' AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS') group by efd.user_name", nativeQuery = true)
	List<Map<String, Object>> getpendingOrtpsDataByserviceId(@Param("serviceId") String serviceId);

	@Query(value = """
			    SELECT
			        ini.intiatedata ->> 'appl_ref_no' AS referenceNo,
			        ini.intiatedata ->> 'submission_date' AS submission_date,
			        ini.intiatedata ->> 'due_date' AS due_date,
			        ini.intiatedata -> 'attribute_details' ->> '145191' AS applicant_name,
			        ini.intiatedata -> 'attribute_details' ->> '145194' AS applicant_mobile,
			        ini.intiatedata -> 'attribute_details' ->> '145192' AS applicant_email,
			        ini.intiatedata -> 'attribute_details' ->> '145799' AS name_location_installation,
			        ini.intiatedata -> 'attribute_details' ->> '147538' AS syshighvoltage_capacity_ofinstalltion,
			        ini.intiatedata -> 'attribute_details' ->> '145802' AS additionalalterationofexitinstal,
			        ini.intiatedata -> 'attribute_details' ->> '145803' AS isrowclearanceenvirmentforestdept,
			        ini.intiatedata -> 'attribute_details' ->> '145806' AS transmision_distribution_line,
			        ini.intiatedata -> 'attribute_details' ->> '145804' AS linepassesthrough_wbrh,

			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145926', '~', 1) AS permanent_address_district_code,
			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145926', '~', 2) AS permanent_address_district,
			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145929', '~', 1) AS permanent_address_block_code,
			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145929', '~', 2) AS permanent_address_block,
			        ini.intiatedata -> 'attribute_details' ->> '145930' AS permanent_address_atpo,

			        ini.intiatedata ->> 'amount' AS paymentamount,
			        ini.intiatedata ->> 'payment_date' AS paymentdate,
			        ini.intiatedata ->> 'submission_location' AS submission_location,
			        ini.applicationid AS application_id,
			        fil.payment_amount AS exe_payment_amount,
			        fil.execution_time AS execution_date

			    FROM energy_initiate_data ini
			    JOIN energy_filtered_execution fil
			    ON ini.applicationid = fil.appl_id
			    AND ini.baseservice_id = fil.baseservice_id

			    WHERE ini.baseservice_id = :serviceId
			""", nativeQuery = true)
	List<Map<String, Object>> getDrawingApprovalDataByserviceId(@Param("serviceId") String serviceId);

	@Query(value = """
			    SELECT
			        ini.intiatedata ->> 'appl_ref_no' AS referenceNo,
			        ini.intiatedata ->> 'submission_date' AS submission_date,
			        ini.intiatedata ->> 'due_date' AS due_date,
			        ini.intiatedata -> 'attribute_details' ->> '145191' AS applicant_name,
			        ini.intiatedata -> 'attribute_details' ->> '145194' AS applicant_mobile,
			        ini.intiatedata -> 'attribute_details' ->> '145192' AS applicant_email,
			        ini.intiatedata -> 'attribute_details' ->> '145799' AS name_location_installation,
			        ini.intiatedata -> 'attribute_details' ->> '147538' AS syshighvoltage_capacity_ofinstalltion,
			        ini.intiatedata -> 'attribute_details' ->> '145802' AS additionalalterationofexitinstal,
			        ini.intiatedata -> 'attribute_details' ->> '145803' AS isrowclearanceenvirmentforestdept,
			        ini.intiatedata -> 'attribute_details' ->> '145806' AS transmision_distribution_line,
			        ini.intiatedata -> 'attribute_details' ->> '145804' AS linepassesthrough_wbrh,

			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145926', '~', 1) AS permanent_address_district_code,
			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145926', '~', 2) AS permanent_address_district,
			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145929', '~', 1) AS permanent_address_block_code,
			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145929', '~', 2) AS permanent_address_block,
			        ini.intiatedata -> 'attribute_details' ->> '145930' AS permanent_address_atpo,

			        ini.intiatedata ->> 'amount' AS paymentamount,
			        ini.intiatedata ->> 'payment_date' AS paymentdate,
			        ini.intiatedata ->> 'submission_location' AS submission_location,
			        ini.applicationid AS application_id,
			        fil.payment_amount AS exe_payment_amount,
			        fil.execution_time AS execution_date

			    FROM energy_initiate_data ini
			    JOIN energy_filtered_execution fil
			    ON ini.applicationid = fil.appl_id
			    AND ini.baseservice_id = fil.baseservice_id

			    WHERE ini.baseservice_id = :serviceId AND fil.status='Forward'
			""", nativeQuery = true)
	List<Map<String, Object>> getPendingDrawingApprovalDataByserviceId(@Param("serviceId") String serviceId);

	@Query(value = """
			    SELECT
			        ini.intiatedata ->> 'appl_ref_no' AS referenceNo,
			        ini.intiatedata ->> 'submission_date' AS submission_date,
			        ini.intiatedata ->> 'due_date' AS due_date,
			        ini.intiatedata -> 'attribute_details' ->> '145191' AS applicant_name,
			        ini.intiatedata -> 'attribute_details' ->> '145194' AS applicant_mobile,
			        ini.intiatedata -> 'attribute_details' ->> '145192' AS applicant_email,
			        ini.intiatedata -> 'attribute_details' ->> '145799' AS name_location_installation,
			        ini.intiatedata -> 'attribute_details' ->> '147538' AS syshighvoltage_capacity_ofinstalltion,
			        ini.intiatedata -> 'attribute_details' ->> '145802' AS additionalalterationofexitinstal,
			        ini.intiatedata -> 'attribute_details' ->> '145803' AS isrowclearanceenvirmentforestdept,
			        ini.intiatedata -> 'attribute_details' ->> '145806' AS transmision_distribution_line,
			        ini.intiatedata -> 'attribute_details' ->> '145804' AS linepassesthrough_wbrh,

			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145926', '~', 1) AS permanent_address_district_code,
			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145926', '~', 2) AS permanent_address_district,
			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145929', '~', 1) AS permanent_address_block_code,
			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145929', '~', 2) AS permanent_address_block,
			        ini.intiatedata -> 'attribute_details' ->> '145930' AS permanent_address_atpo,

			        ini.intiatedata ->> 'amount' AS paymentamount,
			        ini.intiatedata ->> 'payment_date' AS paymentdate,
			        ini.intiatedata ->> 'submission_location' AS submission_location,
			        ini.applicationid AS application_id,
			        fil.payment_amount AS exe_payment_amount,
			        fil.execution_time AS execution_date

			    FROM energy_initiate_data ini
			    JOIN energy_filtered_execution fil
			    ON ini.applicationid = fil.appl_id
			    AND ini.baseservice_id = fil.baseservice_id

			    WHERE ini.baseservice_id = :serviceId AND fil.status='Deliver'
			""", nativeQuery = true)
	List<Map<String, Object>> getDeliverDrawingApprovalDataByserviceId(@Param("serviceId") String serviceId);
	@Query(value = """
		    SELECT
		        ini.intiatedata ->> 'appl_ref_no' AS referenceNo,
		        ini.intiatedata ->> 'submission_date' AS submission_date,
		        ini.intiatedata ->> 'due_date' AS due_date,
		        ini.intiatedata -> 'attribute_details' ->> '145191' AS applicant_name,
		        ini.intiatedata -> 'attribute_details' ->> '145194' AS applicant_mobile,
		        ini.intiatedata -> 'attribute_details' ->> '145192' AS applicant_email,
		        ini.intiatedata -> 'attribute_details' ->> '145799' AS name_location_installation,
		        ini.intiatedata -> 'attribute_details' ->> '147538' AS syshighvoltage_capacity_ofinstalltion,
		        ini.intiatedata -> 'attribute_details' ->> '145802' AS additionalalterationofexitinstal,
		        ini.intiatedata -> 'attribute_details' ->> '145803' AS isrowclearanceenvirmentforestdept,
		        ini.intiatedata -> 'attribute_details' ->> '145806' AS transmision_distribution_line,
		        ini.intiatedata -> 'attribute_details' ->> '145804' AS linepassesthrough_wbrh,

		        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145926', '~', 1) AS permanent_address_district_code,
		        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145926', '~', 2) AS permanent_address_district,
		        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145929', '~', 1) AS permanent_address_block_code,
		        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145929', '~', 2) AS permanent_address_block,
		        ini.intiatedata -> 'attribute_details' ->> '145930' AS permanent_address_atpo,

		        ini.intiatedata ->> 'amount' AS paymentamount,
		        ini.intiatedata ->> 'payment_date' AS paymentdate,
		        ini.intiatedata ->> 'submission_location' AS submission_location,
		        ini.applicationid AS application_id,
		        fil.payment_amount AS exe_payment_amount,
		        fil.execution_time AS execution_date

		    FROM energy_initiate_data ini
		    JOIN energy_filtered_execution fil
		    ON ini.applicationid = fil.appl_id
		    AND ini.baseservice_id = fil.baseservice_id

		    WHERE ini.baseservice_id = :serviceId AND fil.status='Deliver' AND to_date(ini.duedate, 'YYYY-MM-DD') < to_timestamp(fil.execution_time, 'DD-MM-YYYY HH24:MI:SS')
		""", nativeQuery = true)
List<Map<String, Object>> getBeyondDeliverDrawingApprovalDataByserviceId(@Param("serviceId") String serviceId);
	
	@Query(value = """
		    SELECT
		        ini.intiatedata ->> 'appl_ref_no' AS referenceNo,
		        ini.intiatedata ->> 'submission_date' AS submission_date,
		        ini.intiatedata ->> 'due_date' AS due_date,
		        ini.intiatedata -> 'attribute_details' ->> '145191' AS applicant_name,
		        ini.intiatedata -> 'attribute_details' ->> '145194' AS applicant_mobile,
		        ini.intiatedata -> 'attribute_details' ->> '145192' AS applicant_email,
		        ini.intiatedata -> 'attribute_details' ->> '145799' AS name_location_installation,
		        ini.intiatedata -> 'attribute_details' ->> '147538' AS syshighvoltage_capacity_ofinstalltion,
		        ini.intiatedata -> 'attribute_details' ->> '145802' AS additionalalterationofexitinstal,
		        ini.intiatedata -> 'attribute_details' ->> '145803' AS isrowclearanceenvirmentforestdept,
		        ini.intiatedata -> 'attribute_details' ->> '145806' AS transmision_distribution_line,
		        ini.intiatedata -> 'attribute_details' ->> '145804' AS linepassesthrough_wbrh,

		        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145926', '~', 1) AS permanent_address_district_code,
		        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145926', '~', 2) AS permanent_address_district,
		        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145929', '~', 1) AS permanent_address_block_code,
		        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145929', '~', 2) AS permanent_address_block,
		        ini.intiatedata -> 'attribute_details' ->> '145930' AS permanent_address_atpo,

		        ini.intiatedata ->> 'amount' AS paymentamount,
		        ini.intiatedata ->> 'payment_date' AS paymentdate,
		        ini.intiatedata ->> 'submission_location' AS submission_location,
		        ini.applicationid AS application_id,
		        fil.payment_amount AS exe_payment_amount,
		        fil.execution_time AS execution_date

		    FROM energy_initiate_data ini
		    JOIN energy_filtered_execution fil
		    ON ini.applicationid = fil.appl_id
		    AND ini.baseservice_id = fil.baseservice_id

		    WHERE ini.baseservice_id = :serviceId AND fil.status='Forward' AND to_date(ini.duedate, 'YYYY-MM-DD') < to_timestamp(fil.execution_time, 'DD-MM-YYYY HH24:MI:SS')
		""", nativeQuery = true)
List<Map<String, Object>> getOrtpsDrawingApprovalDataByserviceId(@Param("serviceId") String serviceId);

	@Query(value = """
			    SELECT
			        ini.intiatedata ->> 'appl_ref_no' AS referenceNo,
			        ini.intiatedata ->> 'submission_date' AS submission_date,
			        ini.intiatedata ->> 'due_date' AS due_date,
			        ini.intiatedata -> 'attribute_details' ->> '145191' AS applicant_name,
			        ini.intiatedata -> 'attribute_details' ->> '145194' AS applicant_mobile,
			        ini.intiatedata -> 'attribute_details' ->> '145192' AS applicant_email,
			        ini.intiatedata -> 'attribute_details' ->> '145799' AS name_location_installation,
			        ini.intiatedata -> 'attribute_details' ->> '147538' AS syshighvoltage_capacity_ofinstalltion,
			        ini.intiatedata -> 'attribute_details' ->> '145802' AS additionalalterationofexitinstal,
			        ini.intiatedata -> 'attribute_details' ->> '145803' AS isrowclearanceenvirmentforestdept,
			        ini.intiatedata -> 'attribute_details' ->> '145806' AS transmision_distribution_line,
			        ini.intiatedata -> 'attribute_details' ->> '145804' AS linepassesthrough_wbrh,

			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145926', '~', 1) AS permanent_address_district_code,
			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145926', '~', 2) AS permanent_address_district,
			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145929', '~', 1) AS permanent_address_block_code,
			        SPLIT_PART(ini.intiatedata -> 'attribute_details' ->> '145929', '~', 2) AS permanent_address_block,
			        ini.intiatedata -> 'attribute_details' ->> '145930' AS permanent_address_atpo,

			        ini.intiatedata ->> 'amount' AS paymentamount,
			        ini.intiatedata ->> 'payment_date' AS paymentdate,
			        ini.intiatedata ->> 'submission_location' AS submission_location,
			        ini.applicationid AS application_id,
			        fil.payment_amount AS exe_payment_amount,
			        fil.execution_time AS execution_date

			    FROM energy_initiate_data ini
			    JOIN energy_filtered_execution fil
			    ON ini.applicationid = fil.appl_id
			    AND ini.baseservice_id = fil.baseservice_id

			    WHERE ini.baseservice_id = :serviceId AND fil.status='Reject'
			""", nativeQuery = true)
	List<Map<String, Object>> getRejectDrawingApprovalDataByserviceId(@Param("serviceId") String serviceId);

	@Query(value = """
					        SELECT
					            ini.intiatedata ->> 'appl_ref_no' AS referenceNo,
					            ini.intiatedata ->> 'submission_date' AS submission_date,
					            ini.intiatedata ->> 'due_date' AS due_date,
					         case
			when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122647' is not null) then ini.intiatedata ->'attribute_details'->>'122647'
			when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122717' is not null) then ini.intiatedata ->'attribute_details'->>'122717'
			when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127073' is not null) then ini.intiatedata ->'attribute_details'->>'127073'
			when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127929' is not null) then ini.intiatedata ->'attribute_details'->>'127929'
			end as inspectioncategory,
			case
			when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122667' is not null) then ini.intiatedata ->'attribute_details'->>'122667'
			when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122711' is not null) then ini.intiatedata ->'attribute_details'->>'122711'
			when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127076' is not null) then ini.intiatedata ->'attribute_details'->>'127076'
			when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127923' is not null) then ini.intiatedata ->'attribute_details'->>'127923'
			end as applicant_name,
			case
			when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122668' is not null) then ini.intiatedata ->'attribute_details'->>'122668'
			when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122712' is not null) then ini.intiatedata ->'attribute_details'->>'122712'
			when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127077' is not null) then ini.intiatedata ->'attribute_details'->>'127077'
			when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127924' is not null) then ini.intiatedata ->'attribute_details'->>'127924'
			end as applicant_mobile,

			case
			when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122669' is not null) then ini.intiatedata ->'attribute_details'->>'122669'
			when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122713' is not null) then ini.intiatedata ->'attribute_details'->>'122713'
			when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127078' is not null) then ini.intiatedata ->'attribute_details'->>'127078'
			when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127925' is not null) then ini.intiatedata ->'attribute_details'->>'127925'
			end as applicant_email,


			case
			when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122781' is not null) then ini.intiatedata ->'attribute_details'->>'122781'
			when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122760' is not null) then ini.intiatedata ->'attribute_details'->>'122760'
			when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127057' is not null) then ini.intiatedata ->'attribute_details'->>'127057'
			when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127935' is not null) then ini.intiatedata ->'attribute_details'->>'127935'
			end as installationaddressdist,
			case
			when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122785' is not null) then ini.intiatedata ->'attribute_details'->>'122785'
			when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122765' is not null) then ini.intiatedata ->'attribute_details'->>'122765'
			when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127062' is not null) then ini.intiatedata ->'attribute_details'->>'127062'
			when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127940' is not null) then ini.intiatedata ->'attribute_details'->>'127940'

			end as installationaddressblock,
			case
			when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122789' is not null) then ini.intiatedata ->'attribute_details'->>'122789'
			when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122770' is not null) then ini.intiatedata ->'attribute_details'->>'122770'
			when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127067' is not null) then ini.intiatedata ->'attribute_details'->>'127067'
			when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127944' is not null) then ini.intiatedata ->'attribute_details'->>'127944'

			end as installationaddressplot,
			case
			when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122775' is not null) then ini.intiatedata ->'attribute_details'->>'122775'
			when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122767' is not null) then ini.intiatedata ->'attribute_details'->>'122767'
			when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127064' is not null) then ini.intiatedata ->'attribute_details'->>'127064'
			when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127941' is not null) then ini.intiatedata ->'attribute_details'->>'127941'
			end as installationaddressatpo,
			case
			when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122688' is not null) then ini.intiatedata ->'attribute_details'->>'122688'
			when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122701' is not null) then ini.intiatedata ->'attribute_details'->>'122701'
			end as systemhighvoltagecap,
			case
			when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122680' is not null) then ini.intiatedata ->'attribute_details'->>'122680'
			when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122697' is not null) then ini.intiatedata ->'attribute_details'->>'122697'

			end as isgeneraterotherthandgset,
			case
			when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122683' is not null) then ini.intiatedata ->'attribute_details'->>'122683'
			when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122700' is not null) then ini.intiatedata ->'attribute_details'->>'122700'

			end as istransformoiltestSTLNABL,
			ini.intiatedata ->> 'submission_location' AS submission_location,
					            fil.payment_amount AS exe_payment_amount,
					            fil.execution_time AS execution_date

					        FROM energy_initiate_data ini
					        JOIN energy_filtered_execution fil
					        ON ini.applicationid = fil.appl_id
					        AND ini.baseservice_id = fil.baseservice_id

					        WHERE ini.baseservice_id = :serviceId
					    """, nativeQuery = true)
	List<Map<String, Object>> getDGsetDataByserviceId(@Param("serviceId") String serviceId);
	@Query(value = """
	        SELECT
	            ini.intiatedata ->> 'appl_ref_no' AS referenceNo,
	            ini.intiatedata ->> 'submission_date' AS submission_date,
	            ini.intiatedata ->> 'due_date' AS due_date,
	         case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122647' is not null) then ini.intiatedata ->'attribute_details'->>'122647'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122717' is not null) then ini.intiatedata ->'attribute_details'->>'122717'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127073' is not null) then ini.intiatedata ->'attribute_details'->>'127073'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127929' is not null) then ini.intiatedata ->'attribute_details'->>'127929'
end as inspectioncategory,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122667' is not null) then ini.intiatedata ->'attribute_details'->>'122667'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122711' is not null) then ini.intiatedata ->'attribute_details'->>'122711'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127076' is not null) then ini.intiatedata ->'attribute_details'->>'127076'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127923' is not null) then ini.intiatedata ->'attribute_details'->>'127923'
end as applicant_name,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122668' is not null) then ini.intiatedata ->'attribute_details'->>'122668'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122712' is not null) then ini.intiatedata ->'attribute_details'->>'122712'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127077' is not null) then ini.intiatedata ->'attribute_details'->>'127077'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127924' is not null) then ini.intiatedata ->'attribute_details'->>'127924'
end as applicant_mobile,

case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122669' is not null) then ini.intiatedata ->'attribute_details'->>'122669'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122713' is not null) then ini.intiatedata ->'attribute_details'->>'122713'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127078' is not null) then ini.intiatedata ->'attribute_details'->>'127078'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127925' is not null) then ini.intiatedata ->'attribute_details'->>'127925'
end as applicant_email,


case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122781' is not null) then ini.intiatedata ->'attribute_details'->>'122781'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122760' is not null) then ini.intiatedata ->'attribute_details'->>'122760'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127057' is not null) then ini.intiatedata ->'attribute_details'->>'127057'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127935' is not null) then ini.intiatedata ->'attribute_details'->>'127935'
end as installationaddressdist,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122785' is not null) then ini.intiatedata ->'attribute_details'->>'122785'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122765' is not null) then ini.intiatedata ->'attribute_details'->>'122765'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127062' is not null) then ini.intiatedata ->'attribute_details'->>'127062'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127940' is not null) then ini.intiatedata ->'attribute_details'->>'127940'

end as installationaddressblock,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122789' is not null) then ini.intiatedata ->'attribute_details'->>'122789'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122770' is not null) then ini.intiatedata ->'attribute_details'->>'122770'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127067' is not null) then ini.intiatedata ->'attribute_details'->>'127067'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127944' is not null) then ini.intiatedata ->'attribute_details'->>'127944'

end as installationaddressplot,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122775' is not null) then ini.intiatedata ->'attribute_details'->>'122775'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122767' is not null) then ini.intiatedata ->'attribute_details'->>'122767'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127064' is not null) then ini.intiatedata ->'attribute_details'->>'127064'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127941' is not null) then ini.intiatedata ->'attribute_details'->>'127941'
end as installationaddressatpo,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122688' is not null) then ini.intiatedata ->'attribute_details'->>'122688'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122701' is not null) then ini.intiatedata ->'attribute_details'->>'122701'
end as systemhighvoltagecap,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122680' is not null) then ini.intiatedata ->'attribute_details'->>'122680'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122697' is not null) then ini.intiatedata ->'attribute_details'->>'122697'

end as isgeneraterotherthandgset,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122683' is not null) then ini.intiatedata ->'attribute_details'->>'122683'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122700' is not null) then ini.intiatedata ->'attribute_details'->>'122700'

end as istransformoiltestSTLNABL,
ini.intiatedata ->> 'submission_location' AS submission_location,
	            fil.payment_amount AS exe_payment_amount,
	            fil.execution_time AS execution_date

	        FROM energy_initiate_data ini
	        JOIN energy_filtered_execution fil
	        ON ini.applicationid = fil.appl_id
	        AND ini.baseservice_id = fil.baseservice_id

	        WHERE ini.baseservice_id = :serviceId AND fil.status='Deliver'
	    """, nativeQuery = true)
List<Map<String, Object>> getDeliverDGsetDataByserviceId(@Param("serviceId") String serviceId);
	@Query(value = """
	        SELECT
	            ini.intiatedata ->> 'appl_ref_no' AS referenceNo,
	            ini.intiatedata ->> 'submission_date' AS submission_date,
	            ini.intiatedata ->> 'due_date' AS due_date,
	         case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122647' is not null) then ini.intiatedata ->'attribute_details'->>'122647'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122717' is not null) then ini.intiatedata ->'attribute_details'->>'122717'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127073' is not null) then ini.intiatedata ->'attribute_details'->>'127073'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127929' is not null) then ini.intiatedata ->'attribute_details'->>'127929'
end as inspectioncategory,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122667' is not null) then ini.intiatedata ->'attribute_details'->>'122667'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122711' is not null) then ini.intiatedata ->'attribute_details'->>'122711'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127076' is not null) then ini.intiatedata ->'attribute_details'->>'127076'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127923' is not null) then ini.intiatedata ->'attribute_details'->>'127923'
end as applicant_name,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122668' is not null) then ini.intiatedata ->'attribute_details'->>'122668'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122712' is not null) then ini.intiatedata ->'attribute_details'->>'122712'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127077' is not null) then ini.intiatedata ->'attribute_details'->>'127077'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127924' is not null) then ini.intiatedata ->'attribute_details'->>'127924'
end as applicant_mobile,

case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122669' is not null) then ini.intiatedata ->'attribute_details'->>'122669'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122713' is not null) then ini.intiatedata ->'attribute_details'->>'122713'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127078' is not null) then ini.intiatedata ->'attribute_details'->>'127078'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127925' is not null) then ini.intiatedata ->'attribute_details'->>'127925'
end as applicant_email,


case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122781' is not null) then ini.intiatedata ->'attribute_details'->>'122781'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122760' is not null) then ini.intiatedata ->'attribute_details'->>'122760'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127057' is not null) then ini.intiatedata ->'attribute_details'->>'127057'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127935' is not null) then ini.intiatedata ->'attribute_details'->>'127935'
end as installationaddressdist,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122785' is not null) then ini.intiatedata ->'attribute_details'->>'122785'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122765' is not null) then ini.intiatedata ->'attribute_details'->>'122765'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127062' is not null) then ini.intiatedata ->'attribute_details'->>'127062'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127940' is not null) then ini.intiatedata ->'attribute_details'->>'127940'

end as installationaddressblock,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122789' is not null) then ini.intiatedata ->'attribute_details'->>'122789'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122770' is not null) then ini.intiatedata ->'attribute_details'->>'122770'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127067' is not null) then ini.intiatedata ->'attribute_details'->>'127067'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127944' is not null) then ini.intiatedata ->'attribute_details'->>'127944'

end as installationaddressplot,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122775' is not null) then ini.intiatedata ->'attribute_details'->>'122775'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122767' is not null) then ini.intiatedata ->'attribute_details'->>'122767'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127064' is not null) then ini.intiatedata ->'attribute_details'->>'127064'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127941' is not null) then ini.intiatedata ->'attribute_details'->>'127941'
end as installationaddressatpo,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122688' is not null) then ini.intiatedata ->'attribute_details'->>'122688'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122701' is not null) then ini.intiatedata ->'attribute_details'->>'122701'
end as systemhighvoltagecap,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122680' is not null) then ini.intiatedata ->'attribute_details'->>'122680'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122697' is not null) then ini.intiatedata ->'attribute_details'->>'122697'

end as isgeneraterotherthandgset,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122683' is not null) then ini.intiatedata ->'attribute_details'->>'122683'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122700' is not null) then ini.intiatedata ->'attribute_details'->>'122700'

end as istransformoiltestSTLNABL,
ini.intiatedata ->> 'submission_location' AS submission_location,
	            fil.payment_amount AS exe_payment_amount,
	            fil.execution_time AS execution_date

	        FROM energy_initiate_data ini
	        JOIN energy_filtered_execution fil
	        ON ini.applicationid = fil.appl_id
	        AND ini.baseservice_id = fil.baseservice_id

	        WHERE ini.baseservice_id = :serviceId AND fil.status='Reject'
	    """, nativeQuery = true)
List<Map<String, Object>> getRejectDGsetDataByserviceId(@Param("serviceId") String serviceId);
	@Query(value = """
	        SELECT
	            ini.intiatedata ->> 'appl_ref_no' AS referenceNo,
	            ini.intiatedata ->> 'submission_date' AS submission_date,
	            ini.intiatedata ->> 'due_date' AS due_date,
	         case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122647' is not null) then ini.intiatedata ->'attribute_details'->>'122647'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122717' is not null) then ini.intiatedata ->'attribute_details'->>'122717'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127073' is not null) then ini.intiatedata ->'attribute_details'->>'127073'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127929' is not null) then ini.intiatedata ->'attribute_details'->>'127929'
end as inspectioncategory,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122667' is not null) then ini.intiatedata ->'attribute_details'->>'122667'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122711' is not null) then ini.intiatedata ->'attribute_details'->>'122711'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127076' is not null) then ini.intiatedata ->'attribute_details'->>'127076'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127923' is not null) then ini.intiatedata ->'attribute_details'->>'127923'
end as applicant_name,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122668' is not null) then ini.intiatedata ->'attribute_details'->>'122668'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122712' is not null) then ini.intiatedata ->'attribute_details'->>'122712'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127077' is not null) then ini.intiatedata ->'attribute_details'->>'127077'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127924' is not null) then ini.intiatedata ->'attribute_details'->>'127924'
end as applicant_mobile,

case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122669' is not null) then ini.intiatedata ->'attribute_details'->>'122669'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122713' is not null) then ini.intiatedata ->'attribute_details'->>'122713'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127078' is not null) then ini.intiatedata ->'attribute_details'->>'127078'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127925' is not null) then ini.intiatedata ->'attribute_details'->>'127925'
end as applicant_email,


case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122781' is not null) then ini.intiatedata ->'attribute_details'->>'122781'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122760' is not null) then ini.intiatedata ->'attribute_details'->>'122760'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127057' is not null) then ini.intiatedata ->'attribute_details'->>'127057'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127935' is not null) then ini.intiatedata ->'attribute_details'->>'127935'
end as installationaddressdist,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122785' is not null) then ini.intiatedata ->'attribute_details'->>'122785'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122765' is not null) then ini.intiatedata ->'attribute_details'->>'122765'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127062' is not null) then ini.intiatedata ->'attribute_details'->>'127062'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127940' is not null) then ini.intiatedata ->'attribute_details'->>'127940'

end as installationaddressblock,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122789' is not null) then ini.intiatedata ->'attribute_details'->>'122789'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122770' is not null) then ini.intiatedata ->'attribute_details'->>'122770'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127067' is not null) then ini.intiatedata ->'attribute_details'->>'127067'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127944' is not null) then ini.intiatedata ->'attribute_details'->>'127944'

end as installationaddressplot,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122775' is not null) then ini.intiatedata ->'attribute_details'->>'122775'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122767' is not null) then ini.intiatedata ->'attribute_details'->>'122767'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127064' is not null) then ini.intiatedata ->'attribute_details'->>'127064'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127941' is not null) then ini.intiatedata ->'attribute_details'->>'127941'
end as installationaddressatpo,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122688' is not null) then ini.intiatedata ->'attribute_details'->>'122688'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122701' is not null) then ini.intiatedata ->'attribute_details'->>'122701'
end as systemhighvoltagecap,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122680' is not null) then ini.intiatedata ->'attribute_details'->>'122680'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122697' is not null) then ini.intiatedata ->'attribute_details'->>'122697'

end as isgeneraterotherthandgset,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122683' is not null) then ini.intiatedata ->'attribute_details'->>'122683'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122700' is not null) then ini.intiatedata ->'attribute_details'->>'122700'

end as istransformoiltestSTLNABL,
ini.intiatedata ->> 'submission_location' AS submission_location,
	            fil.payment_amount AS exe_payment_amount,
	            fil.execution_time AS execution_date

	        FROM energy_initiate_data ini
	        JOIN energy_filtered_execution fil
	        ON ini.applicationid = fil.appl_id
	        AND ini.baseservice_id = fil.baseservice_id

	        WHERE ini.baseservice_id = :serviceId AND fil.status='Forward'
	    """, nativeQuery = true)
List<Map<String, Object>> getPendingDGsetDataByserviceId(@Param("serviceId") String serviceId);
	
	@Query(value = """
	        SELECT
	            ini.intiatedata ->> 'appl_ref_no' AS referenceNo,
	            ini.intiatedata ->> 'submission_date' AS submission_date,
	            ini.intiatedata ->> 'due_date' AS due_date,
	         case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122647' is not null) then ini.intiatedata ->'attribute_details'->>'122647'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122717' is not null) then ini.intiatedata ->'attribute_details'->>'122717'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127073' is not null) then ini.intiatedata ->'attribute_details'->>'127073'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127929' is not null) then ini.intiatedata ->'attribute_details'->>'127929'
end as inspectioncategory,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122667' is not null) then ini.intiatedata ->'attribute_details'->>'122667'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122711' is not null) then ini.intiatedata ->'attribute_details'->>'122711'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127076' is not null) then ini.intiatedata ->'attribute_details'->>'127076'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127923' is not null) then ini.intiatedata ->'attribute_details'->>'127923'
end as applicant_name,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122668' is not null) then ini.intiatedata ->'attribute_details'->>'122668'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122712' is not null) then ini.intiatedata ->'attribute_details'->>'122712'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127077' is not null) then ini.intiatedata ->'attribute_details'->>'127077'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127924' is not null) then ini.intiatedata ->'attribute_details'->>'127924'
end as applicant_mobile,

case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122669' is not null) then ini.intiatedata ->'attribute_details'->>'122669'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122713' is not null) then ini.intiatedata ->'attribute_details'->>'122713'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127078' is not null) then ini.intiatedata ->'attribute_details'->>'127078'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127925' is not null) then ini.intiatedata ->'attribute_details'->>'127925'
end as applicant_email,


case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122781' is not null) then ini.intiatedata ->'attribute_details'->>'122781'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122760' is not null) then ini.intiatedata ->'attribute_details'->>'122760'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127057' is not null) then ini.intiatedata ->'attribute_details'->>'127057'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127935' is not null) then ini.intiatedata ->'attribute_details'->>'127935'
end as installationaddressdist,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122785' is not null) then ini.intiatedata ->'attribute_details'->>'122785'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122765' is not null) then ini.intiatedata ->'attribute_details'->>'122765'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127062' is not null) then ini.intiatedata ->'attribute_details'->>'127062'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127940' is not null) then ini.intiatedata ->'attribute_details'->>'127940'

end as installationaddressblock,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122789' is not null) then ini.intiatedata ->'attribute_details'->>'122789'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122770' is not null) then ini.intiatedata ->'attribute_details'->>'122770'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127067' is not null) then ini.intiatedata ->'attribute_details'->>'127067'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127944' is not null) then ini.intiatedata ->'attribute_details'->>'127944'

end as installationaddressplot,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122775' is not null) then ini.intiatedata ->'attribute_details'->>'122775'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122767' is not null) then ini.intiatedata ->'attribute_details'->>'122767'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127064' is not null) then ini.intiatedata ->'attribute_details'->>'127064'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127941' is not null) then ini.intiatedata ->'attribute_details'->>'127941'
end as installationaddressatpo,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122688' is not null) then ini.intiatedata ->'attribute_details'->>'122688'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122701' is not null) then ini.intiatedata ->'attribute_details'->>'122701'
end as systemhighvoltagecap,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122680' is not null) then ini.intiatedata ->'attribute_details'->>'122680'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122697' is not null) then ini.intiatedata ->'attribute_details'->>'122697'

end as isgeneraterotherthandgset,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122683' is not null) then ini.intiatedata ->'attribute_details'->>'122683'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122700' is not null) then ini.intiatedata ->'attribute_details'->>'122700'

end as istransformoiltestSTLNABL,
ini.intiatedata ->> 'submission_location' AS submission_location,
	            fil.payment_amount AS exe_payment_amount,
	            fil.execution_time AS execution_date

	        FROM energy_initiate_data ini
	        JOIN energy_filtered_execution fil
	        ON ini.applicationid = fil.appl_id
	        AND ini.baseservice_id = fil.baseservice_id

	        WHERE ini.baseservice_id = :serviceId AND fil.status='Forward' AND to_date(ini.duedate, 'YYYY-MM-DD') < to_timestamp(fil.execution_time, 'DD-MM-YYYY HH24:MI:SS')
	    """, nativeQuery = true)
List<Map<String, Object>> getOrtpsDGsetDataByserviceId(@Param("serviceId") String serviceId);
	
	@Query(value = """
	        SELECT
	            ini.intiatedata ->> 'appl_ref_no' AS referenceNo,
	            ini.intiatedata ->> 'submission_date' AS submission_date,
	            ini.intiatedata ->> 'due_date' AS due_date,
	         case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122647' is not null) then ini.intiatedata ->'attribute_details'->>'122647'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122717' is not null) then ini.intiatedata ->'attribute_details'->>'122717'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127073' is not null) then ini.intiatedata ->'attribute_details'->>'127073'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127929' is not null) then ini.intiatedata ->'attribute_details'->>'127929'
end as inspectioncategory,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122667' is not null) then ini.intiatedata ->'attribute_details'->>'122667'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122711' is not null) then ini.intiatedata ->'attribute_details'->>'122711'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127076' is not null) then ini.intiatedata ->'attribute_details'->>'127076'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127923' is not null) then ini.intiatedata ->'attribute_details'->>'127923'
end as applicant_name,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122668' is not null) then ini.intiatedata ->'attribute_details'->>'122668'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122712' is not null) then ini.intiatedata ->'attribute_details'->>'122712'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127077' is not null) then ini.intiatedata ->'attribute_details'->>'127077'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127924' is not null) then ini.intiatedata ->'attribute_details'->>'127924'
end as applicant_mobile,

case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122669' is not null) then ini.intiatedata ->'attribute_details'->>'122669'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122713' is not null) then ini.intiatedata ->'attribute_details'->>'122713'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127078' is not null) then ini.intiatedata ->'attribute_details'->>'127078'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127925' is not null) then ini.intiatedata ->'attribute_details'->>'127925'
end as applicant_email,


case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122781' is not null) then ini.intiatedata ->'attribute_details'->>'122781'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122760' is not null) then ini.intiatedata ->'attribute_details'->>'122760'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127057' is not null) then ini.intiatedata ->'attribute_details'->>'127057'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127935' is not null) then ini.intiatedata ->'attribute_details'->>'127935'
end as installationaddressdist,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122785' is not null) then ini.intiatedata ->'attribute_details'->>'122785'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122765' is not null) then ini.intiatedata ->'attribute_details'->>'122765'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127062' is not null) then ini.intiatedata ->'attribute_details'->>'127062'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127940' is not null) then ini.intiatedata ->'attribute_details'->>'127940'

end as installationaddressblock,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122789' is not null) then ini.intiatedata ->'attribute_details'->>'122789'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122770' is not null) then ini.intiatedata ->'attribute_details'->>'122770'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127067' is not null) then ini.intiatedata ->'attribute_details'->>'127067'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127944' is not null) then ini.intiatedata ->'attribute_details'->>'127944'

end as installationaddressplot,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122775' is not null) then ini.intiatedata ->'attribute_details'->>'122775'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122767' is not null) then ini.intiatedata ->'attribute_details'->>'122767'
when (ini.intiatedata->>'base_service_id'='1740' and ini.intiatedata ->'attribute_details'->>'127064' is not null) then ini.intiatedata ->'attribute_details'->>'127064'
when (ini.intiatedata->>'base_service_id'='1747' and ini.intiatedata ->'attribute_details'->>'127941' is not null) then ini.intiatedata ->'attribute_details'->>'127941'
end as installationaddressatpo,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122688' is not null) then ini.intiatedata ->'attribute_details'->>'122688'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122701' is not null) then ini.intiatedata ->'attribute_details'->>'122701'
end as systemhighvoltagecap,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122680' is not null) then ini.intiatedata ->'attribute_details'->>'122680'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122697' is not null) then ini.intiatedata ->'attribute_details'->>'122697'

end as isgeneraterotherthandgset,
case
when (ini.intiatedata->>'base_service_id'='1674' and ini.intiatedata ->'attribute_details'->>'122683' is not null) then ini.intiatedata ->'attribute_details'->>'122683'
when (ini.intiatedata->>'base_service_id'='1675' and ini.intiatedata ->'attribute_details'->>'122700' is not null) then ini.intiatedata ->'attribute_details'->>'122700'

end as istransformoiltestSTLNABL,
ini.intiatedata ->> 'submission_location' AS submission_location,
	            fil.payment_amount AS exe_payment_amount,
	            fil.execution_time AS execution_date

	        FROM energy_initiate_data ini
	        JOIN energy_filtered_execution fil
	        ON ini.applicationid = fil.appl_id
	        AND ini.baseservice_id = fil.baseservice_id

	        WHERE ini.baseservice_id = :serviceId AND fil.status = 'Deliver' AND to_date(ini.duedate, 'YYYY-MM-DD') < to_timestamp(fil.execution_time, 'DD-MM-YYYY HH24:MI:SS')
	    """, nativeQuery = true)
List<Map<String, Object>> getBeyondDeliverDGsetDataByserviceId(@Param("serviceId") String serviceId);

	@Query(value = "SELECT e.user_name, count(e.user_name) FROM energy_filtered_execution e JOIN energy_initiate_data a ON a.applicationid = e.appl_id WHERE a.baseservice_id IN :serviceid AND a.routinglocationid IN :locationid AND e.status='Forward' GROUP BY e.user_name", nativeQuery = true)
	List<Map<String, Object>> getpendingDataByserviceIdAndZone(@Param("serviceid") List<String> serviceid,
			@Param("locationid") List<String> locationid);

	@Query(value = "SELECT efd.task_name AS task_name, COUNT(efd.task_name) AS task_count, SUM(CAST(efd.payment_amount AS NUMERIC)) AS total_payment_amount FROM public.energy_filtered_execution efd WHERE efd.user_name = :username AND efd.baseservice_id IN :serviceid  AND efd.status = 'Forward' GROUP BY efd.task_name;", nativeQuery = true)
	List<Map<String, Object>> getPendingTaskDataByUsername(@Param("serviceid") List<String> serviceid,
			@Param("username") String username);

	@Query(value = "SELECT efd.task_name AS task_name, COUNT(efd.task_name) AS task_count, SUM(CAST(efd.payment_amount AS NUMERIC)) AS total_payment_amount FROM (SELECT DISTINCT ON (appl_id) * FROM energy_filtered_execution ORDER BY appl_id) efd JOIN energy_initiate_data a ON a.applicationid = efd.appl_id WHERE a.baseservice_id IN :serviceid AND efd.status = 'Forward' AND efd.user_name = :username AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS') GROUP BY efd.task_name;", nativeQuery = true)
	List<Map<String, Object>> getPendingOrtpsTaskDataByUsername(@Param("serviceid") List<String> serviceid,
			@Param("username") String username);

	@Query(value = "SELECT e.task_name AS task_name, count(e.task_name) AS task_count,SUM(CAST(e.payment_amount AS NUMERIC)) AS total_payment_amount FROM energy_filtered_execution e JOIN energy_initiate_data a ON a.applicationid = e.appl_id WHERE a.baseservice_id IN :serviceid AND a.routinglocationid IN :locationid AND e.status='Forward' AND e.user_name = :username  GROUP BY e.task_name", nativeQuery = true)
	List<Map<String, Object>> getpendingTaskDataByserviceIdAndUsernameAndZone(
			@Param("serviceid") List<String> serviceid, @Param("locationid") List<String> locationid,
			@Param("username") String username);

	@Query(value = "SELECT efd.user_name, count(efd.user_name) FROM (SELECT DISTINCT ON (appl_id) * FROM energy_filtered_execution ORDER BY appl_id) efd JOIN energy_initiate_data a ON a.applicationid = efd.appl_id WHERE a.baseservice_id IN :serviceid AND a.routinglocationid IN :locationid AND efd.status = 'Forward' AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS') group by efd.user_name", nativeQuery = true)
	List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndZone(@Param("serviceid") List<String> serviceid,
			@Param("locationid") List<String> locationid);

	@Query(value = "SELECT efd.task_name AS task_name, COUNT(efd.task_name) AS task_count, SUM(CAST(efd.payment_amount AS NUMERIC)) AS total_payment_amount FROM (SELECT DISTINCT ON (appl_id) * FROM energy_filtered_execution ORDER BY appl_id) efd JOIN energy_initiate_data a ON a.applicationid = efd.appl_id WHERE a.baseservice_id IN :serviceId AND a.routinglocationid IN :locationid AND efd.status = 'Forward' AND efd.user_name = :username AND to_date(a.duedate, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS') GROUP BY efd.task_name", nativeQuery = true)
	List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndUsernameAndZone(
			@Param("serviceId") List<String> serviceId, @Param("locationid") List<String> locationid,
			@Param("username") String username);


}
