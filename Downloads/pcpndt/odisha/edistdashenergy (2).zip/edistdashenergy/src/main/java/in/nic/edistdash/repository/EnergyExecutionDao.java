package in.nic.edistdash.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import in.nic.edistdash.entities.EnergyExecuteData;


public interface EnergyExecutionDao extends JpaRepository<EnergyExecuteData, String>{
	

	@Query(value = "SELECT * FROM energy_execution_data e WHERE status = 'Reject' AND (appl_id, service_id, execution_time) IN (SELECT appl_id, service_id, MAX(execution_time) FROM energy_execution_data WHERE status = 'Reject' GROUP BY appl_id, service_id) ORDER BY execution_time DESC", nativeQuery = true) 
	List<EnergyExecuteData> getEnergyrejectCount();

	@Query(value = "SELECT * FROM energy_execution_data e WHERE status = 'Forward' AND (appl_id, service_id, execution_time) IN (SELECT appl_id, service_id, MAX(execution_time) FROM energy_execution_data WHERE status = 'Forward' GROUP BY appl_id, service_id) ORDER BY execution_time DESC", nativeQuery = true) 
	List<EnergyExecuteData> getEnergyForwardCount();
	
	@Query(value = "SELECT * FROM energy_execution_data e WHERE status = 'Deliver' AND (appl_id, service_id, execution_time) IN (SELECT appl_id, service_id, MAX(execution_time) FROM energy_execution_data WHERE status = 'Deliver' GROUP BY appl_id, service_id) ORDER BY execution_time DESC", nativeQuery = true) 
	List<EnergyExecuteData> getEnergyDeliverCount();
	
	@Query(value = "WITH RankedData AS (SELECT service_id, appl_id, status, execution_time, ROW_NUMBER() OVER (PARTITION BY service_id, appl_id ORDER BY execution_time DESC) AS rn FROM energy_execution_data) SELECT status, COUNT(*) AS status_count FROM RankedData WHERE rn = 1 AND status IS NOT NULL GROUP BY status", nativeQuery = true) 
	List<Object>getEnergyForwardAndDeliverAndRejectCount();
	
	@Query(value = "WITH RankedData AS (SELECT baseservice_id, appl_id, status, execution_time, ROW_NUMBER() OVER (PARTITION BY baseservice_id, appl_id ORDER BY execution_time DESC) AS rn FROM energy_execution_data where baseservice_id IN :serviceid) SELECT status, COUNT(*) AS status_count FROM RankedData WHERE rn = 1 AND status IS NOT NULL GROUP BY status", nativeQuery = true) 
	List<Object>getEnergyForwardAndDeliverAndRejectCountByService(@Param("serviceid") List<String> serviceid);
	
	@Query(value ="SELECT e FROM energy_execution_data e WHERE e.appl_id IN :applid ORDER BY e.execution_time DESC",nativeQuery = true)
	List<Object> getApplicationByApplicationId(@Param("applid") List<String> applid);
}
