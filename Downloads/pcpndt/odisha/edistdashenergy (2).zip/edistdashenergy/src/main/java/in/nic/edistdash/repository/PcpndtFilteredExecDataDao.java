package in.nic.edistdash.repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import in.nic.edistdash.entities.EnergyfilteredExecutionData;

public interface PcpndtFilteredExecDataDao extends JpaRepository<EnergyfilteredExecutionData, String> {
	
	
	   
	  @Query(value = "SELECT efd.user_name,efd.task_name,count(efd.user_name) as count FROM pcpndt_execution_filtered efd JOIN pcpndt_initiated_data a ON a.appl_id = efd.appl_id WHERE a.routinglocationid = :districtId AND efd.status = 'Forward' group by efd.user_name,efd.task_name", nativeQuery = true)
	  List<Map<String, Object>> getPendingDataByDistrictId(@Param("districtId") String districtId);

	  
	  @Query(value = "SELECT efd.user_name, efd.task_name, COUNT(efd.user_name) AS count FROM pcpndt_execution_filtered efd JOIN pcpndt_initiated_data a ON a.appl_id = efd.appl_id WHERE a.routinglocationid = :main_lgd AND efd.status = 'Forward' AND TO_DATE(a.submission_date, 'DD-MM-YYYY HH24:MI:SS') BETWEEN TO_DATE(:startDate, 'DD-MM-YYYY') AND TO_DATE(:endDate, 'DD-MM-YYYY') GROUP BY efd.user_name, efd.task_name", nativeQuery = true)
	  List<Map<String, Object>> getpendingDataByDistrictstdtenddtId(@Param("main_lgd") String main_lgd,@Param("startDate") String startDate,@Param("endDate") String endDate);
		
	 @Query(value ="SELECT efd.user_name,efd.task_name,count(efd.user_name) as count FROM pcpndt_execution_filtered efd JOIN pcpndt_initiated_data a ON a.appl_id = efd.appl_id WHERE a.routinglocationid = :districtId AND efd.status = 'Forward' AND to_date(a.due_date, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS') group by efd.user_name,efd.task_name", nativeQuery = true) 
	 List<Map<String, Object>> getpendingOrtpsDataByDistrictId(@Param("districtId") String districtId);
		
	 @Query(value ="SELECT efd.user_name, efd.task_name, COUNT(efd.user_name) AS count FROM pcpndt_execution_filtered efd JOIN pcpndt_initiated_data a ON a.appl_id = efd.appl_id WHERE a.routinglocationid = :main_lgd AND efd.status = 'Forward' AND TO_DATE(a.due_date, 'YYYY-MM-DD') < TO_TIMESTAMP(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS') AND TO_DATE(a.submission_date, 'DD-MM-YYYY HH24:MI:SS') BETWEEN TO_DATE(:startDate, 'DD-MM-YYYY') AND TO_DATE(:endDate, 'DD-MM-YYYY') GROUP BY efd.user_name, efd.task_name", nativeQuery = true) 
	 List<Map<String, Object>> getpendingOrtpsDataByDistrictstdtenddtId(@Param("main_lgd") String main_lgd,@Param("startDate") String startDate,@Param("endDate") String endDate);
	
	 @Query(value = "SELECT pcpini.applicant_name, pcpini.mobile_no, pcpini.emails, pcpini.submission_date, pcpini.due_date, pcpini.name_of_centre, pcpini.routinglocationname FROM pcpndt_initiated_data pcpini INNER JOIN pcpndt_execution_filtered efd ON pcpini.appl_id = efd.appl_id WHERE pcpini.routinglocationid = :main_lgd AND efd.status = 'Reject' AND TO_DATE(pcpini.submission_date, 'DD-MM-YYYY HH24:MI:SS') BETWEEN TO_DATE(:startDate, 'DD-MM-YYYY') AND TO_DATE(:endDate, 'DD-MM-YYYY')", nativeQuery = true)
	 List<Map<String, Object>> getrejectingDataByDistrictstdtenddtId(@Param("main_lgd") String main_lgd,@Param("startDate") String startDate,@Param("endDate") String endDate);
		
	 @Query(value = "SELECT pcpini.applicant_name, pcpini.mobile_no, pcpini.emails, pcpini.submission_date, pcpini.due_date, pcpini.name_of_centre, pcpini.routinglocationname FROM pcpndt_initiated_data pcpini INNER JOIN pcpndt_execution_filtered efd ON pcpini.appl_id = efd.appl_id WHERE pcpini.routinglocationid = :main_lgd AND efd.status = 'Deliver' AND TO_DATE(pcpini.due_date, 'YYYY-MM-DD') < TO_TIMESTAMP(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS') AND TO_DATE(pcpini.submission_date, 'DD-MM-YYYY HH24:MI:SS') BETWEEN TO_DATE(:startDate, 'DD-MM-YYYY') AND TO_DATE(:endDate, 'DD-MM-YYYY')", nativeQuery = true)
	 List<Map<String, Object>> getordelDataByDistrictstdtenddtId(@Param("main_lgd") String main_lgd,@Param("startDate") String startDate,@Param("endDate") String endDate);
	 
	 @Query(value = "SELECT pcpini.applicant_name, pcpini.mobile_no, pcpini.emails, pcpini.submission_date, pcpini.due_date, pcpini.name_of_centre, pcpini.routinglocationname FROM pcpndt_initiated_data pcpini INNER JOIN pcpndt_execution_filtered efd ON pcpini.appl_id = efd.appl_id WHERE pcpini.routinglocationid = :main_lgd AND TO_DATE(pcpini.submission_date, 'DD-MM-YYYY HH24:MI:SS') BETWEEN TO_DATE(:startDate, 'DD-MM-YYYY') AND TO_DATE(:endDate, 'DD-MM-YYYY')", nativeQuery = true)
	 List<Map<String, Object>> gettapplordelDataByDistrictstdtenddtId(@Param("main_lgd") String main_lgd,@Param("startDate") String startDate,@Param("endDate") String endDate);
		
	@Query(value = "SELECT pcpini.applicant_name, pcpini.mobile_no, pcpini.emails, pcpini.submission_date, pcpini.due_date, pcpini.name_of_centre, pcpini.routinglocationname FROM pcpndt_initiated_data pcpini INNER JOIN pcpndt_execution_filtered efd ON pcpini.appl_id = efd.appl_id WHERE pcpini.routinglocationid = :main_lgd AND efd.status = 'Deliver' AND TO_DATE(pcpini.submission_date, 'DD-MM-YYYY HH24:MI:SS') BETWEEN TO_DATE(:startDate, 'DD-MM-YYYY') AND TO_DATE(:endDate, 'DD-MM-YYYY')", nativeQuery = true)
	List<Map<String, Object>> gettotaldeliverByDistrictstdtenddtId(@Param("main_lgd") String main_lgd,@Param("startDate") String startDate,@Param("endDate") String endDate);
	
	 
	@Query(value = "SELECT pcpini.applicant_name,pcpini.mobile_no,pcpini.emails,pcpini.submission_date,pcpini.due_date,pcpini.name_of_centre,pcpini.routinglocationname from pcpndt_initiated_data pcpini inner join pcpndt_execution_filtered efd on pcpini.appl_id=efd.appl_id WHERE pcpini.routinglocationid = :districtId AND efd.status = 'Reject'", nativeQuery = true)
	List<Map<String, Object>> getrejectDataByDistrictId(@Param("districtId") String districtId);
	
	
	@Query(value = "SELECT pcpini.applicant_name,pcpini.mobile_no,pcpini.emails,pcpini.submission_date,pcpini.due_date,pcpini.name_of_centre,pcpini.routinglocationname from pcpndt_initiated_data pcpini inner join pcpndt_execution_filtered efd on pcpini.appl_id=efd.appl_id WHERE pcpini.routinglocationid=:districtId AND efd.status = 'Deliver' AND to_date(pcpini.due_date, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS')", nativeQuery = true)
	List<Map<String, Object>> getordelDataByDistrictId(@Param("districtId") String districtId);
	
	@Query(value = "SELECT pcpini.applicant_name,pcpini.mobile_no,pcpini.emails,pcpini.submission_date,pcpini.due_date,pcpini.name_of_centre,pcpini.routinglocationname from pcpndt_initiated_data pcpini inner join pcpndt_execution_filtered efd on pcpini.appl_id=efd.appl_id WHERE pcpini.routinglocationid=:districtId", nativeQuery = true)
	List<Map<String, Object>> gettapplordelDataByDistrictId(@Param("districtId") String districtId);
	
	@Query(value = "SELECT pcpini.applicant_name,pcpini.mobile_no,pcpini.emails,pcpini.submission_date,pcpini.due_date,pcpini.name_of_centre,pcpini.routinglocationname from pcpndt_initiated_data pcpini inner join pcpndt_execution_filtered efd on pcpini.appl_id=efd.appl_id WHERE pcpini.routinglocationid=:districtId AND efd.status = 'Deliver'", nativeQuery = true)
	List<Map<String, Object>> gettotaldeliverByDistrictId(@Param("districtId") String districtId);
	

	@Query(
		    value = """
		WITH diff_calculation AS (
		  SELECT 
		    pef.appl_id,
		    ini.routinglocationid,
		    (CAST(to_timestamp(pef.execution_time, 'DD-MM-YYYY HH24:MI:SS') AS date) 
		     - 
		     CAST(to_timestamp(ini.submission_date, 'DD-MM-YYYY HH24:MI:SS') AS date)
		    ) AS diff
		  FROM pcpndt_initiated_data ini
		  INNER JOIN pcpndt_execution_filtered pef 
		    ON ini.appl_id = pef.appl_id
		),
		status_counts AS (
		  SELECT 
		    ini.routinglocationid,
		    ini.routinglocationname,
		    SUM(CASE WHEN pef.status = 'Deliver' THEN 1 ELSE 0 END) AS deliver_count,
		    SUM(CASE WHEN pef.status = 'Reject' THEN 1 ELSE 0 END) AS reject_count,
		    SUM(CASE WHEN pef.status = 'Forward' THEN 1 ELSE 0 END) AS forward_count,
		    (
		      SUM(CASE WHEN pef.status = 'Deliver' THEN 1 ELSE 0 END) +
		      SUM(CASE WHEN pef.status = 'Reject' THEN 1 ELSE 0 END) +
		      SUM(CASE WHEN pef.status = 'Forward' THEN 1 ELSE 0 END)
		    ) AS totalapplied,
		    SUM(COALESCE(CAST(ini.payment_amount AS NUMERIC), 0)) AS total_payment_amount,
		    COUNT(DISTINCT CASE WHEN (pef.status = 'Forward' AND to_date(ini.due_date, 'YYYY-MM-DD') < to_timestamp(pef.execution_time, 'DD-MM-YYYY HH24:MI:SS')) THEN ini.appl_id ELSE NULL END) AS ortpscount,
		    COUNT(DISTINCT CASE WHEN (pef.status = 'Deliver' AND to_date(ini.due_date, 'YYYY-MM-DD') < to_timestamp(pef.execution_time, 'DD-MM-YYYY HH24:MI:SS')) THEN ini.appl_id ELSE NULL END) AS ortpsdelivercount,
		    CASE 
		      WHEN COUNT(DISTINCT CASE WHEN pef.status = 'Forward' THEN ini.appl_id ELSE NULL END) > 0 
		      THEN ROUND(
		        COUNT(DISTINCT CASE WHEN (pef.status = 'Forward' AND to_date(ini.due_date, 'YYYY-MM-DD') < to_timestamp(pef.execution_time, 'DD-MM-YYYY HH24:MI:SS')) THEN ini.appl_id ELSE NULL END) * 100.0
		        /
		        COUNT(DISTINCT CASE WHEN pef.status = 'Forward' THEN ini.appl_id ELSE NULL END),
		        2
		      )
		      ELSE 0.0
		    END AS ortps_percentage
		  FROM pcpndt_initiated_data ini
		  INNER JOIN pcpndt_execution_filtered pef 
		    ON ini.appl_id = pef.appl_id
		  GROUP BY ini.routinglocationid, ini.routinglocationname
		)

		SELECT 
		  MAX(d.diff) AS max_diff,
		  MIN(d.diff) AS min_diff,
		  ROUND(CAST(AVG(d.diff) AS numeric), 2) AS avg_diff,
		  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY d.diff) AS median_diff,
		  s.routinglocationid,
		  s.routinglocationname,
		  s.deliver_count,
		  s.forward_count,
		  s.reject_count,
		  s.totalapplied,
		  s.ortpscount,
		  s.ortpsdelivercount,
		  s.ortps_percentage,
		  s.total_payment_amount
		FROM status_counts AS s
		JOIN diff_calculation AS d 
		  ON s.routinglocationid = d.routinglocationid
		WHERE s.routinglocationid IN (:zoneIds)
		GROUP BY s.routinglocationid, s.routinglocationname, s.deliver_count, s.forward_count, s.reject_count, s.totalapplied, s.ortpscount, s.ortpsdelivercount, s.ortps_percentage, s.total_payment_amount
		""",
		    nativeQuery = true
		)
		List<Map<String, Object>> getPcpndtForwardAndDeliverAndRejectAndPaymentCountByServiceAndDist(@Param("zoneIds") List<String> zoneIds);

	@Query(
		    value = """
		    		WITH filtered_data AS (
					  SELECT *
					  FROM pcpndt_initiated_data
					  WHERE to_date(submission_date, 'DD-MM-YYYY HH24:MI:SS') 
					        BETWEEN to_date(:startDate, 'DD-MM-YYYY') 
					        AND to_date(:endDate, 'DD-MM-YYYY')
					),
					
					diff_calculation AS (
					  SELECT 
					    pef.appl_id,
					    ini.routinglocationid,
					    (
					      CAST(to_timestamp(pef.execution_time, 'DD-MM-YYYY HH24:MI:SS') AS date) 
					      - 
					      CAST(to_timestamp(ini.submission_date, 'DD-MM-YYYY HH24:MI:SS') AS date)
					    ) AS diff
					  FROM filtered_data ini
					  INNER JOIN pcpndt_execution_filtered pef 
					    ON ini.appl_id = pef.appl_id
					),
					
					diff_summary AS (
					  SELECT
					    routinglocationid,
					    MAX(diff) AS max_diff,
					    MIN(diff) AS min_diff,
					    ROUND(CAST(AVG(diff) AS numeric), 2) AS avg_diff,
					    PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY diff) AS median_diff
					  FROM diff_calculation
					  GROUP BY routinglocationid
					),
					
					status_counts AS (
					  SELECT 
					    ini.routinglocationid,
					    ini.routinglocationname,
					    SUM(CASE WHEN pef.status = 'Deliver' THEN 1 ELSE 0 END) AS deliver_count,
					    SUM(CASE WHEN pef.status = 'Reject' THEN 1 ELSE 0 END) AS reject_count,
					    SUM(CASE WHEN pef.status = 'Forward' THEN 1 ELSE 0 END) AS forward_count,
					    (
					      SUM(CASE WHEN pef.status = 'Deliver' THEN 1 ELSE 0 END) +
					      SUM(CASE WHEN pef.status = 'Reject' THEN 1 ELSE 0 END) +
					      SUM(CASE WHEN pef.status = 'Forward' THEN 1 ELSE 0 END)
					    ) AS totalapplied,
					    SUM(COALESCE(CAST(ini.payment_amount AS NUMERIC), 0)) AS total_payment_amount,
					    COUNT(DISTINCT CASE WHEN (pef.status = 'Forward' AND to_date(ini.due_date, 'YYYY-MM-DD') < to_timestamp(pef.execution_time, 'DD-MM-YYYY HH24:MI:SS')) THEN ini.appl_id ELSE NULL END) AS ortpscount,
					    COUNT(DISTINCT CASE WHEN (pef.status = 'Deliver' AND to_date(ini.due_date, 'YYYY-MM-DD') < to_timestamp(pef.execution_time, 'DD-MM-YYYY HH24:MI:SS')) THEN ini.appl_id ELSE NULL END) AS ortpsdelivercount,
					    CASE 
					      WHEN COUNT(DISTINCT CASE WHEN pef.status = 'Forward' THEN ini.appl_id ELSE NULL END) > 0 
					      THEN ROUND(
					        COUNT(DISTINCT CASE WHEN (pef.status = 'Forward' AND to_date(ini.due_date, 'YYYY-MM-DD') < to_timestamp(pef.execution_time, 'DD-MM-YYYY HH24:MI:SS')) THEN ini.appl_id ELSE NULL END) * 100.0
					        /
					        COUNT(DISTINCT CASE WHEN pef.status = 'Forward' THEN ini.appl_id ELSE NULL END),
					        2
					      )
					      ELSE 0.0
					    END AS ortps_percentage
					  FROM filtered_data ini
					  INNER JOIN pcpndt_execution_filtered pef 
					    ON ini.appl_id = pef.appl_id
					  GROUP BY ini.routinglocationid, ini.routinglocationname
					)
					
					SELECT 
					  d.max_diff,
					  d.min_diff,
					  d.avg_diff,
					  d.median_diff,
					  s.routinglocationid,
					  s.routinglocationname,
					  s.deliver_count,
					  s.forward_count,
					  s.reject_count,
					  s.totalapplied,
					  s.ortpscount,
					  s.ortpsdelivercount,
					  s.ortps_percentage,
					  s.total_payment_amount
					FROM status_counts s
					JOIN diff_summary d
					  ON s.routinglocationid = d.routinglocationid
					WHERE s.routinglocationid IN (:main_lgd)
					""",
		    nativeQuery = true
		)
		List<Map<String, Object>> getcountApplication(@Param("main_lgd") List<String> main_lgd,@Param("startDate") String startDate,@Param("endDate") String endDate);

	
}
