package in.nic.edistdash.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import in.nic.edistdash.entities.PcpndtServiceData;

public interface PcpndtServiceDao extends JpaRepository<PcpndtServiceData, String> {
	
	    //@Query("SELECT * FROM PcpndtServiceData")
		//@Query("select distinct baseservice_id from EnergyServiceData")
		//List<Object>getPcpndtserviceDetails();
	    @Query(value="SELECT a.routinglocationid AS routinglocationid,a.routinglocationname AS routinglocationname, COUNT(DISTINCT efd.appl_id) AS total_applications, COUNT(DISTINCT CASE WHEN efd.status = 'Deliver' THEN efd.appl_id END) AS delivercount, COUNT(DISTINCT CASE WHEN efd.status = 'Forward' THEN efd.appl_id END) AS forwardcount, COUNT(DISTINCT CASE WHEN efd.status = 'Reject' THEN efd.appl_id END) AS rejectcount, COUNT(DISTINCT CASE WHEN efd.status IN ('Deliver', 'Forward', 'Reject') THEN efd.appl_id END) AS appliedcount, (SUM(COALESCE(CAST(a.payment_amount AS NUMERIC), 0)) + SUM(COALESCE(CAST(efd.payment_amount AS NUMERIC), 0))) AS total_payment_amount, COUNT(DISTINCT CASE WHEN (efd.status = 'Forward' AND to_date(a.due_date, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS')) THEN efd.appl_id END) AS ortpscount,COUNT(DISTINCT CASE WHEN (efd.status = 'Deliver' AND to_date(a.due_date, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS')) THEN efd.appl_id END) AS ortpsdelivercount, CASE WHEN COUNT(DISTINCT CASE WHEN efd.status = 'Forward' THEN efd.appl_id END) > 0 AND COUNT(DISTINCT CASE WHEN (efd.status = 'Forward' AND to_date(a.due_date, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS')) THEN efd.appl_id END) > 0 THEN ROUND(COUNT(DISTINCT CASE WHEN (efd.status = 'Forward' AND to_date(a.due_date, 'YYYY-MM-DD') < to_timestamp(efd.execution_time, 'DD-MM-YYYY HH24:MI:SS')) THEN efd.appl_id END) * 100.0 / COUNT(DISTINCT CASE WHEN efd.status = 'Forward' THEN efd.appl_id END), 2) ELSE 0.0 END AS ortps_percentage FROM (SELECT DISTINCT ON (appl_id) * FROM pcpndt_execution_filtered ORDER BY appl_id) efd JOIN pcpndt_initiated_data a ON a.appl_id = efd.appl_id JOIN pcpndt_service es ON es.baseservice_id = efd.baseservice_id GROUP BY es.baseservice_id, es.servicename,a.routinglocationname,a.routinglocationid ORDER BY total_applications DESC",nativeQuery=true)
	    List<Map<String, Object>>getEnergyAllcountByService();
	    
	    @Query("SELECT e.routinglocationid,e.routinglocationname FROM PcpndtServiceDistrict e")
		//@Query("select distinct baseservice_id from EnergyServiceData")
		List<Object>getPcpndtDistrictsDetails();
        
	    
}
