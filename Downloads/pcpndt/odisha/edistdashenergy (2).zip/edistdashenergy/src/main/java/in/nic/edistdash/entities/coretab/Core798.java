package in.nic.edistdash.entities.coretab;

import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;

import in.nic.edistdash.entities.BaseService;
import in.nic.edistdash.entities.Department;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Core798 {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	private long id;
	private String applId;
	@ManyToOne
	private BaseService baseService;

	@Column(columnDefinition = "text")
	private String initData;

	@Column(columnDefinition = "text")
	private String execData;

	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date creation;

}
