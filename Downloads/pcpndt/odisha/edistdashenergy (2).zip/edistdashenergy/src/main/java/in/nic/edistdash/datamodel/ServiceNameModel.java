package in.nic.edistdash.datamodel;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ServiceNameModel {

    private String serviceid;
    private String servicename;
    private Long delivercount;
    private Long forwardcount;
    private Long rejectcount;
    private Integer max_diff;
    private Integer min_diff;
    private Double avg_diff;
    private Double median_diff;
}
