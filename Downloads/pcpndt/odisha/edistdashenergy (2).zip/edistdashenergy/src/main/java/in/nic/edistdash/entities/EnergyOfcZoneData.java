package in.nic.edistdash.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "energy_ofc_zone_data")
public class EnergyOfcZoneData {
	 @Id  
		private String ofc_lgd_code;
		 private String ofc_office_name;
	    private String child_lgd_code;
	    private String child_office_name;
	    private String parent_lgd_code;
	    private String parent_office_name;
	    private String grand_lgd_code;
	    private String grand_office_name;
	    private String main_grand_lgd_code;
	    private String main_grand_office_name;
}
