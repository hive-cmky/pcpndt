package in.nic.edistdash.datamodel;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DistrictStatusModel {

    private String district;
    private String districtlgd;
    private Long delivercount;
    private Long forwardcount;
    private Long rejectcount;
    private Long appliedcount;
    private Long ortpscount;
    private Double ortps_percentage;
}
