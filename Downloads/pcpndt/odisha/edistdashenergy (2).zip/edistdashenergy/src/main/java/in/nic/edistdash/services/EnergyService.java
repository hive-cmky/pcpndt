package in.nic.edistdash.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nic.edistdash.datamodel.DistrictStatusModel;
import in.nic.edistdash.entities.EnergyExecuteData;
import in.nic.edistdash.entities.EnergyInitiatedData;
import in.nic.edistdash.entities.EnergyOfcZoneData;
import in.nic.edistdash.entities.EnergyServiceData;
import in.nic.edistdash.repository.EnergyExecutionDao;
import in.nic.edistdash.repository.EnergyFilteredExecDataDao;
import in.nic.edistdash.repository.EnergyInitiatedataDao;
import in.nic.edistdash.repository.EnergyOfcZoneDao;
import in.nic.edistdash.repository.EnergyOfficeDao;
import in.nic.edistdash.repository.EnergyServiceDao;

@Service
public class EnergyService {
	
	@Autowired
	private EnergyOfficeDao energyofficeDao;
	
	@Autowired
	private EnergyInitiatedataDao energyinitdao;
	
	@Autowired
	private EnergyOfcZoneDao energyofczonedao;
	
	@Autowired
	private EnergyFilteredExecDataDao energyfilterexeczonedao;
	
	@Autowired
	private EnergyServiceDao energyserviceDao;
	@Autowired
	private EnergyExecutionDao energyexecutioDao;
	
	 public List<Object> getEnergyserviceDetails(){
	        return energyserviceDao.getEnergyserviceDetails();
	    }
	 public List<Map<String, Object>> getEnergyAllcountByService() {
		    List<Map<String, Object>> result = energyserviceDao.getEnergyAllcountByService();
		    
//		    List<Map<String, Object>> cleanedResult = new ArrayList<>();
//		    
//		    for (Map<String, Object> map : result) {
//		        Map<String, Object> cleanedMap = new LinkedHashMap<>();
//		        
//		        for (Map.Entry<String, Object> entry : map.entrySet()) {
//		            String key = entry.getKey();
//		            Object value = entry.getValue();
//
//		            if (key == null) {
//		                System.out.println("Null key found in result set: " + map);
//		                continue; // Skip null keys
//		            }
//
//		            cleanedMap.put(key, value != null ? value : 0); // Replace null values with 0
//		        }
//		        
//		        cleanedResult.add(cleanedMap);
//		    }
		    
		    return result;
		}

	   public List<Object> getDistinctOfcByservice(Map<String, Object> requestBody) {
		  
	    	List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
	         List<Object> list = null;
	        list= energyinitdao.getDistinctOfcByservice(serviceIds);
	        return list;
	    }

		/*
		 * public List<Object> getDistinctMainGrandZoneByservice(Map<String, Object>
		 * requestBody) {
		 * 
		 * List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		 * List<Object> list = null; list=
		 * energyinitdao.getDistinctMainGrandZoneByservice(serviceIds); return list; }
		 */
	   public List<Object> getDistinctParentZoneByserviceAndgrandLgd(Map<String, Object> requestBody) {
			  
	    	List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
	    	List<String> zoneIds = (List<String>) requestBody.get("grand_lgd");
	         List<Object> list = null;
	        list= energyinitdao.getDistinctParentZoneByserviceAndgrandLgd(serviceIds,zoneIds);
	        return list;
	    }
	   public List<Object> getDistinctChildZoneByserviceAndparentLgd(Map<String, Object> requestBody) {
			  
	    	List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
	    	List<String> zoneIds = (List<String>) requestBody.get("parent_lgd");
	         List<Object> list = null;
	        list= energyinitdao.getDistinctChildZoneByserviceAndparentLgd(serviceIds,zoneIds);
	        return list;
	    }
	   public List<Object> getDistinctGrandZoneByserviceAndMainzone(Map<String, Object> requestBody) {
			  
	    	List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
	    	List<String> zoneIds = (List<String>) requestBody.get("zoneid");
	         List<Object> list = null;
	        list= energyinitdao.getDistinctGrandZoneByserviceAndMainzone(serviceIds,zoneIds);
	        return list;
	    }
	   public List<Object> getDistinctOfcByserviceAndZone(Map<String, Object> requestBody) {
			  
	    	List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
	    	List<String> zoneIds = (List<String>) requestBody.get("zoneIds");
	         List<Object> list = null;
	        list= energyinitdao.getDistinctOfcByserviceAndZone(serviceIds,zoneIds);
	        return list;
	    }
	   public List<Object> getEnergyAllCountByserviceAndMainzone(Map<String, Object> requestBody) {
			  
	    	List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
	    	List<String> main_lgd = (List<String>) requestBody.get("main_lgd");
	         List<Object> list = null;
	        list= energyinitdao.getEnergyAllCountByserviceAndMainzone(serviceIds,main_lgd);
	        return list;
	    }
	   public List<Map<String, Object>> getDistinctCountByserviceandmainZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandmainZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());

		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getEnergyForwardAndDeliverAndRejectAndPaymentCountByServiceAndZone(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getDistinctCountByserviceandgrandZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandgrandZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());

		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getEnergyForwardAndDeliverAndRejectAndPaymentCountByServiceAndgrandZone(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getDistinctCountByserviceandparentZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandparentZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());

		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getEnergyForwardAndDeliverAndRejectAndPaymentCountByServiceAndparentZone(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getDistinctCountByserviceandchildZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandchildZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());

		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getEnergyForwardAndDeliverAndRejectAndPaymentCountByServiceAndchildZone(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getDistinctCountByserviceandofcZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandofcZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());

		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getEnergyForwardAndDeliverAndRejectAndPaymentCountByServiceAndofcZone(serviceIds, mergedList);


		    return applList;

		}

	   

	   public List<Object> getEnergyAllCountByserviceAndGrandzone(Map<String, Object> requestBody) {
			  
	    	List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
	    	List<String> grand_lgd = (List<String>) requestBody.get("grand_lgd");
	         List<Object> list = null;
	        list= energyinitdao.getEnergyAllCountByserviceAndGrandzone(serviceIds,grand_lgd);
	        return list;
	    }
	   public List<Object> getEnergyAllCountByserviceAndParentzone(Map<String, Object> requestBody) {
			  
	    	List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
	    	List<String> parent_lgd = (List<String>) requestBody.get("parent_lgd");
	         List<Object> list = null;
	        list= energyinitdao.getEnergyAllCountByserviceAndParentzone(serviceIds,parent_lgd);
	        return list;
	    }
	   public List<Object> getEnergyAllCountByserviceAndChildzone(Map<String, Object> requestBody) {
			  
	    	List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
	    	List<String> child_lgd = (List<String>) requestBody.get("child_lgd");
	         List<Object> list = null;
	        list= energyinitdao.getEnergyAllCountByserviceAndChildzone(serviceIds,child_lgd);
	        return list;
	    }
	   public List<Object> getEnergyAllCountByserviceAndOfczone(Map<String, Object> requestBody) {
			  
	    	List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
	    	List<String> ofc_lgd = (List<String>) requestBody.get("ofc_lgd");
	         List<Object> list = null;
	        list= energyinitdao.getEnergyAllCountByserviceAndOfczone(serviceIds,ofc_lgd);
	        return list;
	    }
	   public List<EnergyExecuteData> getEnergyrejectCount(){
	        return energyexecutioDao.getEnergyrejectCount();
	    }
	   public List<EnergyExecuteData> getEnergyForwardCount(){
	        return energyexecutioDao.getEnergyForwardCount();
	    }
	   public List<EnergyExecuteData> getEnergyDeliverCount(){
	        return energyexecutioDao.getEnergyDeliverCount();
	    }
	   
	   public List<Object> getEnergyForwardAndDeliverAndRejectCount(){
	        return energyexecutioDao.getEnergyForwardAndDeliverAndRejectCount();
	    }
	   public List<Object> getEnergyForwardAndDeliverAndRejectCountByService(Map<String, Object> requestBody) {
			  
	    	List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
	    	
	         List<Object> list = null;
	        list= energyexecutioDao.getEnergyForwardAndDeliverAndRejectCountByService(serviceIds);
	        return list;
	    }
	   public List<Object> getEnergyPaymentCount(){
	        return energyinitdao.getEnergyPaymentCount();
	    }
	   public List<Object> getEnergyPaymentCountByservice(Map<String, Object> requestBody) {
			  
	    	List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
	    	
	         List<Object> list = null;
	        list= energyinitdao.getEnergyPaymentCountByservice(serviceIds);
	        return list;
	    }
	   public List<Map<String, Object>> findMaxMinTimeByService() {
			  
	    	
	    	
	         List<Map<String, Object>> list = null;
	        list= energyinitdao.findMaxMinTimeByService();
	        return list;
	    }
	   
	   public Map<String, Object> findApplication(Map<String, Object> requestBody) {
		    Object appIdsObj = requestBody.get("applicationIds");
		    List<String> applicationIds;

		    if (appIdsObj instanceof String) {
		        // If applicationIds is a single string, split by commas
		        applicationIds = Arrays.asList(((String) appIdsObj).split("\\s*,\\s*"));
		    } else if (appIdsObj instanceof List) {
		        applicationIds = (List<String>) appIdsObj;
		    } else {
		        throw new IllegalArgumentException("Invalid applicationIds format");
		    }

		    // Fetch applications
		    List<Object> resultList = energyinitdao.getApplicationByAppRefNO(applicationIds);

		    // Process and clean results
		    List<String> mergedList = resultList.stream()
		        .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		        .filter(Objects::nonNull)
		        .map(Object::toString)
		        .filter(str -> !str.trim().isEmpty())
		        .distinct()
		        .collect(Collectors.toList());
		    System.out.println("Merged List: " + mergedList);

		    List<Object> execution = energyexecutioDao.getApplicationByApplicationId(mergedList);
		    List<Object> applList2 = energyinitdao.getApplicationByApplicationId(mergedList);

		    // Handle null cases by initializing empty lists
		    if (execution == null) execution = new ArrayList<>();
		    if (applList2 == null) applList2 = new ArrayList<>();

		    // Create response map
		    Map<String, Object> response = new HashMap<>();
		    
		    if (!execution.isEmpty()) {
		        response.put("execution", execution);
		    }
		    if (!applList2.isEmpty()) {
		        response.put("initiate", applList2);
		    }
		    
		    // If no data found, return message
		    if (response.isEmpty()) {
		        response.put("message", "No data found");
		    }

		    return response;
		}

	   public List<Map<String, Object>> getMaxMinCountByServiceAndLgd(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandmainZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getMaxMinCountByServiceAndApplicationId(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getMaxMinCountByServiceAndgrandZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandgrandZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getMaxMinCountByServiceAndApplicationId(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getMaxMinCountByServiceAndparentZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandparentZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getMaxMinCountByServiceAndApplicationId(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getMaxMinCountByServiceAndchildZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandchildZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getMaxMinCountByServiceAndApplicationId(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getMaxMinCountByServiceAndofcZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandofcZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getMaxMinCountByServiceAndApplicationId(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingDataByserviceId(String id){
	        return energyfilterexeczonedao.getpendingDataByserviceId(id);
	    }
	   public List<Map<String, Object>> getpendingOrtpsDataByserviceId(String id){
	        return energyfilterexeczonedao.getpendingOrtpsDataByserviceId(id);
	    }

	   public List<Map<String, Object>> getDrawingApprovalDataByserviceId(String id){
	        return energyfilterexeczonedao.getDrawingApprovalDataByserviceId(id);
	    }
	   public List<Map<String, Object>> getPendingDrawingApprovalDataByserviceId(String id){
	        return energyfilterexeczonedao.getPendingDrawingApprovalDataByserviceId(id);
	    }
	   public List<Map<String, Object>> getRejectDrawingApprovalDataByserviceId(String id){
	        return energyfilterexeczonedao.getRejectDrawingApprovalDataByserviceId(id);
	    }
	   public List<Map<String, Object>> getDeliverDrawingApprovalDataByserviceId(String id){
	        return energyfilterexeczonedao.getDeliverDrawingApprovalDataByserviceId(id);
	    }
	   public List<Map<String, Object>> getDGsetDataByserviceId(String id){
	        return energyfilterexeczonedao.getDGsetDataByserviceId(id);
	    }
	   public List<Map<String, Object>> getRejectDGsetDataByserviceId(String id){
	        return energyfilterexeczonedao.getRejectDGsetDataByserviceId(id);
	    }
	   public List<Map<String, Object>> getDeliverDGsetDataByserviceId(String id){
	        return energyfilterexeczonedao.getDeliverDGsetDataByserviceId(id);
	    }
	   public List<Map<String, Object>> getOrtpsDGsetDataByserviceId(String id){
	        return energyfilterexeczonedao.getOrtpsDGsetDataByserviceId(id);
	    }
	   public List<Map<String, Object>> getBeyondDeliverDGsetDataByserviceId(String id){
	        return energyfilterexeczonedao.getBeyondDeliverDGsetDataByserviceId(id);
	    }
	   public List<Map<String, Object>> getBeyondDeliverDrawingApprovalDataByserviceId(String id){
	        return energyfilterexeczonedao.getBeyondDeliverDrawingApprovalDataByserviceId(id);
	    }
	   public List<Map<String, Object>> getOrtpsDrawingApprovalDataByserviceId(String id){
	        return energyfilterexeczonedao.getOrtpsDrawingApprovalDataByserviceId(id);
	    }
	   public List<Map<String, Object>> getPendingDGsetDataByserviceId(String id){
	        return energyfilterexeczonedao.getPendingDGsetDataByserviceId(id);
	    }

	   public List<Map<String, Object>> getpendingDataByserviceIdAndMainZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandmainZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingDataByserviceIdAndZone(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingTaskDataByserviceIdAndUsernameAndMainZone(Map<String, Object> requestBody) {

		  
		    List<String> serviceIdsRaw = (List<String>) requestBody.get("serviceIds");

		 // Ensure each element is split by "," and collected properly
		 List<String> serviceIds = serviceIdsRaw.stream()
		         .flatMap(id -> Arrays.stream(id.split(","))) // Split each element by ","
		         .map(String::trim) // Trim any extra spaces
		         .filter(s -> !s.isEmpty()) // Remove empty values
		         .collect(Collectors.toList());
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");
		    String user_name =  (String) requestBody.get("user_name");
		    
		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandmainZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingTaskDataByserviceIdAndUsernameAndZone(serviceIds, mergedList,user_name);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingTaskDataByserviceIdAndUsernameAndGrandZone(Map<String, Object> requestBody) {

			  
		    List<String> serviceIdsRaw = (List<String>) requestBody.get("serviceIds");

		 // Ensure each element is split by "," and collected properly
		 List<String> serviceIds = serviceIdsRaw.stream()
		         .flatMap(id -> Arrays.stream(id.split(","))) // Split each element by ","
		         .map(String::trim) // Trim any extra spaces
		         .filter(s -> !s.isEmpty()) // Remove empty values
		         .collect(Collectors.toList());
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");
		    String user_name =  (String) requestBody.get("user_name");
		    
		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandgrandZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingTaskDataByserviceIdAndUsernameAndZone(serviceIds, mergedList,user_name);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingTaskDataByserviceIdAndUsernameAndParentZone(Map<String, Object> requestBody) {

			  
		    List<String> serviceIdsRaw = (List<String>) requestBody.get("serviceIds");

		 // Ensure each element is split by "," and collected properly
		 List<String> serviceIds = serviceIdsRaw.stream()
		         .flatMap(id -> Arrays.stream(id.split(","))) // Split each element by ","
		         .map(String::trim) // Trim any extra spaces
		         .filter(s -> !s.isEmpty()) // Remove empty values
		         .collect(Collectors.toList());
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");
		    String user_name =  (String) requestBody.get("user_name");
		    
		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandparentZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingTaskDataByserviceIdAndUsernameAndZone(serviceIds, mergedList,user_name);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingTaskDataByserviceIdAndUsernameAndChildZone(Map<String, Object> requestBody) {

			  
		    List<String> serviceIdsRaw = (List<String>) requestBody.get("serviceIds");

		 // Ensure each element is split by "," and collected properly
		 List<String> serviceIds = serviceIdsRaw.stream()
		         .flatMap(id -> Arrays.stream(id.split(","))) // Split each element by ","
		         .map(String::trim) // Trim any extra spaces
		         .filter(s -> !s.isEmpty()) // Remove empty values
		         .collect(Collectors.toList());
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");
		    String user_name =  (String) requestBody.get("user_name");
		    
		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandchildZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingTaskDataByserviceIdAndUsernameAndZone(serviceIds, mergedList,user_name);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingTaskDataByserviceIdAndUsernameAndOfcZone(Map<String, Object> requestBody) {

			  
		    List<String> serviceIdsRaw = (List<String>) requestBody.get("serviceIds");

		 // Ensure each element is split by "," and collected properly
		 List<String> serviceIds = serviceIdsRaw.stream()
		         .flatMap(id -> Arrays.stream(id.split(","))) // Split each element by ","
		         .map(String::trim) // Trim any extra spaces
		         .filter(s -> !s.isEmpty()) // Remove empty values
		         .collect(Collectors.toList());
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");
		    String user_name =  (String) requestBody.get("user_name");
		    
		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandofcZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingTaskDataByserviceIdAndUsernameAndZone(serviceIds, mergedList,user_name);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndUsernameAndMainZone(Map<String, Object> requestBody) {

			  
		    List<String> serviceIdsRaw = (List<String>) requestBody.get("serviceIds");

		 // Ensure each element is split by "," and collected properly
		 List<String> serviceIds = serviceIdsRaw.stream()
		         .flatMap(id -> Arrays.stream(id.split(","))) // Split each element by ","
		         .map(String::trim) // Trim any extra spaces
		         .filter(s -> !s.isEmpty()) // Remove empty values
		         .collect(Collectors.toList());
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");
		    String user_name =  (String) requestBody.get("user_name");
		    
		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandmainZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingOrtpsDataByserviceIdAndUsernameAndZone(serviceIds, mergedList,user_name);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndUsernameAndGrandZone(Map<String, Object> requestBody) {

			  
		    List<String> serviceIdsRaw = (List<String>) requestBody.get("serviceIds");

		 // Ensure each element is split by "," and collected properly
		 List<String> serviceIds = serviceIdsRaw.stream()
		         .flatMap(id -> Arrays.stream(id.split(","))) // Split each element by ","
		         .map(String::trim) // Trim any extra spaces
		         .filter(s -> !s.isEmpty()) // Remove empty values
		         .collect(Collectors.toList());
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");
		    String user_name =  (String) requestBody.get("user_name");
		    
		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandgrandZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingOrtpsDataByserviceIdAndUsernameAndZone(serviceIds, mergedList,user_name);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndUsernameAndParentZone(Map<String, Object> requestBody) {

			  
		    List<String> serviceIdsRaw = (List<String>) requestBody.get("serviceIds");

		 // Ensure each element is split by "," and collected properly
		 List<String> serviceIds = serviceIdsRaw.stream()
		         .flatMap(id -> Arrays.stream(id.split(","))) // Split each element by ","
		         .map(String::trim) // Trim any extra spaces
		         .filter(s -> !s.isEmpty()) // Remove empty values
		         .collect(Collectors.toList());
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");
		    String user_name =  (String) requestBody.get("user_name");
		    
		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandparentZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingOrtpsDataByserviceIdAndUsernameAndZone(serviceIds, mergedList,user_name);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndUsernameAndChildZone(Map<String, Object> requestBody) {

			  
		    List<String> serviceIdsRaw = (List<String>) requestBody.get("serviceIds");

		 // Ensure each element is split by "," and collected properly
		 List<String> serviceIds = serviceIdsRaw.stream()
		         .flatMap(id -> Arrays.stream(id.split(","))) // Split each element by ","
		         .map(String::trim) // Trim any extra spaces
		         .filter(s -> !s.isEmpty()) // Remove empty values
		         .collect(Collectors.toList());
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");
		    String user_name =  (String) requestBody.get("user_name");
		    
		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandchildZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingOrtpsDataByserviceIdAndUsernameAndZone(serviceIds, mergedList,user_name);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndUsernameAndOfcZone(Map<String, Object> requestBody) {

			  
		    List<String> serviceIdsRaw = (List<String>) requestBody.get("serviceIds");

		 // Ensure each element is split by "," and collected properly
		 List<String> serviceIds = serviceIdsRaw.stream()
		         .flatMap(id -> Arrays.stream(id.split(","))) // Split each element by ","
		         .map(String::trim) // Trim any extra spaces
		         .filter(s -> !s.isEmpty()) // Remove empty values
		         .collect(Collectors.toList());
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");
		    String user_name =  (String) requestBody.get("user_name");
		    
		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandofcZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingOrtpsDataByserviceIdAndUsernameAndZone(serviceIds, mergedList,user_name);


		    return applList;

		}
	   public List<Map<String, Object>> getPendingTaskDataByUsername(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    String user_name =  (String) requestBody.get("user_name");

		  // List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandmainZone(main_lgd);

		   
//		    List<String> mergedList = resultList.stream()
//		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
//		            .filter(Objects::nonNull) // Remove null values
//		            .map(Object::toString)  
//		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
//		            .distinct()  
//		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getPendingTaskDataByUsername(serviceIds, user_name);


		    return applList;

		}
	   public List<Map<String, Object>> getPendingOrtpsTaskDataByUsername(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    String user_name =  (String) requestBody.get("user_name");

		  // List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandmainZone(main_lgd);

		   
//		    List<String> mergedList = resultList.stream()
//		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
//		            .filter(Objects::nonNull) // Remove null values
//		            .map(Object::toString)  
//		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
//		            .distinct()  
//		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getPendingOrtpsTaskDataByUsername(serviceIds, user_name);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingDataByserviceIdAndGrandZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandgrandZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingDataByserviceIdAndZone(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingDataByserviceIdAndParentZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandparentZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingDataByserviceIdAndZone(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingDataByserviceIdAndChildZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandchildZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingDataByserviceIdAndZone(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingDataByserviceIdAndOfcZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandofcZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingDataByserviceIdAndZone(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndMainZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandmainZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingOrtpsDataByserviceIdAndZone(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndGrandZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandgrandZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingOrtpsDataByserviceIdAndZone(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndParentZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandparentZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingOrtpsDataByserviceIdAndZone(serviceIds, mergedList);


		    return applList;

		}
	   public List<Map<String, Object>> getpendingOrtpsDataByserviceIdAndChildZone(Map<String, Object> requestBody) {

		    List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		    List<String> main_lgd = (List<String>) requestBody.get("main_lgd");

		   List<Object> resultList = energyofczonedao.getDistinctlgdCodeByserviceandchildZone(main_lgd);

		   
		    List<String> mergedList = resultList.stream()
		            .flatMap(obj -> obj instanceof Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		            .filter(Objects::nonNull) // Remove null values
		            .map(Object::toString)  
		            .filter(str -> !str.trim().isEmpty()) // Remove empty strings
		            .distinct()  
		            .collect(Collectors.toList());
		 
		    
		    List<Map<String, Object>> applList = energyfilterexeczonedao.getpendingOrtpsDataByserviceIdAndZone(serviceIds, mergedList);


		    return applList;

		}
		/*
		 * public List<Map<String, Object>>
		 * getpendingOrtpsDataByserviceIdAndOfcZone(Map<String, Object> requestBody) {
		 * 
		 * List<String> serviceIds = (List<String>) requestBody.get("serviceIds");
		 * List<String> main_lgd = (List<String>) requestBody.get("main_lgd");
		 * 
		 * List<Object> resultList =
		 * energyofczonedao.getDistinctlgdCodeByserviceandofcZone(main_lgd);
		 * 
		 * 
		 * List<String> mergedList = resultList.stream() .flatMap(obj -> obj instanceof
		 * Object[] ? Arrays.stream((Object[]) obj) : Stream.of(obj))
		 * .filter(Objects::nonNull) // Remove null values .map(Object::toString)
		 * .filter(str -> !str.trim().isEmpty()) // Remove empty strings .distinct()
		 * .collect(Collectors.toList());
		 * 
		 * 
		 * List<Map<String, Object>> applList =
		 * energyfilterexeczonedao.getpendingOrtpsDataByserviceIdAndZone(serviceIds,
		 * mergedList);
		 * 
		 * 
		 * return applList;
		 * 
		 * }
		 */
}
