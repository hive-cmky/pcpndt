package in.nic.edistdash.services;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import in.nic.edistdash.datamodel.ApprovedStatusModel;
import in.nic.edistdash.datamodel.FindStatusModel;
import in.nic.edistdash.datamodel.PendingStatusModel;
import in.nic.edistdash.datamodel.RejectedStatusModel;
import in.nic.edistdash.entities.District;
import in.nic.edistdash.repository.DistrictRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import in.nic.edistdash.entities.PndtData;
import in.nic.edistdash.repository.PndtDataRep;

@Service
public class PndtService {
	@Autowired
	private PndtDataRep pndtdataRep;

	private DistrictRepo districtRepo;

	private District district;

	public List<PndtData> getAllData() {

		return pndtdataRep.findAll();
	}

	public long getPndtCount() {
		return pndtdataRep.count();
	}

	public List<PndtData> getPendingData() {

		return pndtdataRep.findPendingPndData();
	}

	public Object getCountPendingData() {
		return pndtdataRep.countPendingPndData();
	}



	public List<PndtData> findRejectedPndData(){
		return pndtdataRep.findRejectPndData();
	}

	public Object countRejectPndData() {
		return pndtdataRep.countRejectPndData();
	}

	public List<PndtData> findApprovedPndData() {

		return pndtdataRep.findApprovedPndData();

	}

	public Object countApprovedPndData() {
		return pndtdataRep.countApprovedPndData();
	}

	// Shaswat Starts //

	public List<PndtData> findRenewalPndData() {
		return pndtdataRep.findRenewalPndData();
	}

	public Object countRenewalPndData() {
		return pndtdataRep.countRenewalPndData();
	}

	public List<PndtData> findNewRegistrationPndData() {
		return pndtdataRep.findNewRegistrationPndData();
	}

	public Object countNewRegistrationPndData() {
		return pndtdataRep.countNewRegistrationPndData();
	}

	public List<PndtData> findFreshApplicationPndData() {
		return pndtdataRep.findFreshApplicationPndData();
	}

	public Object countFreshApplicationPndData() {
		return pndtdataRep.countFreshApplicationPndData();
	}

	public List<PndtData> findReapplyPndData() {
		return pndtdataRep.findReapplyPndData();
	}

	public Object countReapplyPndData() {
		return pndtdataRep.countReapplyPndData();
	}

	public List<PndtData> findapplyFormBPndData() {
		return pndtdataRep.findapplyFormBPndData();
	}

	public Object countapplyFormBPndData() {
		return pndtdataRep.countapplyFormBPndData();
	}

	public List<PndtData> findRegisterPndData() {
		return pndtdataRep.findRegisterPndData();
	}

	public Object countRegisterPndData() {
		return pndtdataRep.countRegisterPndData();
	}

	public List<FindStatusModel> countTotalApplicationByDistrict() {

		List<Map<String, Object>> result = pndtdataRep.findStatusDistrictWise();
		List<FindStatusModel> listt = new ArrayList<>();

		for (Map<String, Object> row : result) {
			FindStatusModel abc = new FindStatusModel();
			abc.setDistrict((String) row.get("district"));
			abc.setDistadmin((String) row.get("distadmin"));
//			abc.setStatus((String) row.get("status"));
//			abc.setCount((Long) row.get("count"));
			listt.add(abc);
		}
		return listt;
	}

	public List<FindStatusModel> countTotalDeliveredByDistrict() {

		List<Map<String, Object>> result = pndtdataRep.countTotalAppliedRejectedPendingApproved();
		List<FindStatusModel> listt = new ArrayList<>();

		for (Map<String, Object> row : result) {
			FindStatusModel abc = new FindStatusModel();
			abc.setDistrict((String) row.get("district"));
			abc.setDistadmin((String) row.get("distadmin"));
			abc.setTotalapplied((Long) row.get("totalapplied"));
			abc.setCountrjct((Long) row.get("countrjct"));
			abc.setCountdel((Long) row.get("countdel"));
			abc.setCountpen((Long) row.get("countpen"));
			listt.add(abc);
		}
		return listt;
	}

	public List<ApprovedStatusModel> findApprovedByDistrictWise() {
		List<Map<String, Object>> result = pndtdataRep.countApprovedByDistrictWise();
		List<ApprovedStatusModel> efg = new ArrayList<>();

		for (Map<String, Object> row : result){
			ApprovedStatusModel abc = new ApprovedStatusModel();
			abc.setDistrict((String) row.get("district"));
			abc.setDistadmin((String) row.get("distadmin"));
			abc.setTotalapplied((Long) row.get("totalapplied"));
			abc.setCountdel((Long) row.get("countdel"));
			efg.add(abc);
		}
		return efg;
	}

	public List<PendingStatusModel> findpendingbydistrictwise(){
		List<Map<String, Object>> result = pndtdataRep.counUnderProcessByDistrictWise();
		List<PendingStatusModel> abc = new ArrayList<>();

		for(Map<String, Object> row : result){
			PendingStatusModel efg = new PendingStatusModel();
			efg.setDistrict((String) row.get("district"));
			efg.setDistadmin((String) row.get("distadmin"));
			efg.setTotalapplied((Long) row.get("totalapplied"));
			efg.setCountpen((Long) row.get("countpen"));
			abc.add(efg);
		}
		return abc;
	}

	public List<RejectedStatusModel> findrjctbydistrictwise(){
		List<Map<String, Object>> result = pndtdataRep.countrjctbydistrictwise();
		List<RejectedStatusModel> abc = new ArrayList<>();

		for(Map<String, Object> row : result){
			RejectedStatusModel efg = new RejectedStatusModel();
			efg.setDistrict((String) row.get("district"));
			efg.setDistadmin((String) row.get("distadmin"));
			efg.setTotalapplied((Long) row.get("totalapplied"));
			efg.setCountreject((Long) row.get("countreject"));
			abc.add(efg);
		}
		return abc;
	}


	public List<FindStatusModel> countTotalUnderProcessByDistrict() {

		List<Map<String, Object>> result = pndtdataRep.findStatusUnderProcessDistrictWise();
		List<FindStatusModel> listt = new ArrayList<>();

		for (Map<String, Object> row : result) {
			FindStatusModel abc = new FindStatusModel();
			abc.setDistrict((String) row.get("district"));
			abc.setDistadmin((String) row.get("distadmin"));
//			abc.setStatus((String) row.get("status"));
//			abc.setCount((Long) row.get("count"));
			listt.add(abc);
		}
		return listt;
	}

	public List<FindStatusModel> countTotalRejectedByDistrict() {

		List<Map<String, Object>> result = pndtdataRep.findStatusRejectedDistrictWise();
		List<FindStatusModel> listt = new ArrayList<>();

		for (Map<String, Object> row : result) {
			FindStatusModel abc = new FindStatusModel();
			abc.setDistrict((String) row.get("district"));
			abc.setDistadmin((String) row.get("distadmin"));
//			abc.setStatus((String) row.get("status"));
//			abc.setCount((Long) row.get("count"));
			listt.add(abc);
		}
		return listt;
	}

	//new today

//	public List<Object> countAppliedRejectPendingApproved() {
//		return pndtdataRep.countTotalAppliedRejectedPendingApproved();
//	}

	public List<PndtData> totaldata(String id) {

		return pndtdataRep.findTotalapplieddistrict(Integer.parseInt(id));
	}

	public List<PndtData> penddata(String id){
		return pndtdataRep.findTotalPendbyDistrict(Integer.parseInt(id));
	}

	public List<PndtData> findRejectPndData(String id) {

		return pndtdataRep.findRejectPndData(Integer.parseInt(id));
	}

	public List<PndtData> findListApplied(String id){
		return pndtdataRep.findAppliedList(Integer.parseInt(id));
	}

	}

