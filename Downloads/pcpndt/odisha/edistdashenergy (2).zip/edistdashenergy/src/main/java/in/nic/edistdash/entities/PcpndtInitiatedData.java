package in.nic.edistdash.entities;



import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "pcpndt_initiated_data")
public class PcpndtInitiatedData {
	
	@Id
	private String service_id;
	private String base_service_id;
	private String appl_id;
	private String appl_ref_no;
	private String submission_location;
	private String submission_date;
	private String due_date;
	//private String routinglocation;
	private String payment_reference_no;
	private String payment_date;
	private String payment_amount;
	private String routinglocationid;
	private String routinglocationname;

}
