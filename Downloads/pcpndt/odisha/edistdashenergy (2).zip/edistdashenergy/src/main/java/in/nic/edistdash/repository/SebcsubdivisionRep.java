package in.nic.edistdash.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.nic.edistdash.entities.Sebcsubdivision;

public interface SebcsubdivisionRep extends JpaRepository<Sebcsubdivision, String> {
	
}
