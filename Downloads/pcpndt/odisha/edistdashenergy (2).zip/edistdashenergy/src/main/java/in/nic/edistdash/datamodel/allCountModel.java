package in.nic.edistdash.datamodel;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class allCountModel {

    private String district;
    private String currentmonthdistrictlgd;
    private String districtlgd;
    private Long currentmonth;
    private Long currentmonthapplicationreceived;
    private Long totalprocessed;
    private Long total_applications;
    private Long forward_count;
    private Long ortps_count;
}