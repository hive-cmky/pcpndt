$('#addDesignationForm').on('submit', function(e) {
    e.preventDefault();
    
    // Get input value and convert to array (splitting by commas)
    let appRefNos = $('#AppRefNo').val().split(/\s*,\s*/);  // Splits by commas & trims spaces

    $.ajax({
        type: "POST",
        url: "/findApplication",
        contentType: "application/json",
        data: JSON.stringify({ applicationIds: appRefNos }),  
        success: function(data) {
            console.log("Success:", data);
            if (data.initiate && data.initiate.length > 0) {
            let appref = data.initiate[0].applicationrefno;
            let duedate = data.initiate[0].duedate;
             let locname = data.initiate[0].routinglocationname;
                   let submloc = data.initiate[0].submilocation;
               let submdate = data.initiate[0].submissiondate;                      
            $("#appref").text(appref);       
            $("#duedate").text(duedate);
            $("#locname").text(locname);
            $("#submitloc").text(submloc);
            $("#submitdate").text(submdate);
            
             }


        if ($.fn.DataTable.isDataTable("#zonetbl")) {
            $("#zonetbl").DataTable().clear().destroy();
        }

        if (data.execution && data.execution.length > 0) {
            $("#zonetbl").DataTable({
                data: data.execution,
                   "columns": [
            {
                "data": [5], "className": "dt-head-center dt-body-center"
            },
            {
                "data": [3], "className": "dt-head-center dt-body-center"
            },
            {
                "data": [4], "className": "dt-head-center dt-body-center"
            },
            {
                "data": [8], "className": "dt-head-center dt-body-center"
            },
            {
                "data": [6], "className": "dt-head-center dt-body-center"
            },
            {
                "data": [7], "className": "dt-head-center dt-body-center"
            },
             {
                "data": [10], "className": "dt-head-center dt-body-center"
            }
          
        ],
         "order": [[5, "desc"]],
        	dom: 'Blftrip',
							buttons: [
								{
									extend: 'excelHtml5',
									text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
									titleAttr: 'Excel'
								},
								{
									extend: 'pdfHtml5',
									text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
									titleAttr: 'PDF'
								}
							],

                destroy: true
            });
        } 
            
            
            
        },
        error: function(jqXHR) {
            console.error("Error:", jqXHR.responseText);
        }
    });
});
let ofcDetail = $('#zonetbl').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            });