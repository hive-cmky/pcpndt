var TotalAppliedModal = new bootstrap.Modal(document.getElementById('editAppliedModal'));
var DeliveredModal = new bootstrap.Modal(document.getElementById('editDeliveredModal'));
var PendingModal = new bootstrap.Modal(document.getElementById('editPendingModal'));
var RejectModal = new bootstrap.Modal(document.getElementById('editRejectedModal'));

//adjusting column with the table body
function autoAdjustColumns(table) {
    var container = table.table().container();
    var resizeObserver = new ResizeObserver(function () {
        table.columns.adjust();
    });
    resizeObserver.observe(container);
}

let abcReport = $('#AllappliedData').DataTable({
            scrollX: true,
            scrollY: 300,
            });
let approvedReport = $('#allapproved').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            });
let pendingReport = $('#Allpending').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            });
let rejectReport = $('#rejected').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            });

let TotalDetail = $('#example').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            });
let TotalDeliveredDetail = $('#example2').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            });
let TotalPendingDetail = $('#example3').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            });
let TotalRejectDetail = $('#example4').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            });

let TotalApprovedAplReport = $('#apllist').DataTable({
                                                                    scrollCollapse: true,
                                                                    scrollY: 300,
                                                                    scrollX: true,
                                                                    });
var TotalApplReport = new bootstrap.Modal(document.getElementById('appl_Modal'));
let TotalApprovedReport = $('#approvedlist').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            });
var TotalApprovedReportModal = new bootstrap.Modal(document.getElementById('approv_Modal'));

let TotalPendingAplReport = $('#pendapllist').DataTable({
                   scrollCollapse: true,
                   scrollY: 300,
                   scrollX: true,
                   });
var TotalApplByPendingReport = new bootstrap.Modal(document.getElementById('pendingapplModal'));
let TotalPendingReport = $('#pendlist').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            });
var PendingReportModal = new bootstrap.Modal(document.getElementById('pending_Modal'));

let TotalRejectAplReport = $('#rejectapllist').DataTable({
                scrollCollapse: true,
                scrollY: 300,
                scrollX: true,
                });
var TotalApplByRejectReport = new bootstrap.Modal(document.getElementById('rejectaplModal'));
let TotalRejectReport = $('#rejectlist').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            });
var RejectReportModal = new bootstrap.Modal(document.getElementById('reject_Modal'));


async function fetchCounts() {
	// Make multiple AJAX requests to fetch the counts
	const [appliedCountResponse, pendingCountResponse, rejectCountResponse, approvedCountResponse] = await Promise.all([
		$.ajax({ type: "GET", url: "/getPndtCount" }),
		$.ajax({ type: "GET", url: "/getCountPendingData" }),
		$.ajax({ type: "GET", url: "/getcountRejectPndData" }),
		$.ajax({ type: "GET", url: "/getcountApprovedPndData" })
	]);

	// Retrieve the counts from the AJAX responses
	const appliedCount = appliedCountResponse;
	const pendingCount = pendingCountResponse;
	const rejectCount = rejectCountResponse;
	const approvedCount = approvedCountResponse;

	// Update the HTML elements with the counts
	$("#appliedCount").html(appliedCount);
	$("#pendingCount").html(pendingCount);
	$("#rejectCount").html(rejectCount);
	$("#approvedCount").html(approvedCount);

	// Create the pie chart with the fetched data
	createPieChart(appliedCount, pendingCount, rejectCount, approvedCount);
}

// Function to create a pie chart with given counts
function createPieChart(appliedCount, pendingCount, rejectCount, approvedCount) {
	const ctx = document.getElementById("myPieChart").getContext("2d");

	const data = {
		labels: ["Pending", "Rejected", "Approved"],
		datasets: [{
			data: [pendingCount, rejectCount, approvedCount],
			backgroundColor: ["#FF6384", "#36A2EB", "#FFCE56"]
		}]
	};

	new Chart(ctx, {
		type: "pie",
		data: data,
		options: {
			responsive: true,
			title: {
				display: true,
				text: `Application Distribution (Total: ${appliedCount})`
			}
		}
	});
}

// Call the fetchCounts function to retrieve the data and create the pie chart
fetchCounts();

    $.ajax({
	type: "GET",
	url: "/getApprovedPndData",
	success: function(data) {
		//console.log(data)

	}, error: function(jqXHR) {
		jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : ""
	}
});

let ApplData = $('#Appl_list').DataTable({
    scrollX: true,
    scrollY: 300,
	"ajax": {
		"url": "/pndtAllData",
		"type": "GET",
		"dataSrc": ""
	},

	"columns": [
		        { "data": "district" },
        		{ "data": "appl_ref" },
        		{ "data": "appl_name" },
        		{ "data": "submi_date" },
        		{ "data": "clinic_name" },
        		{ "data": "appl_type" },
        		{ "data": "institute_type" },
        		{ "data": "owner_type" },
        		{ "data": "amount" },
        		{ "data": "payment_date" },
        		{ "data": "payment_mode" },
        		{ "data": "reference" },
        		{ "data": "status" },
        		{ "data": "due_date" },
	],
	"createdRow": function(row, data, dataIndex){
	    var statusCell = $('td',row).eq(12);

	    if(data.status === "Rejected"){
	        statusCell.css('color','red');
	    }else if(data.status === "Under Process"){
	        statusCell.css('color','purple');
	    }else if(data.status === "Delivered"){
	        statusCell.css('color','green');
	    }
	}
});
autoAdjustColumns(ApplData)

let ApprovedData = $('#AllapprovedData').DataTable({
	scrollX: true,
    scrollY: 300,
	"ajax": {
		"url": "/getApprovedPndData",
		"type": "GET",
		"dataSrc": ""
	},
	"columns": [
		        { "data": "district" },
        		{ "data": "appl_ref" },
        		{ "data": "appl_name" },
        		{ "data": "submi_date" },
        		{ "data": "clinic_name" },
        		{ "data": "appl_type" },
        		{ "data": "institute_type" },
        		{ "data": "owner_type" },
        		{ "data": "amount" },
        		{ "data": "payment_date" },
        		{ "data": "payment_mode" },
        		{ "data": "reference" },
        		{ "data": "status" },
        		{ "data": "due_date" },
	],
});
autoAdjustColumns(ApprovedData)

let RejectData = $('#AllrejectData').DataTable({
	scrollX: true,
        scrollY: 300,
	"ajax": {
		"url": "/getRejectPndData",
		"type": "GET",
		"dataSrc": ""

	},

	"columns": [

		{ "data": "district" },
		{ "data": "appl_ref" },
		{ "data": "appl_name" },
		{ "data": "submi_date" },
		{ "data": "clinic_name" },
		{ "data": "appl_type" },
		{ "data": "institute_type" },
		{ "data": "owner_type" },
		{ "data": "amount" },
		{ "data": "payment_date" },
		{ "data": "payment_mode" },
		{ "data": "reference" },
		{ "data": "status" },
		{ "data": "due_date" },
	],
});
autoAdjustColumns(RejectData)

let PendingData = $('#AllpendingData').DataTable({
    scrollX: true,
    scrollY: 300,
	"ajax": {
		"url": "/getPendingData",
		"type": "GET",
		"dataSrc": ""

	},

	"columns": [

		{ "data": "district" },
		{ "data": "appl_ref" },
		{ "data": "appl_name" },
		{ "data": "submi_date" },
		{ "data": "clinic_name" },
		{ "data": "appl_type" },
		{ "data": "institute_type" },
		{ "data": "owner_type" },
		{ "data": "amount" },
		{ "data": "payment_date" },
		{ "data": "payment_mode" },
		{ "data": "reference" },
		{ "data": "status" },
		{ "data": "due_date" },
		{ "data": "timeline"}
	],
});
autoAdjustColumns(PendingData)


<!--DataTable Inside Modal -->

abcReport.destroy();
abcReport = $('#AllappliedData').DataTable({
         scrollX: true,
         scrollY: 300,
      "ajax": {
          "url": "/totalstatusbydistrict",
          "type":"GET",
          "dataSrc":""
          },

          "columns": [
                 {
                    "data": "district", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
                        return '<div id="distId" distLgd=" distadmin="' + full.distadmin + '">' + data + '</div>';
                   }
                 },
                 {
                 "data": "totalapplied", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta){
                    return '<div id="total" total_id="' + full.distadmin + '">' + data + '</div>';
                 }
                 },
                 {
                 "data": "countdel", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
                    return '<div id="deliver" deli_id="' + full.distadmin + '">' + data + '</div>';
                 }
                 },
                 {
                 "data": "countpen", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta){
                    return '<div id="pending" pend_id="' + full.distadmin + '">' + data + '</div>';
                 }
                 },
                 {
                 "data": "countrjct", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta){
                    return '<div id="reject" reject_id="' + full.distadmin + '">' + data + '</div>';
                 }
                 },
              ]
          });
     autoAdjustColumns(abcReport)
$('#AllappliedData').on('click', '#total, #deliver, #pending, #reject' , function() {
            var id = $(this).attr("total_id") || $(this).attr("deli_id") || $(this).attr("pend_id") || $(this).attr("reject_id");
								console.log(id);
                            var url;
								if ($(this).attr("id") === "total"){
								url = "/getAppliedList/" + id;
                                TotalDetail.destroy();
                                TotalDetail = $('#example').DataTable({
                                scrollX: true,
                                scrollY: 300,
                                "ajax": {
                                    "url": url,
                                    "type": "GET",
                                    "dataSrc": ""
                                },
                                "columns": [
                                { "data": "district" },
                                { "data": "appl_ref" },
                                { "data": "appl_name" },
                                { "data": "submi_date" },
                                { "data": "clinic_name" },
                                { "data": "appl_type" },
                                { "data": "institute_type" },
                                { "data": "owner_type" },
                                { "data": "amount" },
                                { "data": "payment_date" },
                                { "data": "payment_mode" },
                                { "data": "reference" },
                                { "data": "status" },
                                { "data": "due_date" }
                                ],
                                });
                                autoAdjustColumns(TotalDetail)
                                TotalAppliedModal.show();
								} else if ($(this).attr("id") === "deliver"){
								    url = "/totaldeliveredbydistrict/" + id;
								    TotalDeliveredDetail.destroy();
								    TotalDeliveredDetail = $('#example2').DataTable({
								    scrollX: true,
                                    scrollY: 300,
                                    "ajax": {
                                         "url":url,
                                         "type": "GET",
                                         "dataSrc": ""
                                         },
                                         "columns": [
                                         { "data": "district" },
                                         { "data": "appl_ref" },
                                         { "data": "appl_name" },
                                         { "data": "submi_date" },
                                    	 { "data": "clinic_name" },
                                         { "data": "appl_type" },
                                         { "data": "institute_type" },
                                         { "data": "owner_type" },
                                         { "data": "amount" },
                                         { "data": "payment_date" },
                                         { "data": "payment_mode" },
                                         { "data": "reference" },
                                         { "data": "status" },
                                         { "data": "due_date" }
                                         ],
								    });
                                autoAdjustColumns(TotalDeliveredDetail)
	                                DeliveredModal.show();
								} else if ($(this).attr("id") === "pending") {
								    url = "/totalpendingbydistrict/" + id;
								    TotalPendingDetail.destroy();
								    TotalPendingDetail = $('#example3').DataTable({
								            scrollX: true,
                                            scrollY: 300,
                                            "ajax": {
                                            "url": url,
                                            "type":"GET",
                                            "dataSrc": ""
                                            },
                                            "columns": [
                                            { "data": "district" },
                                            { "data": "appl_ref" },
                                            { "data": "appl_name" },
                                            { "data": "submi_date" },
                                            { "data": "clinic_name" },
                                            { "data": "appl_type" },
                                       	    { "data": "institute_type" },
                                       	    { "data": "owner_type" },
                                            { "data": "amount" },
                                            { "data": "payment_date" },
                                            { "data": "payment_mode" },
                                            { "data": "reference" },
                                            { "data": "status" },
                                            { "data": "due_date" }
                                            ],
								    });
								autoAdjustColumns(TotalPendingDetail)
								    PendingModal.show();
								} else if ($(this).attr("id") === "reject"){
								    url = "/getTotalRejectPndData/" + id;
                         		    TotalRejectDetail.destroy();
                                    TotalRejectDetail = $('#example4').DataTable({
              					            scrollX: true,
                                            scrollY: 300,
                                            "ajax": {
                                            "url": url,
                                            "type":"GET",
                                            "dataSrc": ""
                                            },
                                            "columns": [
                                             { "data": "district" },
                                             { "data": "appl_ref" },
                                             { "data": "appl_name" },
                                             { "data": "submi_date" },
                                             { "data": "clinic_name" },
                                             { "data": "appl_type" },
                                       	     { "data": "institute_type" },
                                             { "data": "owner_type" },
                                             { "data": "amount" },
                                             { "data": "payment_date" },
                                             { "data": "payment_mode" },
                                             { "data": "reference" },
                                             { "data": "status" },
                                             { "data": "due_date" }
                                             ],
                                             });
                                autoAdjustColumns(TotalRejectDetail)
                                             RejectModal.show();
								}
            });

approvedReport.destroy();
approvedReport = $('#allapproved').DataTable({
        scrollCollapse: true,
        scrollY: 300,
        scrollX: true,
        "ajax":{
            "url": "/countapproveddistrictwise",
            "type":"GET",
            "dataSrc":""
        },
        "columns":[
        {
            "data":"district", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta){
                return '<div id="distId" distLgd=" distadmin="' + full.distadmin + '">' + data + '</div>'
            }
        },
        {
            "data":"totalapplied", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta){
                return '<div id="appl" appl_id="' + full.distadmin + '">' + data + '</div>'
            }
        },
        {
            "data":"countdel", "className": "dt-head-center dt-body-center", "render":function(data, type, full, meta){
                return '<div id="delvr" delvr_id="' + full.distadmin + '">' + data + '</div>'
            }
        },
        ],
});
    autoAdjustColumns(approvedReport)
$('#allapproved').on('click', '#appl, #delvr', function(){
    var id = $(this).attr("appl_id") || $(this).attr("delvr_id")
    console.log(id);
    var url;
    if($(this).attr("id") === "appl"){
    url = "/getAppliedList/" + id;
        TotalApprovedAplReport.destroy();
        TotalApprovedAplReport = $('#apllist').DataTable({
            scrollCollapse: true,
            scrollX: true,
            scrollY: 300,
            "ajax": {
                "url": url,
                "type": "GET",
                "dataSrc": ""
            },
            "columns": [
                { "data": "district" },
                { "data": "appl_ref" },
                { "data": "appl_name" },
                { "data": "submi_date" },
                { "data": "clinic_name" },
                { "data": "appl_type" },
                { "data": "institute_type" },
                { "data": "owner_type" },
                { "data": "amount" },
                { "data": "payment_date" },
                { "data": "payment_mode" },
                { "data": "reference" },
                { "data": "status" },
                { "data": "due_date" }
            ],
        });
        autoAdjustColumns(TotalApprovedAplReport)
        TotalApplReport.show();
    } else if ($(this).attr("id") === "delvr"){
        url = "/totaldeliveredbydistrict/" + id;
        TotalApprovedReport.destroy();
        TotalApprovedReport = $('#approvedlist').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            "ajax": {
                "url": url,
                "type":"GET",
                "dataSrc": ""
            },
            "columns": [
               {"data": "district"},
               { "data": "appl_ref" },
               { "data": "appl_name" },
               { "data": "submi_date" },
               { "data": "clinic_name" },
               { "data": "appl_type" },
               { "data": "institute_type" },
               { "data": "owner_type" },
               { "data": "amount" },
               { "data": "payment_date" },
               { "data": "payment_mode" },
               { "data": "reference" },
               { "data": "status" },
               { "data": "due_date" }
            ],
        });
        autoAdjustColumns(TotalApprovedReport)
        TotalApprovedReportModal.show();
    }
});

pendingReport.destroy();
pendingReport = $('#All_pending').DataTable({
    scrollCollapse: true,
    scrollX:true,
    scrollY:300,
    "ajax": {
        "url": "/findpendbydistrictwise",
        "type": "GET",
        "dataSrc":""
    },

    "columns": [
        {
            "data": "district", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta){
                return '<div id="distId" distLgd=" distadmin="' + full.distadmin + '">' + data + '</div>';
            }
        },
        {
            "data":"totalapplied", "className": "dt-head-center dt-body-center", "render":function(data, type, full, meta){
                return '<div id="totalappl" total_id="' + full.distadmin + '">' + data + '</div>';
            }
        },
        {
            "data":"countpen", "className": "dt-head-center dt-body-center", "render":function(data, type, full, meta){
                return '<div id="pend" pend_id="' + full.distadmin + '">' + data + '</div>';
            }
        },
    ],
});
    autoAdjustColumns(pendingReport)
$('#All_pending').on('click', '#totalappl, #pend', function(){
    var id = $(this).attr("total_id") || $(this).attr("pend_id")
    console.log(id);
    var url;
    if($(this).attr("id") === "totalappl"){
    url = "/getAppliedList/" + id;
        TotalPendingAplReport.destroy();
        TotalPendingAplReport = $('#pendapllist').DataTable({
            scrollCollapse: true,
            scrollX: true,
            scrollY: 300,
            "ajax": {
                "url": url,
                "type": "GET",
                "dataSrc": ""
            },
            "columns": [
                { "data": "district" },
                { "data": "appl_ref" },
                { "data": "appl_name" },
                { "data": "submi_date" },
                { "data": "clinic_name" },
                { "data": "appl_type" },
                { "data": "institute_type" },
                { "data": "owner_type" },
                { "data": "amount" },
                { "data": "payment_date" },
                { "data": "payment_mode" },
                { "data": "reference" },
                { "data": "status" },
                { "data": "due_date" }
            ],
        });
        autoAdjustColumns(TotalPendingAplReport)
        TotalApplByPendingReport.show();
    } else if ($(this).attr("id") === "pend"){
        url= "/totalpendingbydistrict/" + id;
        TotalPendingReport.destroy();
        TotalPendingReport = $('#pendlist').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            "ajax": {
                "url": url,
                "type":"GET",
                "dataSrc": ""
            },
            "columns": [
               {"data": "district"},
               { "data": "appl_ref" },
               { "data": "appl_name" },
               { "data": "submi_date" },
               { "data": "clinic_name" },
               { "data": "appl_type" },
               { "data": "institute_type" },
               { "data": "owner_type" },
               { "data": "amount" },
               { "data": "payment_date" },
               { "data": "payment_mode" },
               { "data": "reference" },
               { "data": "status" },
               { "data": "due_date" }
            ],
        });
        autoAdjustColumns(TotalPendingReport)
        PendingReportModal.show();
    }
});

rejectReport.destroy();
rejectReport = $('#rejected').DataTable({
    scrollCollapse:true,
    scrollY:300,
    scrollX: true,
    "ajax": {
        "url": "/findrjctdistrictwise",
        "type": "GET",
        "dataSrc": ""
    },

    "columns":[
        {
            "data":"district", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta){
                return '<div id="distId" distLgd=" distadmin="' + full.distadmin + '">' + data + '</div>';
            }
        },
        {
            "data":"totalapplied", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta){
                return '<div id="totalapplied" total_id="' + full.distadmin + '">' + data + '</div>';
            }
        },
        {
            "data":"countreject", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta){
                return '<div id="countrjt" rej_id="' + full.distadmin + '">' + data + '</div>';
            }
        },
    ],
});
    autoAdjustColumns(rejectReport)
$('#rejected').on('click', '#totalapplied, #countrjt', function(){
    var id = $(this).attr("total_id") || $(this).attr("rej_id")
    console.log(id);
    var url;
    if($(this).attr("id") === "totalapplied"){
    url = "/getAppliedList/" + id;
        TotalRejectAplReport.destroy();
        TotalRejectAplReport = $('#rejectapllist').DataTable({
            scrollCollapse: true,
            scrollX: true,
            scrollY: 300,
            "ajax": {
                "url": url,
                "type": "GET",
                "dataSrc": ""
            },
            "columns": [
                { "data": "district" },
                { "data": "appl_ref" },
                { "data": "appl_name" },
                { "data": "submi_date" },
                { "data": "clinic_name" },
                { "data": "appl_type" },
                { "data": "institute_type" },
                { "data": "owner_type" },
                { "data": "amount" },
                { "data": "payment_date" },
                { "data": "payment_mode" },
                { "data": "reference" },
                { "data": "status" },
                { "data": "due_date" }
            ],
        });
        autoAdjustColumns(TotalRejectAplReport)
        TotalApplByRejectReport.show();
    } else if ($(this).attr("id") === "countrjt"){
        url= "/getTotalRejectPndData/" + id;
        TotalRejectReport.destroy();
        TotalRejectReport = $('#rejectlist').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            "ajax": {
                "url": url,
                "type":"GET",
                "dataSrc": ""
            },
            "columns": [
               {"data": "district"},
               { "data": "appl_ref" },
               { "data": "appl_name" },
               { "data": "submi_date" },
               { "data": "clinic_name" },
               { "data": "appl_type" },
               { "data": "institute_type" },
               { "data": "owner_type" },
               { "data": "amount" },
               { "data": "payment_date" },
               { "data": "payment_mode" },
               { "data": "reference" },
               { "data": "status" },
               { "data": "due_date" }
            ],
        });
        autoAdjustColumns(TotalRejectReport)
        RejectReportModal.show();
    }
});

$(window).on("load", function() {
	$('#approvedDatatable').hide();
	$('#pendingDatatable').hide();
	$('#rejectDatatable').hide();
	$('#appliedDatatable').hide();
	$('#appliedDetails').hide();
	$('#applDatatable').hide();
	$('#TotalapprovedDatatable').hide();
	$('#TotalPendingDatatable').hide();
	$('#TotalRejectedDatatable').hide();
})

$('#details').click(function(e) {
e.stopPropagation();
$('#applDatatable').toggle();
$('#appliedDatatable').hide();
$('#approvedDatatable').hide();
$('#pendingDatatable').hide();
$('#rejectDatatable').hide();
$('#TotalapprovedDatatable').hide();
$('#TotalRejectedDatatable').hide();
$('#TotalPendingDatatable').hide();
});

$('#details2').click(function(e) {
e.stopPropagation();
$('#approvedDatatable').toggle();
$('#appliedDatatable').hide();
$('#TotalapprovedDatatable').hide();
$('#rejectDatatable').hide();
$('#pendingDatatable').hide();
$('#TotalPendingDatatable').hide();
$('#TotalRejectedDatatable').hide();
$('#applDatatable').hide();
});

$('#details3').click(function(e) {
e.stopPropagation();
$('#pendingDatatable').toggle();
$('#approvedDatatable').hide();
$('#rejectDatatable').hide();
$('#TotalapprovedDatatable').hide();
$('#TotalRejectedDatatable').hide();
$('#TotalPendingDatatable').hide();
$('#appliedDatatable').hide();
$('#applDatatable').hide();
});

$('#details4').click(function(e) {
e.stopPropagation();
$('#rejectDatatable').toggle();
$('#pendingDatatable').hide();
$('#approvedDatatable').hide();
$('#TotalPendingDatatable').hide();
$('#TotalRejectedDatatable').hide();
$('#appliedDatatable').hide();
$('#TotalapprovedDatatable').hide();
$('#applDatatable').hide();
});

$("#Applied").click(function() {
	$('#approvedDatatable').hide();
	$('#applDatatable').hide();
	$('#pendingDatatable').hide();
	$('#rejectDatatable').hide();
	$('#appliedDatatable').toggle();
    $('#TotalapprovedDatatable').hide();
    $('#TotalPendingDatatable').hide();
    $('#TotalRejectedDatatable').hide();

});
$("#Pending").click(function() {
	$('#approvedDatatable').hide();
	$('#TotalPendingDatatable').toggle();
	$('#TotalapprovedDatatable').hide();
	$('#TotalRejectedDatatable').hide();
	$('#pendingDatatable').hide();
	$('#rejectDatatable').hide();
	$('#appliedDatatable').hide();
	$('#applDatatable').hide();
});
$("#Approved").click(function() {
	$('#TotalapprovedDatatable').toggle();
	$('#TotalRejectedDatatable').hide();
	$('#approvedDatatable').hide();
	$('#TotalPendingDatatable').hide();
	$('#pendingDatatable').hide();
	$('#rejectDatatable').hide();
	$('#applDatatable').hide();
	$('#appliedDatatable').hide();
});
$("#Reject").click(function() {
	$('#approvedDatatable').hide();
	$('#pendingDatatable').hide();
	$('#TotalRejectedDatatable').toggle();
	$('#TotalPendingDatatable').hide();
	$('#rejectDatatable').hide();
	$('#appliedDatatable').hide();
	$('#applDatatable').hide();
	$('#TotalapprovedDatatable').hide();
});