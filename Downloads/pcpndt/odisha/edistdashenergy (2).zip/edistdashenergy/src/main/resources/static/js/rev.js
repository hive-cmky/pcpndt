var myPieChart;
var halfChart;
var myPieCha;
var currentlyOpenRow = null;

let TotalDetail = $('#example').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            });
var TotalTehasilModal = new bootstrap.Modal(document.getElementById('tehasilmodal'));

let ofcDetail = $('#officelist').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            });
var ofcModal = new bootstrap.Modal(document.getElementById('officemodal'));

let ofcTehasilDetail = $('#tehasiloffice').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            });
var ofcTehasilDetailModal = new bootstrap.Modal(document.getElementById('officetehasilmodal'));

let pendingdetail = $('#example1').DataTable({
            scrollCollapse: true,
            scrollY: 300,
            scrollX: true,
            });
var pendingModal = new bootstrap.Modal(document.getElementById('datatablemodal'));


let ortpsReport = $('#ortpsdatatble').DataTable({
	scrollX: true,
	scrollY: 300,
});


function getallAjaxcallbyServiceId (serviceid){
    $.ajax({
        		type: "POST",
        		url: "/findtopperformercountbyserviceid",
        		contentType: 'application/json',
        		data: JSON.stringify({ serviceIds: serviceid }),

        		success: function(data) {
        			console.log(data);
        			var tableHTML = `<table class ="table table-bordered"style="width:100%;">
                                            <thead>
                                                <tr>
                                                    <th>District</th>
                                                    <th>Percentage</th>
                                                </tr>
                                            </thead>
                                            <tbody>`;

                    		data.slice(0,5).forEach(dist => {
                    			tableHTML += `<tr>
                                          <td>` + dist.district + `</td>
                                          <td>` + dist.percentagevalue + `</td>
                                        </tr>`;
                    		});

                    		// Close the table HTML
                    		tableHTML += `</tbody>
                                      </table>`;

                    		$('#topcount').html(tableHTML);
        		}, error: function(jqXHR) {
        			jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : ""
        		}
        	});
    $.ajax({
        	url: "/findBottomperformerbyserviceId",
        	type: "POST",
            contentType: 'application/json',
            data: JSON.stringify({ serviceIds: serviceid}),
        	success: function(data, status) {
        		console.log(data);

        		var tableHTML = `<table class="table table-bordered" style="width:100%;">
                                    <thead>
                                        <tr>
                                            <th>District</th>
                                            <th>Percentage</th>
                                        </tr>
                                    </thead>
                                    <tbody>`;


        		data.slice(-5).forEach(dist => {

        			tableHTML += `<tr>
                                  <td>` + dist.district + `</td>
                                  <td>` + dist.percentagevalue + `</td>
                                </tr>`;
        		});

        		// Close the table HTML
        		tableHTML += `</tbody>
                              </table>`;

        		$('#bottomcount').html(tableHTML);
        	}
        });
    $.ajax({
    	url: "/getTopPerformerbyTehasilbyServiceId",
    	type: "POST",
    	contentType: 'application/json',
        data: JSON.stringify({ serviceIds: serviceid}),
    	success: function(data, status) {
    		console.log(data);

    		var tableHTML = `<table class="table table-bordered" style="width:100%;">
                                <thead>
                                    <tr>
                                        <th>Tehasil</th>
                                        <th>Percentage</th>
                                    </tr>
                                </thead>
                                <tbody>`;


    		data.slice(0,5).forEach(dist => {

    			tableHTML += `<tr>
                              <td>` + dist.tehasil + `</td>
                              <td>` + dist.percentagevalue + `</td>
                            </tr>`;
    		});

    		// Close the table HTML
    		tableHTML += `</tbody>
                          </table>`;

    		$('#Tehasiltopcount').html(tableHTML);
    	}
    });
    $.ajax({
    	url: "/getBottomPerformerbyTehasilbyServiceId",
    	type: "POST",
        contentType: 'application/json',
        data: JSON.stringify({ serviceIds: serviceid}),
    	success: function(data, status) {
    		console.log(data);

    		var tableHTML = `<table class="table table-bordered" style="width:100%;">
                                <thead>
                                    <tr>
                                        <th>Tehasil</th>
                                        <th>Percentage</th>
                                    </tr>
                                </thead>
                                <tbody>`;


    		data.slice(-5).forEach(dist => {

    			tableHTML += `<tr>
                              <td>` + dist.tehasil + `</td>
                              <td>` + dist.percentagevalue + `</td>
                            </tr>`;
    		});

    		// Close the table HTML
    		tableHTML += `</tbody>
                          </table>`;

    		$('#Tehasilbottomcount').html(tableHTML);
    	}
    });
    $.ajax({
    	type: "POST",
        		url: "/findortpscountbyserviceId",
        		contentType: 'application/json',
        		data: JSON.stringify({ serviceIds: serviceid }),
    	success: function(data) {
    		console.log(data)
    		// Extract data from API response
    		const districts = data.map(entry => entry.district);
    		const deliverCounts = data.map(entry => entry.delivercount);
    		const forwardCounts = data.map(entry => entry.forwardcount);
    		const rejectCounts = data.map(entry => entry.rejectcount);
    if (myPieCha) {
    					myPieCha.destroy();
    				}
    		// Create the chart
    		var ctx = document.getElementById('districtBarChart').getContext('2d');
    		 myPieCha = new Chart(ctx, {
    			type: 'bar',
    			data: {
    				labels: districts,
    				datasets: [
    					{
    						label: 'Deliver Count',
    						data: deliverCounts,
    						backgroundColor: '#ffa94d',
    						borderColor: '#000000',
    						borderWidth: 1
    					},
    					{
    						label: 'Reject Count',
    						data: rejectCounts,
    						backgroundColor: '#4dabf7',
    						borderColor: '#000000',
    						borderWidth: 1
    					},
    					{
    						label: 'Pending Count',
    						data: forwardCounts,
    						backgroundColor: '#f03e3e',
    						borderColor: '#000000',
    						borderWidth: 1
    					}
    				]
    			},
    			options: {
                    responsive: true,
                    maintainAspectRatio: false,
    			}
    		});
    	},
    	error: function(xhr, status, error) {
    		console.error('Error fetching data:', error);
    	}
    });
    $.ajax({
        type: "POST",
        url: "/getalltimetakenvaluebyServiceId",
        contentType: 'application/json',
        data: JSON.stringify({ serviceIds: serviceid }),
        beforeSend: function() {
            showLoader();
        },
        success: function(data) {
            console.log(data);

            var items = data[0];
            var maxtime = items[0];
            var mintime = items[1];
            var avgtime = items[2];
            var mediantime = items[3];

            // Update the HTML elements with the values
            document.getElementById("maxtime").innerText = maxtime;
            document.getElementById("mintime").innerText = mintime;
            document.getElementById("avgtime").innerText = avgtime;
            document.getElementById("mediantime").innerText = mediantime;

            hideLoader();
        },
        error: function(jqXHR) {
            jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : "";
        }
    });
    	    abcReport.destroy();
     abcReport = $('#districttbl').DataTable({
        scrollX: true,
        scrollY: 300,
        "ajax": {
            type: "POST",
            url: "/findortpscountbyserviceId",
            contentType: "application/json; charset=utf-8",
            data: function (d) {
                var requestData = {
                    serviceIds: serviceid

                };
              //  console.log("Request Data:", requestData);
                return JSON.stringify(requestData);
            },
                dataSrc: function (json) {
                console.log("Response Data:", json);
                return json;
            }
        },
        "columns": [
            {
                "data": "district", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "appliedcount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "delivercount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "rejectcount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "forwardcount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "ortpscount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "ortps_percentage", "className": "dt-head-center dt-body-center"
            }
        ],
        	dom: 'Blftrip',
							buttons: [
								{
									extend: 'excelHtml5',
									text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
									titleAttr: 'Excel'
								},
								{
									extend: 'pdfHtml5',
									text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
									titleAttr: 'PDF'
								}
							],
    });
    
    	    tehasilReport.destroy();
     tehasilReport = $('#tehsiltbl').DataTable({
        scrollX: true,
        scrollY: 300,
        "ajax": {
            type: "POST",
            url: "/findortpsTehasilcountbyserviceId",
            contentType: "application/json; charset=utf-8",
            data: function (d) {
                var requestData = {
                    serviceIds: serviceid

                };
              //  console.log("Request Data:", requestData);
                return JSON.stringify(requestData);
            },
                dataSrc: function (json) {
                console.log("Response Data:", json);
                return json;
            }
        },
        "columns": [
            {
                "data": "district", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "appliedcount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "delivercount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "rejectcount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "forwardcount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "ortpscount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "ortps_percentage", "className": "dt-head-center dt-body-center"
            }
        ],
        	dom: 'Blftrip',
							buttons: [
								{
									extend: 'excelHtml5',
									text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
									titleAttr: 'Excel'
								},
								{
									extend: 'pdfHtml5',
									text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
									titleAttr: 'PDF'
								}
							],
    });

    	$.ajax({
    		type: "POST",
    		url: "/districtlist",
    		contentType: 'application/json',
    		data: JSON.stringify({ serviceIds: serviceid }),
    		success: function(data) {
    			console.log(data);
    			$('#District').html('');
    			let options = ``;

    			for (let kgf of data) {
    				options += `<option value="` + kgf[1] + `">` + kgf[0] + `</option>`;
    			}
    			$('#District').html(options);
    			$('#District').selectpicker('refresh');
    		}, error: function(jqXHR) {
    			jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : ""
    		}
    	});
    	
    	$.ajax({
    		type: "POST",
    		url: "/findcountByserviceId",
    		contentType: 'application/json',
    		data: JSON.stringify({ serviceIds: serviceid }),


    		success: function(data) {
    			let totalDeliverCount = 0;
    			let totalForwardCount = 0;
    			let totalRejectCount = 0;
    			let serviceNames = [];
    			let totalAppliedCounts = [];
    			let deliverCounts = [];
    			let forwardCounts = [];
    			let rejectCounts = [];
    			console.log(data)
    			$('#cardContainer').html('');
    			var tableBody = $("#dataTable tbody");
    			tableBody.empty();
    			data.forEach(function(service) {
    				let serviceid = service.serviceid;
    				let serviceName = service.servicename;
    				let deliverCount = service.delivercount;
    				let forwardCount = service.forwardcount;
    				let rejectCount = service.rejectcount;

    				let maxdiff = service.max_diff;
    				let mindiff = service.min_diff;
    				let avgdiff = service.avg_diff;
    				let mediandiff = service.median_diff;

    				// Creating card structure dynamically for each service
    				totalDeliverCount += deliverCount;
    				totalForwardCount += forwardCount;
    				totalRejectCount += rejectCount;
    				let totalAppliedCount = totalRejectCount + totalForwardCount + totalDeliverCount;
    				serviceNames.push(serviceName);
    				totalAppliedCounts.push(totalAppliedCount);
    				deliverCounts.push(deliverCount);
    				forwardCounts.push(forwardCount);
    				rejectCounts.push(rejectCount);
    				const percentDeliver = (totalDeliverCount / totalAppliedCount) * 100;
    				const percentForward = (totalForwardCount / totalAppliedCount) * 100;
    				const percentReject = (totalRejectCount / totalAppliedCount) * 100;
    				$("#appliedCount").html(totalAppliedCount);
    				$("#deliverCount").html(totalDeliverCount);
    				$("#forwardCount").html(totalForwardCount);
    				$("#rejectCount").html(totalRejectCount);
    				$('#data-table').hide();
    				$('#dataTable').show();




    				var row = $("<tr></tr>");
    				row.append("<td>" + serviceName + "</td>");
    				row.append("<td>" + maxdiff + "</td>");
    				row.append("<td>" + mindiff + "</td>");
    				row.append("<td>" + avgdiff + "</td>");
    				row.append("<td>" + mediandiff + "</td>");
    				tableBody.append(row);





    				let cardHtml = `
                 <div class="col-md-4">
                  <div class="card mb-3">
                       <div class="card-header bgcolor text-center" id=${serviceid} >${serviceName}</div>
                       <div class="card-body">
                            <div class="row">
                             <div class="col-md-4">
                                   <div class="card custom-border-color1 mb-3">
                                       <div class="card-body">
                                            <h6 class="card-title custom-font-size">Deliver Count</h6>
                                            <p class="card-text">${deliverCount}</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                   <div class="card custom-border-color2 mb-3">
                                        <div class="card-body">
                                           <h6 class="card-title", style="font-size: 14px">Pending Count</h6>
                                           <p class="card-text">${forwardCount}</p>
                                       </div>
                                   </div>
                             </div>
                              <div class="col-md-4">
                                  <div class="card custom-border-color3 mb-3">
                                      <div class="card-body">
                                            <h6 class="card-title", style="font-size: 15px">Reject Count</h6>
                                            <p class="card-text">${rejectCount}</p>
                                        </div>
                                    </div>
                                </div>
                              <div class="col-md-3">
                                  <div class="card custom-border-color4 mb-3">
                                      <div class="card-body">
                                           <h6 class="card-title">Max Time</h6>
                                           <p class="card-text">${maxdiff}</p>
                                      </div>
                                  </div>
                              </div>
                              <div class="col-md-3">
                                  <div class="card custom-border-color5 mb-3">
                                     <div class="card-body">
                                          <h6 class="card-title">Min Time</h6>
                                          <p class="card-text">${mindiff}</p>
                                     </div>
                                  </div>
                              </div>
                              <div class="col-md-3">
                                  <div class="card custom-border-color6 mb-3">
                                       <div class="card-body">
                                            <h6 class="card-title">Avg Time</h6>
                                            <p class="card-text">${avgdiff}</p>
                                       </div>
                                  </div>
                              </div>
                              <div class="col-md-3">
                                 <div class="card custom-border-color7 mb-3">
                                      <div class="card-body">
                                           <h6 class="card-title">Median Time</h6>
                                           <p class="card-text">${mediandiff}</p>
                                      </div>
                                 </div>
                              </div>
                            </div>
                        </div>
                    </div>
                    </div>
                `;

    				$('#cardContainer').append(cardHtml);

    				if (halfChart) {
    					halfChart.destroy();
    				}

    				const ctxz = document.getElementById('halfChart').getContext('2d');
    				halfChart = new Chart(ctxz, {
    					type: 'doughnut',
    					data: {
    						labels: ['Deliver', 'Reject', 'Pending'],
    						datasets: [{
    							label: 'Percentage',
    							data: [percentDeliver, percentReject, percentForward],
    							backgroundColor: [
    								'#ffa94d',
    								'#4dabf7',
    								'#f03e3e'
    							],
    							borderWidth: 1
    						}]
    					},
    					options: {
    						responsive: true,
    						maintainAspectRatio: false,
    						rotation: -90, // Rotate to make a semi-circle
    						circumference: 180, // Only show 180 degrees (half circle)
    						plugins: {
    							legend: {
    								display: true,
    								position: 'top'
    							},
    							tooltip: {
    								callbacks: {
    									label: function(tooltipItem) {
    										let label = tooltipItem.label || '';
    										let value = tooltipItem.raw.toFixed(2);
    										let count;
    										if (label === 'Deliver') {
    											count = totalDeliverCount;
    										} else if (label === 'Pending') {
    											count = totalForwardCount;
    										} else if (label === 'Reject') {
    											count = totalRejectCount;
    										}
    										return `${label}: ${value}% (${count} counts)`;
    									}
    								}
    							},
    							datalabels: {
    								display: true,
    								color: 'white',
    								font: {
    									weight: 'bold',
    									size: 16
    								},
    								formatter: function(value, context) {
    									return value.toFixed(2) + '%';
    								}
    							}
    						},
    						layout: {
    							padding: {
    								top: 20,
    								bottom: 20
    							}
    						}
    					},
    					plugins: [ChartDataLabels]
    				});
    				if (myPieChart) {
    					myPieChart.destroy();
    				}
    				var ctx = document.getElementById('tripleLineChart').getContext('2d');
    				myPieChart = new Chart(ctx, {
    					type: 'bar',
    					data: {
    						labels: serviceNames,
    						datasets: [
    							{
    								label: 'Total Applied',
    								data: totalAppliedCounts,
    								backgroundColor: '#ffd43b',
    								borderColor: '#000000',
    								borderWidth: 1
    							},
    							{
    								label: 'Total Deliver',
    								data: deliverCounts,
    								backgroundColor: '#ffa94d',
    								borderColor: '#000000',
    								borderWidth: 1
    							},
    							/*		{
    										label: 'Reject Count',
    										data: rejectCounts,
    										backgroundColor: 'rgba(255, 99, 132, 0.6)',
    										borderColor: 'rgba(255, 99, 132, 1)',
    										borderWidth: 1
    									}*/
    						]
    					},
    					options: {
                            responsive: true,
                            maintainAspectRatio: false,
    					}
    				})
    			});
    		},
    		error: function(jqXHR) {
    			if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
    				showToast(jqXHR.responseJSON.message);
    			}
    		}
    	});
}

function getallAjaxcallbyServiceIdandDistrict(serviceid,district){
    $.ajax({
    	type: "POST",
        url: "/getOrtpscountbyServiceIdandDistrict",
        contentType: 'application/json',
        data: JSON.stringify({ serviceIds: serviceid, districtIds: district }),
    	success: function(data) {
    		console.log(data)
    		// Extract data from API response
    		const districts = data.map(entry => entry.district);
    		const deliverCounts = data.map(entry => entry.delivercount);
    		const forwardCounts = data.map(entry => entry.forwardcount);
    		const rejectCounts = data.map(entry => entry.rejectcount);
                    if (myPieCha) {
    					myPieCha.destroy();
    				}
    		// Create the chart
    		var ctx = document.getElementById('districtBarChart').getContext('2d');
    		 myPieCha = new Chart(ctx, {
    			type: 'bar',
    			data: {
    				labels: districts,
    				datasets: [
    					{
    						label: 'Deliver Count',
    						data: deliverCounts,
    						backgroundColor: '#ffa94d',
    						borderColor: '#000000',
    						borderWidth: 1
    					},
    					{
    						label: 'Reject Count',
    						data: rejectCounts,
    						backgroundColor: '#4dabf7',
    						borderColor: '#000000',
    						borderWidth: 1
    					},
    					{
    						label: 'Pending Count',
    						data: forwardCounts,
    						backgroundColor: '#f03e3e',
    						borderColor: '#000000',
    						borderWidth: 1
    					}
    				]
    			},
    			options: {
                    responsive: true,
                    maintainAspectRatio: false,
    			}
    		});
    	},
    	error: function(xhr, status, error) {
    		console.error('Error fetching data:', error);
    	}
    });
        abcReport.destroy();
     abcReport = $('#districttbl').DataTable({
        scrollX: true,
        scrollY: 300,
        "ajax": {
            type: "POST",
            url: "/getOrtpscountbyServiceIdandDistrict",
            contentType: "application/json; charset=utf-8",
            data: function (d) {
                var requestData = {
                    serviceIds: serviceid,
                    districtIds: district
                };
                console.log("Request Data:", requestData);
                return JSON.stringify(requestData);
            },
                dataSrc: function (json) {
                console.log("Response Data:", json);
                return json;
            }
        },
        "columns": [
            {
                "data": "district", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "appliedcount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "delivercount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "rejectcount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "forwardcount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "ortpscount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "ortps_percentage", "className": "dt-head-center dt-body-center"
            }
        ],
        	dom: 'Blftrip',
							buttons: [
								{
									extend: 'excelHtml5',
									text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
									titleAttr: 'Excel'
								},
								{
									extend: 'pdfHtml5',
									text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
									titleAttr: 'PDF'
								}
							],
    });
    
           tehasilReport.destroy();
     tehasilReport = $('#tehsiltbl').DataTable({
        scrollX: true,
        scrollY: 300,
        "ajax": {
            type: "POST",
            url: "/getOrtpsTehasilcountbyServiceIdandDistrict",
            contentType: "application/json; charset=utf-8",
            data: function (d) {
                var requestData = {
                    serviceIds: serviceid,
                    districtIds: district
                };
                console.log("Request Data:", requestData);
                return JSON.stringify(requestData);
            },
                dataSrc: function (json) {
                console.log("Response Data:", json);
                return json;
            }
        },
        "columns": [
            {
                "data": "district", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "appliedcount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "delivercount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "rejectcount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "forwardcount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "ortpscount", "className": "dt-head-center dt-body-center"
            },
            {
                "data": "ortps_percentage", "className": "dt-head-center dt-body-center"
            }
        ],
        	dom: 'Blftrip',
							buttons: [
								{
									extend: 'excelHtml5',
									text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
									titleAttr: 'Excel'
								},
								{
									extend: 'pdfHtml5',
									text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
									titleAttr: 'PDF'
								}
							],
    });

        $.ajax({
        	url: "/findBottomPerformerbyTehasilbyServiceIdandDistrict",
        	type: "POST",
            contentType: 'application/json',
            data: JSON.stringify({ serviceIds: serviceid, districtIds: district }),
        	success: function(data, status) {
        		console.log(data);

        		var tableHTML = `<table class="table table-bordered" style="width:100%;">
                                    <thead>
                                        <tr>
                                            <th>Tehasil</th>
                                            <th>Percentage</th>
                                        </tr>
                                    </thead>
                                    <tbody>`;


        		data.slice(-5).forEach(dist => {

        			tableHTML += `<tr>
                                  <td>` + dist.tehasil + `</td>
                                  <td>` + dist.percentagevalue + `</td>
                                </tr>`;
        		});

        		// Close the table HTML
        		tableHTML += `</tbody>
                              </table>`;

        		$('#Tehasilbottomcount').html(tableHTML);
        	}
        });

        $.ajax({
        	url: "/findBottomperformerbyserviceIdanddistrict",
        	type: "POST",
            contentType: 'application/json',
            data: JSON.stringify({ serviceIds: serviceid, districtIds: district }),
        	success: function(data, status) {
        		console.log(data);

        		var tableHTML = `<table class="table table-bordered" style="width:100%;">
                                    <thead>
                                        <tr>
                                            <th>District</th>
                                            <th>Percentage</th>
                                        </tr>
                                    </thead>
                                    <tbody>`;


        		data.slice(-5).forEach(dist => {

        			tableHTML += `<tr>
                                  <td>` + dist.district + `</td>
                                  <td>` + dist.percentagevalue + `</td>
                                </tr>`;
        		});

        		// Close the table HTML
        		tableHTML += `</tbody>
                              </table>`;

        		$('#bottomcount').html(tableHTML);
        	}
        });

    	$.ajax({
        	url: "/getTopPerformerbyTehasilbyServiceIdandDistrict",
        	type: "POST",
        		contentType: 'application/json',
            		data: JSON.stringify({ serviceIds: serviceid, districtIds: district }),
        	success: function(data, status) {
        		console.log(data);

        		var tableHTML = `<table class="table table-bordered" style="width:100%;">
                                    <thead>
                                        <tr>
                                            <th>Tehasil</th>
                                            <th>Percentage</th>
                                        </tr>
                                    </thead>
                                    <tbody>`;


        		data.slice(0,5).forEach(dist => {

        			tableHTML += `<tr>
                                  <td>` + dist.tehasil + `</td>
                                  <td>` + dist.percentagevalue + `</td>
                                </tr>`;
        		});

        		// Close the table HTML
        		tableHTML += `</tbody>
                              </table>`;

        		$('#Tehasiltopcount').html(tableHTML);
        	}
        });

    	$.ajax({
        		type: "POST",
        		url: "/findtopperformerbyserviceIdandDistrict",
        		contentType: 'application/json',
        		data: JSON.stringify({ serviceIds: serviceid, districtIds: district }),
        		success: function(data) {
        		console.log(data)
        		var tableHTML = `<table class ="table table-bordered"style="width:100%;">
                                        <thead>
                                            <tr>
                                                <th>District</th>
                                                <th>Percentage</th>
                                            </tr>
                                        </thead>
                                        <tbody>`;

                		data.slice(0,5).forEach(dist => {

                			tableHTML += `<tr>
                                      <td>` + dist.district + `</td>
                                      <td>` + dist.percentagevalue + `</td>
                                    </tr>`;
                		});
                		// Close the table HTML
                		tableHTML += `</tbody>
                                  </table>`;
                		$('#topcount').html(tableHTML);
        		}
        		});

        $.ajax({
            type: "POST",
            url: "/getalltimetakenvaluebyServiceIdandDistrict",
            contentType: 'application/json',
            data: JSON.stringify({ serviceIds: serviceid, districtIds: district }),
            beforeSend: function() {
                showLoader();
            },
            success: function(data) {
                console.log(data);

                var items = data[0];
                var maxtime = items[0];
                var mintime = items[1];
                var avgtime = items[2];
                var mediantime = items[3];

                // Update the HTML elements with the values
                document.getElementById("maxtime").innerText = maxtime;
                document.getElementById("mintime").innerText = mintime;
                document.getElementById("avgtime").innerText = avgtime;
                document.getElementById("mediantime").innerText = mediantime;

                hideLoader();
            },
            error: function(jqXHR) {
                jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : "";
            }
        });
    	$.ajax({
            		type: "POST",
            		url: "/findcountByserviceIdAndDistrict",
            		contentType: 'application/json',
            		data: JSON.stringify({ serviceIds: serviceid, districtIds: district }),
            		success: function(data) {
            			let totalDeliverCount = 0;
            			let totalForwardCount = 0;
            			let totalRejectCount = 0;
            			let serviceNames = [];
            			let totalAppliedCounts = [];
            			let deliverCounts = [];
            			let forwardCounts = [];
            			let rejectCounts = [];
            			console.log(data)
            			$('#cardContainer').html('');
            			var tableBody = $("#dataTable tbody");
            			tableBody.empty();
            			data.forEach(function(service) {
            				let serviceid = service.serviceid;
            				let serviceName = service.servicename;
            				let deliverCount = service.delivercount;
            				let forwardCount = service.forwardcount;
            				let rejectCount = service.rejectcount;

            				let maxdiff = service.max_diff;
            				let mindiff = service.min_diff;
            				let avgdiff = service.avg_diff;
            				let mediandiff = service.median_diff;

            				// Creating card structure dynamically for each service
            				totalDeliverCount += deliverCount;
            				totalForwardCount += forwardCount;
            				totalRejectCount += rejectCount;
            				let totalAppliedCount = totalRejectCount + totalForwardCount + totalDeliverCount;
            				serviceNames.push(serviceName);
            				totalAppliedCounts.push(totalAppliedCount);
            				deliverCounts.push(deliverCount);
            				forwardCounts.push(forwardCount);
            				rejectCounts.push(rejectCount);
            				const percentDeliver = (totalDeliverCount / totalAppliedCount) * 100;
            				const percentForward = (totalForwardCount / totalAppliedCount) * 100;
            				const percentReject = (totalRejectCount / totalAppliedCount) * 100;
            				$("#appliedCount").html(totalAppliedCount);
            				$("#deliverCount").html(totalDeliverCount);
            				$("#forwardCount").html(totalForwardCount);
            				$("#rejectCount").html(totalRejectCount);
            				$('#data-table').hide();
            				$('#dataTable').show();




            				var row = $("<tr></tr>");
            				row.append("<td>" + serviceName + "</td>");
            				row.append("<td>" + maxdiff + "</td>");
            				row.append("<td>" + mindiff + "</td>");
            				row.append("<td>" + avgdiff + "</td>");
            				row.append("<td>" + mediandiff + "</td>");
            				tableBody.append(row);





            				let cardHtml = `
                         <div class="col-md-4">
                          <div class="card mb-3">
                               <div class="card-header bgcolor text-center" id=${serviceid} >${serviceName}</div>
                               <div class="card-body">
                                    <div class="row">
                                     <div class="col-md-4">
                                           <div class="card custom-border-color1 mb-3">
                                               <div class="card-body">
                                                    <h6 class="card-title custom-font-size">Deliver Count</h6>
                                                    <p class="card-text">${deliverCount}</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                           <div class="card custom-border-color2 mb-3">
                                                <div class="card-body">
                                                   <h6 class="card-title", style="font-size: 14px">Pending Count</h6>
                                                   <p class="card-text">${forwardCount}</p>
                                               </div>
                                           </div>
                                     </div>
                                      <div class="col-md-4">
                                          <div class="card custom-border-color3 mb-3">
                                              <div class="card-body">
                                                    <h6 class="card-title", style="font-size: 15px">Reject Count</h6>
                                                    <p class="card-text">${rejectCount}</p>
                                                </div>
                                            </div>
                                        </div>
                                      <div class="col-md-3">
                                          <div class="card custom-border-color4 mb-3">
                                              <div class="card-body">
                                                   <h6 class="card-title">Max Time</h6>
                                                   <p class="card-text">${maxdiff}</p>
                                              </div>
                                          </div>
                                      </div>
                                      <div class="col-md-3">
                                          <div class="card custom-border-color5 mb-3">
                                             <div class="card-body">
                                                  <h6 class="card-title">Min Time</h6>
                                                  <p class="card-text">${mindiff}</p>
                                             </div>
                                          </div>
                                      </div>
                                      <div class="col-md-3">
                                          <div class="card custom-border-color6 mb-3">
                                               <div class="card-body">
                                                    <h6 class="card-title">Avg Time</h6>
                                                    <p class="card-text">${avgdiff}</p>
                                               </div>
                                          </div>
                                      </div>
                                      <div class="col-md-3">
                                         <div class="card custom-border-color7 mb-3">
                                              <div class="card-body">
                                                   <h6 class="card-title">Median Time</h6>
                                                   <p class="card-text">${mediandiff}</p>
                                              </div>
                                         </div>
                                      </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                        `;

            				$('#cardContainer').append(cardHtml);

            				if (halfChart) {
            					halfChart.destroy();
            				}
            				const ctxz = document.getElementById('halfChart').getContext('2d');
            				halfChart = new Chart(ctxz, {
            					type: 'doughnut',
            					data: {
            						labels: ['Deliver', 'Reject', 'Pending'],
            						datasets: [{
            							label: 'Percentage',
            							data: [percentDeliver, percentReject, percentForward],
            							backgroundColor: [
            								'#ffa94d',
            								'#4dabf7',
            								'#f03e3e'
            							],
            							borderWidth: 1
            						}]
            					},
            					options: {
            						responsive: true,
            						maintainAspectRatio: false,
            						rotation: -90, // Rotate to make a semi-circle
            						circumference: 180, // Only show 180 degrees (half circle)
            						plugins: {
            							legend: {
            								display: true,
            								position: 'top'
            							},
            							tooltip: {
            								callbacks: {
            									label: function(tooltipItem) {
            										let label = tooltipItem.label || '';
            										let value = tooltipItem.raw.toFixed(2);
            										let count;
            										if (label === 'Deliver') {
            											count = totalDeliverCount;
            										} else if (label === 'Pending') {
            											count = totalForwardCount;
            										} else if (label === 'Reject') {
            											count = totalRejectCount;
            										}
            										return `${label}: ${value}% (${count} counts)`;
            									}
            								}
            							},
            							datalabels: {
            								display: true,
            								color: 'white',
            								font: {
            									weight: 'bold',
            									size: 16
            								},
            								formatter: function(value, context) {
            									return value.toFixed(2) + '%';
            								}
            							}
            						},
            						layout: {
            							padding: {
            								top: 20,
            								bottom: 20
            							}
            						}
            					},
            					plugins: [ChartDataLabels]
            				});
            				if (myPieChart) {
            					myPieChart.destroy();
            				}
            				var ctx = document.getElementById('tripleLineChart').getContext('2d');
            				myPieChart = new Chart(ctx, {
            					type: 'bar',
            					data: {
            						labels: serviceNames,
            						datasets: [
            							{
            								label: 'Total Applied',
            								data: totalAppliedCounts,
            								backgroundColor: '#ffd43b',
            								borderColor: '#000000',
            								borderWidth: 1
            							},
            							{
            								label: 'Total Deliver',
            								data: deliverCounts,
            								backgroundColor: '#ffa94d',
            								borderColor: '#000000',
            								borderWidth: 1
            							},
            							/*		{
            										label: 'Reject Count',
            										data: rejectCounts,
            										backgroundColor: 'rgba(255, 99, 132, 0.6)',
            										borderColor: 'rgba(255, 99, 132, 1)',
            										borderWidth: 1
            									}*/
            						]
            					},
            					options: {
                                    responsive: true,
                                    maintainAspectRatio: false,
            					}
            				})
            			});
            		},
            		error: function(jqXHR) {
            			if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
            				showToast(jqXHR.responseJSON.message);
            			}
            		}
            	});
}

//function getallAjaxcallbyStartdate(submidate){
//$.ajax({
//        type: "POST",
//        url: "/getalltimetakenvaluebyStartdate",
//        contentType: 'application/json',
//        data: JSON.stringify({ SubmitDate: submidate }),
//        success: function(data) {
//        console.log(data);
//
//            var items = data[0];
//            var maxtime = items[0];
//            var mintime = items[1];
//            var avgtime = items[2];
//            var mediantime = items[3];
//
//            // Update the HTML elements with the values
//            document.getElementById("maxtime").innerText = maxtime;
//            document.getElementById("mintime").innerText = mintime;
//            document.getElementById("avgtime").innerText = avgtime;
//            document.getElementById("mediantime").innerText = mediantime;
//        },
//        error: function(jqXHR) {
//            jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : "";
//        }
//    });
//abcReport.destroy();
//     abcReport = $('#districttbl').DataTable({
//        scrollX: true,
//        scrollY: 300,
//        "ajax": {
//            type: "POST",
//            url: "/getortpscountbyStartDate",
//            contentType: "application/json; charset=utf-8",
//            data: function (d) {
//                var requestData = {
//                    SubmitDate: submidate
//                };
//              //  console.log("Request Data:", requestData);
//                return JSON.stringify(requestData);
//            },
//                dataSrc: function (json) {
//                console.log("Response Data:", json);
//                return json;
//            }
//        },
//        "columns": [
//            {
//                "data": "district", "className": "dt-head-center dt-body-center"
//            },
//            {
//                "data": "appliedcount", "className": "dt-head-center dt-body-center"
//            },
//            {
//                "data": "delivercount", "className": "dt-head-center dt-body-center"
//            },
//            {
//                "data": "rejectcount", "className": "dt-head-center dt-body-center"
//            },
//            {
//                "data": "forwardcount", "className": "dt-head-center dt-body-center"
//            },
//            {
//                "data": "ortpscount", "className": "dt-head-center dt-body-center"
//            },
//            {
//                "data": "ortps_percentage", "className": "dt-head-center dt-body-center"
//            }
//        ]
//    });
//$.ajax({
//    	type: "POST",
//        url: "/getortpscountbyStartDate",
//        contentType: 'application/json',
//        data: JSON.stringify({ SubmitDate: submidate }),
//    	success: function(data) {
//    		console.log(data)
//    		// Extract data from API response
//    		const districts = data.map(entry => entry.district);
//    		const deliverCounts = data.map(entry => entry.delivercount);
//    		const forwardCounts = data.map(entry => entry.forwardcount);
//    		const rejectCounts = data.map(entry => entry.rejectcount);
//                        if (myPieCha) {
//    					myPieCha.destroy();
//    				}
//    		// Create the chart
//    		var ctx = document.getElementById('districtBarChart').getContext('2d');
//    		 myPieCha = new Chart(ctx, {
//    			type: 'bar',
//    			data: {
//    				labels: districts,
//    				datasets: [
//    					{
//    						label: 'Deliver Count',
//    						data: deliverCounts,
//    						backgroundColor: '#ffa94d',
//    						borderColor: '#000000',
//    						borderWidth: 1
//    					},
//    					{
//    						label: 'Reject Count',
//    						data: rejectCounts,
//    						backgroundColor: '#4dabf7',
//    						borderColor: '#000000',
//    						borderWidth: 1
//    					},
//    					{
//    						label: 'Pending Count',
//    						data: forwardCounts,
//    						backgroundColor: '#f03e3e',
//    						borderColor: '#000000',
//    						borderWidth: 1
//    					}
//    				]
//    			},
//    			options: {
//                    responsive: true,
//                    maintainAspectRatio: false,
//    			}
//    		});
//    	},
//    	error: function(xhr, status, error) {
//    		console.error('Error fetching data:', error);
//    	}
//    });
//$.ajax({
//    		type: "POST",
//    		url: "/getcountbyStartDate",
//    		contentType: 'application/json',
//    		data: JSON.stringify({ SubmitDate: submidate }),
//    		success: function(data) {
//    			let totalDeliverCount = 0;
//    			let totalForwardCount = 0;
//    			let totalRejectCount = 0;
//    			let serviceNames = [];
//    			let totalAppliedCounts = [];
//    			let deliverCounts = [];
//    			let forwardCounts = [];
//    			let rejectCounts = [];
//    			console.log(data)
//    			$('#cardContainer').html('');
//    			var tableBody = $("#dataTable tbody");
//    			tableBody.empty();
//    			data.forEach(function(service) {
//    				let serviceid = service.serviceid;
//    				let serviceName = service.servicename;
//    				let deliverCount = service.delivercount;
//    				let forwardCount = service.forwardcount;
//    				let rejectCount = service.rejectcount;
//
//    				let maxdiff = service.max_diff;
//    				let mindiff = service.min_diff;
//    				let avgdiff = service.avg_diff;
//    				let mediandiff = service.median_diff;
//
//    				// Creating card structure dynamically for each service
//    				totalDeliverCount += deliverCount;
//    				totalForwardCount += forwardCount;
//    				totalRejectCount += rejectCount;
//    				let totalAppliedCount = totalRejectCount + totalForwardCount + totalDeliverCount;
//    				serviceNames.push(serviceName);
//    				totalAppliedCounts.push(totalAppliedCount);
//    				deliverCounts.push(deliverCount);
//    				forwardCounts.push(forwardCount);
//    				rejectCounts.push(rejectCount);
//    				const percentDeliver = (totalDeliverCount / totalAppliedCount) * 100;
//    				const percentForward = (totalForwardCount / totalAppliedCount) * 100;
//    				const percentReject = (totalRejectCount / totalAppliedCount) * 100;
//    				$("#appliedCount").html(totalAppliedCount);
//    				$("#deliverCount").html(totalDeliverCount);
//    				$("#forwardCount").html(totalForwardCount);
//    				$("#rejectCount").html(totalRejectCount);
//    				$('#data-table').hide();
//    				$('#dataTable').show();
//
//
//
//
//    				var row = $("<tr></tr>");
//    				row.append("<td>" + serviceName + "</td>");
//    				row.append("<td>" + maxdiff + "</td>");
//    				row.append("<td>" + mindiff + "</td>");
//    				row.append("<td>" + avgdiff + "</td>");
//    				row.append("<td>" + mediandiff + "</td>");
//    				tableBody.append(row);
//
//
//
//
//
//    				let cardHtml = `
//                 <div class="col-md-4">
//                  <div class="card mb-3">
//                       <div class="card-header bgcolor text-center" id=${serviceid} >${serviceName}</div>
//                       <div class="card-body">
//                            <div class="row">
//                             <div class="col-md-4">
//                                   <div class="card custom-border-color1 mb-3">
//                                       <div class="card-body">
//                                            <h6 class="card-title custom-font-size">Deliver Count</h6>
//                                            <p class="card-text">${deliverCount}</p>
//                                        </div>
//                                    </div>
//                                </div>
//                                <div class="col-md-4">
//                                   <div class="card custom-border-color2 mb-3">
//                                        <div class="card-body">
//                                           <h6 class="card-title", style="font-size: 14px">Pending Count</h6>
//                                           <p class="card-text">${forwardCount}</p>
//                                       </div>
//                                   </div>
//                             </div>
//                              <div class="col-md-4">
//                                  <div class="card custom-border-color3 mb-3">
//                                      <div class="card-body">
//                                            <h6 class="card-title", style="font-size: 15px">Reject Count</h6>
//                                            <p class="card-text">${rejectCount}</p>
//                                        </div>
//                                    </div>
//                                </div>
//                              <div class="col-md-3">
//                                  <div class="card custom-border-color4 mb-3">
//                                      <div class="card-body">
//                                           <h6 class="card-title">Max Time</h6>
//                                           <p class="card-text">${maxdiff}</p>
//                                      </div>
//                                  </div>
//                              </div>
//                              <div class="col-md-3">
//                                  <div class="card custom-border-color5 mb-3">
//                                     <div class="card-body">
//                                          <h6 class="card-title">Min Time</h6>
//                                          <p class="card-text">${mindiff}</p>
//                                     </div>
//                                  </div>
//                              </div>
//                              <div class="col-md-3">
//                                  <div class="card custom-border-color6 mb-3">
//                                       <div class="card-body">
//                                            <h6 class="card-title">Avg Time</h6>
//                                            <p class="card-text">${avgdiff}</p>
//                                       </div>
//                                  </div>
//                              </div>
//                              <div class="col-md-3">
//                                 <div class="card custom-border-color7 mb-3">
//                                      <div class="card-body">
//                                           <h6 class="card-title">Median Time</h6>
//                                           <p class="card-text">${mediandiff}</p>
//                                      </div>
//                                 </div>
//                              </div>
//                            </div>
//                        </div>
//                    </div>
//                    </div>
//                `;
//
//    				$('#cardContainer').append(cardHtml);
//
//    				if (halfChart) {
//    					halfChart.destroy();
//    				}
//    				const ctxz = document.getElementById('halfChart').getContext('2d');
//    				halfChart = new Chart(ctxz, {
//    					type: 'doughnut',
//    					data: {
//    						labels: ['Deliver', 'Reject', 'Pending'],
//    						datasets: [{
//    							label: 'Percentage',
//    							data: [percentDeliver, percentReject, percentForward],
//    							backgroundColor: [
//    								'#ffa94d',
//    								'#4dabf7',
//    								'#f03e3e'
//    							],
//    							borderWidth: 1
//    						}]
//    					},
//    					options: {
//    						responsive: true,
//    						maintainAspectRatio: false,
//    						rotation: -90, // Rotate to make a semi-circle
//    						circumference: 180, // Only show 180 degrees (half circle)
//    						plugins: {
//    							legend: {
//    								display: true,
//    								position: 'top'
//    							},
//    							tooltip: {
//    								callbacks: {
//    									label: function(tooltipItem) {
//    										let label = tooltipItem.label || '';
//    										let value = tooltipItem.raw.toFixed(2);
//    										let count;
//    										if (label === 'Deliver') {
//    											count = totalDeliverCount;
//    										} else if (label === 'Pending') {
//    											count = totalForwardCount;
//    										} else if (label === 'Reject') {
//    											count = totalRejectCount;
//    										}
//    										return `${label}: ${value}% (${count} counts)`;
//    									}
//    								}
//    							},
//    							datalabels: {
//    								display: true,
//    								color: 'white',
//    								font: {
//    									weight: 'bold',
//    									size: 16
//    								},
//    								formatter: function(value, context) {
//    									return value.toFixed(2) + '%';
//    								}
//    							}
//    						},
//    						layout: {
//    							padding: {
//    								top: 20,
//    								bottom: 20
//    							}
//    						}
//    					},
//    					plugins: [ChartDataLabels]
//    				});
//    				if (myPieChart) {
//    					myPieChart.destroy();
//    				}
//    				var ctx = document.getElementById('tripleLineChart').getContext('2d');
//    				myPieChart = new Chart(ctx, {
//    					type: 'bar',
//    					data: {
//    						labels: serviceNames,
//    						datasets: [
//    							{
//    								label: 'Total Applied',
//    								data: totalAppliedCounts,
//    								backgroundColor: '#ffd43b',
//    								borderColor: '#000000',
//    								borderWidth: 1
//    							},
//    							{
//    								label: 'Total Deliver',
//    								data: deliverCounts,
//    								backgroundColor: '#ffa94d',
//    								borderColor: '#000000',
//    								borderWidth: 1
//    							},
//    							/*		{
//    										label: 'Reject Count',
//    										data: rejectCounts,
//    										backgroundColor: 'rgba(255, 99, 132, 0.6)',
//    										borderColor: 'rgba(255, 99, 132, 1)',
//    										borderWidth: 1
//    									}*/
//    						]
//    					},
//    					options: {
//                            responsive: true,
//                            maintainAspectRatio: false,
//    					}
//    				})
//    			});
//    		},
//    		error: function(jqXHR) {
//    			if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
//    				showToast(jqXHR.responseJSON.message);
//    			}
//    		}
//    	});
//$.ajax({
//        		type: "POST",
//        		url: "/findtopperformercountbyStartDate",
//        		contentType: 'application/json',
//        		data: JSON.stringify({ SubmitDate: submidate }),
//
//        		success: function(data) {
//        			console.log(data);
//        			var tableHTML = `<table class ="table table-bordered"style="width:100%;">
//                                            <thead>
//                                                <tr>
//                                                    <th>District</th>
//                                                    <th>Percentage</th>
//                                                </tr>
//                                            </thead>
//                                            <tbody>`;
//
//                    		data.slice(0,5).forEach(dist => {
//                    			tableHTML += `<tr>
//                                          <td>` + dist.district + `</td>
//                                          <td>` + dist.percentagevalue + `</td>
//                                        </tr>`;
//                    		});
//
//                    		// Close the table HTML
//                    		tableHTML += `</tbody>
//                                      </table>`;
//
//                    		$('#topcount').html(tableHTML);
//        		}, error: function(jqXHR) {
//        			jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : ""
//        		}
//        	});
//$.ajax({
//	url: "/findtopperformercountbyStartDate",
//	type: "POST",
//    contentType: 'application/json',
//    data: JSON.stringify({ SubmitDate: submidate }),
//	success: function(data, status) {
//		console.log(data);
//
//		var tableHTML = `<table class="table table-bordered" style="width:100%;">
//                            <thead>
//                                <tr>
//                                    <th>District</th>
//                                    <th>Percentage</th>
//                                </tr>
//                            </thead>
//                            <tbody>`;
//
//
//		data.slice(-5).forEach(dist => {
//			tableHTML += `<tr>
//                          <td>` + dist.district + `</td>
//                          <td>` + dist.percentagevalue + `</td>
//                        </tr>`;
//		});
//
//		// Close the table HTML
//		tableHTML += `</tbody>
//                      </table>`;
//
//		$('#bottomcount').html(tableHTML);
//	}
//});
//$.ajax({
//    	url: "/getTopPerformerbyTehasilbyStartDate",
//    	type: "POST",
//    	contentType: 'application/json',
//        data: JSON.stringify({ SubmitDate: submidate }),
//    	success: function(data, status) {
//    		console.log(data);
//
//    		var tableHTML = `<table class="table table-bordered" style="width:100%;">
//                                <thead>
//                                    <tr>
//                                        <th>Tehasil</th>
//                                        <th>Percentage</th>
//                                    </tr>
//                                </thead>
//                                <tbody>`;
//
//
//    		data.slice(0,5).forEach(dist => {
//
//    			tableHTML += `<tr>
//                              <td>` + dist.tehasil + `</td>
//                              <td>` + dist.percentagevalue + `</td>
//                            </tr>`;
//    		});
//
//    		// Close the table HTML
//    		tableHTML += `</tbody>
//                          </table>`;
//
//    		$('#Tehasiltopcount').html(tableHTML);
//    	}
//    });
//$.ajax({
//    	url: "/getTopPerformerbyTehasilbyStartDate",
//    	type: "POST",
//        contentType: 'application/json',
//        data: JSON.stringify({ SubmitDate: submidate }),
//    	success: function(data, status) {
//    		console.log(data);
//
//    		var tableHTML = `<table class="table table-bordered" style="width:100%;">
//                                <thead>
//                                    <tr>
//                                        <th>Tehasil</th>
//                                        <th>Percentage</th>
//                                    </tr>
//                                </thead>
//                                <tbody>`;
//
//
//    		data.slice(-5).forEach(dist => {
//
//    			tableHTML += `<tr>
//                              <td>` + dist.tehasil + `</td>
//                              <td>` + dist.percentagevalue + `</td>
//                            </tr>`;
//    		});
//
//    		// Close the table HTML
//    		tableHTML += `</tbody>
//                          </table>`;
//
//    		$('#Tehasilbottomcount').html(tableHTML);
//    	}
//    });
//}

function getallAjaxcallbySubmissionmonthandyear(enddate){
//console.log(enddate);
ortpsReport.destroy();
     ortpsReport = $('#ortpsdatatble').DataTable({
        scrollX: true,
        scrollY: 300,
        "ajax": {
            type: "POST",
            url: "/getOrtpscountbymonthandyear",
            contentType: "application/json; charset=utf-8",
            data: function (d) {
                var requestData = {
                    enddate: enddate
                };
              //  console.log("Request Data:", requestData);
                return JSON.stringify(requestData);
            },
                dataSrc: function (json) {
                console.log("Response Data:", json);
                return json;
            }
        },
        "columns": [
            {
                "data": "district", "className": "dt-head-center dt-body-center","render": function(data, type, full, meta) {
                    return '<div id="distId"  distlgd="' + full.districtlgd + '">' + data + '</div>';
                }
            },
            {
                "data": "total_applications", "className": "dt-head-center dt-body-center","render": function(data, type, full, meta) {
                   return '<div id="distId"  distlgd="' + full.districtlgd + '">' + data + '</div>';
            }
            },
            {
                "data": "forward_count", "className": "dt-head-center dt-body-center","render": function(data, type, full, meta) {
                   return '<div id="distId"  distlgd="' + full.districtlgd + '">' + data + '</div>';
            }
            },
            {
                "data": "ortps_count", "className": "dt-head-center dt-body-center","render": function(data, type, full, meta) {
                   return '<div id="distId"  distlgd="' + full.districtlgd + '">' + data + '</div>';
            }
            },
            {
                "data": "currentmonthapplicationreceived", "className": "dt-head-center dt-body-center","render": function(data, type, full, meta) {
                        if(full.currentmonthapplicationreceived == null){
                            return 0
                        }else{
                            return '<div>' + full.currentmonthapplicationreceived + '</div>';
                        }
                }
            },
            {
            //totalapplicationtobeprocessed
                "data": null,"className": "dt-head-center dt-body-center","render": function(data, type, full, meta) {
                   let currentmonthapplicationreceived = full.currentmonthapplicationreceived;
                   let forward_count = full.forward_count;
                   let sum = currentmonthapplicationreceived + forward_count;
                  // full.sum = sum;
                   return '<div>' + sum + '</div>';
                }
            },
            {
            //applicationprocessedcurrentmonth
                "data": null,"className": "dt-head-center dt-body-center","render": function(data, type, full, meta) {
                   let applicationprocessed = full.currentmonthapplicationreceived;
                   let totalapplicationtobeprocessed = full.currentmonth;
                   let sub = totalapplicationtobeprocessed + applicationprocessed;
                   //full.sub = sub;
                   return '<div>' + sub + '</div>';
                }
            },
            {
            //pending
                "data": null, "className": "dt-head-center dt-body-center","render": function(data, type, full, meta) {
					 let currentmonthapplicationreceived = full.currentmonthapplicationreceived;
                   let forward_count = full.forward_count;
                   let sum = currentmonthapplicationreceived + forward_count;
                   
                   let applicationprocessed = full.currentmonthapplicationreceived;
                   let totalapplicationtobeprocessed = full.currentmonth;
                   let sub = totalapplicationtobeprocessed + applicationprocessed;
                   let pending = sum-sub;
					
               // let sum = full.currentmonthapplicationreceived + full.forward_count
              /*  let sub = full.sub;
                    full.sum = sum;
                    full.sub = sub;
                    let abc = sum-sub;*/
                    return '<div>' + pending +'</div>'
                }
            },
            {
                "data": null, "className": "dt-head-center dt-body-center","render": function(data, type, full, meta) {
                        if(full){
                            return 0
                        }     }

            }
        ]
    });
//     $.ajax({
//          	url: "/getOrtpscountbymonthandyear",
//          	type: "POST",
//             contentType: 'application/json',
//             data: JSON.stringify({ enddate: enddate }),
//          	success: function(data, status) {
//             console.log(data);
//
//          		var tableHTML = `<table class ="table table-bordered center-table"style="width:100%;">
//                                  <thead>
//                                      <tr>
//                                          <th>District</th>
//                                          <th>TotalApplication</th>
//                                          <th>No of Pending</th>
//                                          <th>Totaltobeprocessed</th>
//                                          <th>CurrentMonthApplicationReceived</th>
//                                          <th>CurrentMonthPending</th>
//                                          <th>Totalprocessed</th>
//                                      </tr>
//                                  </thead>
//                                  <tbody>`;
//
//
//          		for(let dist of data) {
//         		//console.log(dist);
////         		console.log(dist.districtlgd == dist.currentmonthdistrictlgd);
////         		console.log(dist.total_applications);
////         		console.log(dist.currentmonthdistrictlgd);
//
//          			tableHTML += `<tr>
//                                <td>` + dist.district + `</td>
//                                <td>` + dist.total_applications + `</td>
//                                <td>` + dist.forward_count + `</td>
//                                <td>` + dist.totaltobeprocessed + `</td>
//                                <td>` + dist.currentmonthapplicationreceived + `</td>
//                                <td>` + dist.currentmonth + `</td>
//                                <td>` + dist.totalprocessed + `</td>
//                              </tr>`;
//          		}
//
//          		// Close the table HTML
//          		tableHTML += `</tbody>
//                            </table>`;
//
//          		$('#ortpsmonthyeartable').html(tableHTML);
//          	}
//          });
}

function autoAdjustColumns(table) {
    var container = table.table().container();
    var resizeObserver = new ResizeObserver(function () {
        table.columns.adjust();
    });
    resizeObserver.observe(container);
}


let abcReport = $('#districttbl').DataTable({
	scrollX: true,
	scrollY: 300,
});
let tehasilReport = $('#tehsiltbl').DataTable({
	responsive: true,
});


function showLoader() {
	$("#loader").show();
}

function hideLoader() {
	$("#loader").hide();
}

//ontouch of select displaying different services
$.ajax({
	type: "GET",
	url: "/getservicenamebystatuscount",
	success: function(data) {
		$('#Service').html('');
		console.log(data);
		let options = ``;
		for (let serv of data) {
			options += `<option value="` + serv.serviceid + `">` + serv.servicename + `</option>`
		}
		$('#Service').html(options);
		$('#Service').selectpicker('refresh');
	}, error: function(jqXHR) {
		jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : ""
	}
});
//getallmaxminavgmedianvalue
$.ajax({
    type: "GET",
    url: "/getalltimetakenvalue",
    beforeSend: function() {
        showLoader();
    },
    success: function(data) {
        console.log(data);

        var items = data[0];
        var maxtime = items[0];
        var mintime = items[1];
        var avgtime = items[2];
        var mediantime = items[3];

        // Update the HTML elements with the values
        document.getElementById("maxtime").innerText = maxtime;
        document.getElementById("mintime").innerText = mintime;
        document.getElementById("avgtime").innerText = avgtime;
        document.getElementById("mediantime").innerText = mediantime;

        hideLoader();
    },
    error: function(jqXHR) {
        jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : "";
    },
});





$.ajax({
	type: "GET",
	url: "/getservicenamebystatuscount",
	success: function(data) {
		$('#Servicename').html('');
		console.log(data);
		let options = ``;
		for (let serv of data) {
			options += `<option value="` + serv.serviceid + `">` + serv.servicename + `</option>`
		}
		$('#Servicename').html(options);
		$('#Servicename').selectpicker('refresh');
	}, error: function(jqXHR) {
		jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : ""
	}
});
//displaying dynamically cards using ajax call

$.ajax({
	type: "GET",
	url: "/getservicenamebystatuscount",
	success: function(data) {
		console.log(data);
		let totalDeliverCount = 0;
		let totalForwardCount = 0;
		let totalRejectCount = 0;
		let serviceNames = [];
		let totalAppliedCounts = [];
		let deliverCounts = [];
		let forwardCounts = [];
		let rejectCounts = [];

		data.forEach(function(service) {

			let serviceid = service.serviceid;
			let serviceName = service.servicename;
			let deliverCount = service.delivercount;
			let forwardCount = service.forwardcount;
			let rejectCount = service.rejectcount;
			let maxdiff = service.max_diff;
			let mindiff = service.min_diff;
			let avgdiff = service.avg_diff;
			let mediandiff = service.median_diff;

			totalDeliverCount += deliverCount;
			totalForwardCount += forwardCount;
			totalRejectCount += rejectCount;

			let totalAppliedCount = totalRejectCount + totalForwardCount + totalDeliverCount;
			serviceNames.push(serviceName);
			totalAppliedCounts.push(totalAppliedCount);
			deliverCounts.push(deliverCount);
			forwardCounts.push(forwardCount);
			rejectCounts.push(rejectCount);
			// Creating card structure dynamically for each service
			let cardHtml = `
             <div class="col-md-4">
              <div class="card mb-3">
                   <div class="card-header bgcolor text-center" id=${serviceid} >${serviceName}</div>
                   <div class="card-body">
                        <div class="row">
                         <div class="col-md-4">
                               <div class="card custom-border-color1 mb-3">
                                   <div class="card-body">
                                        <h6 class="card-title custom-font-size">Deliver Count</h6>
                                        <p class="card-text">${deliverCount}</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                               <div class="card custom-border-color2 mb-3">
                                    <div class="card-body">
                                       <h6 class="card-title", style="font-size: 14px">Pending Count</h6>
                                       <p class="card-text">${forwardCount}</p>
                                   </div>
                               </div>
                         </div>
                          <div class="col-md-4">
                              <div class="card custom-border-color3 mb-3">
                                  <div class="card-body">
                                        <h6 class="card-title", style="font-size: 15px">Reject Count</h6>
                                        <p class="card-text">${rejectCount}</p>
                                    </div>
                                </div>
                            </div>
                          <div class="col-md-3">
                              <div class="card custom-border-color4 mb-3">
                                  <div class="card-body">
                                       <h6 class="card-title">Max Time</h6>
                                       <p class="card-text">${maxdiff}</p>
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-3">
                              <div class="card custom-border-color5 mb-3">
                                 <div class="card-body">
                                      <h6 class="card-title">Min Time</h6>
                                      <p class="card-text">${mindiff}</p>
                                 </div>
                              </div>
                          </div>
                          <div class="col-md-3">
                              <div class="card custom-border-color6 mb-3">
                                   <div class="card-body">
                                        <h6 class="card-title">Avg Time</h6>
                                        <p class="card-text">${avgdiff}</p>
                                   </div>
                              </div>
                          </div>
                          <div class="col-md-3">
                             <div class="card custom-border-color7 mb-3">
                                  <div class="card-body">
                                       <h6 class="card-title">Median Time</h6>
                                       <p class="card-text">${mediandiff}</p>
                                  </div>
                             </div>
                          </div>
                        </div>
                    </div>
                </div>
                </div>
            `;
			$('#cardContainer').append(cardHtml);
			if (myPieChart) {
				myPieChart.destroy();
			}
			var ctx = document.getElementById('tripleLineChart').getContext('2d');
			myPieChart = new Chart(ctx, {
				type: 'bar',
				data: {
					labels: serviceNames,
					datasets: [
						{
							label: 'Total Applied',
							data: totalAppliedCounts,
							backgroundColor: '#ffd43b',
							borderColor: '#000000',
							borderWidth: 1
						},
						{
							label: 'Total Deliver',
							data: deliverCounts,
							backgroundColor: '#ffa94d',
							borderColor: '#000000',
							borderWidth: 1
						},
						/*		{
									label: 'Reject Count',
									data: rejectCounts,
									backgroundColor: 'rgba(255, 99, 132, 0.6)',
									borderColor: 'rgba(255, 99, 132, 1)',
									borderWidth: 1
								}*/
					]
				},
				options: {
                    responsive: true,
                    maintainAspectRatio: false,
				}
			})
		});
	},
	error: function(jqXHR) {
		if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
			showToast(jqXHR.responseJSON.message);
		}
	}
});

$('#District').on('change', function() {
    const serviceid = $('#Service').val();
    const district = $('#District').val();
	$("#appliedCount").html("");
	$("#deliverCount").html('');
	$("#forwardCount").html('');
	$("#rejectCount").html('');
	if ($('#District').val() === null || $('#District').val().length === 0) {
		$('#Service').trigger('change');
		return;
	}

    getallAjaxcallbyServiceIdandDistrict(serviceid,district);
});



//on change of select
$('#Service').on('change', function() {
    var service = $('#Service').val();
	$("#appliedCount").html("");
	$("#deliverCount").html('');
	$("#forwardCount").html('');
	$("#rejectCount").html('');

	getallAjaxcallbyServiceId(service);

});


//displaying bar chart by count
$.ajax({
	url: '/findapplicationstatuscountbydistrictwise',
	method: 'GET',
	dataType: 'json',
	success: function(data) {
		console.log(data)
		// Extract data from API response
		const districts = data.map(entry => entry.district);
		const deliverCounts = data.map(entry => entry.delivercount);
		const forwardCounts = data.map(entry => entry.forwardcount);
		const rejectCounts = data.map(entry => entry.rejectcount);

		// Create the chart
		var ctx = document.getElementById('districtBarChart').getContext('2d');
		 myPieCha = new Chart(ctx, {
			type: 'bar',
			data: {
				labels: districts,
				datasets: [
					{
						label: 'Deliver Count',
						data: deliverCounts,
						backgroundColor: '#ffa94d',
						borderColor: '#000000',
						borderWidth: 1
					},
					{
						label: 'Reject Count',
						data: rejectCounts,
						backgroundColor: '#4dabf7',
						borderColor: '#000000',
						borderWidth: 1
					},
					{
                        label: 'Pending Count',
                        data: forwardCounts,
                        backgroundColor: '#f03e3e',
                        borderColor: '#000000',
                        borderWidth: 1
                    }
				]
			},
			options: {
                responsive: true,
                maintainAspectRatio: false,
			}
		});
	},
	error: function(xhr, status, error) {
		console.error('Error fetching data:', error);
	}
});


//displaying the count cards value dynamically
async function fetchCounts() {
	// Make multiple AJAX requests to fetch the counts
	const [deliverCountResponse, forwardCountResponse, rejectCountResponse] = await Promise.all([
		$.ajax({ type: "GET", url: "/getCountDeliverData" }),
		$.ajax({ type: "GET", url: "/getCountForwardData" }),
		$.ajax({ type: "GET", url: "/getCountRejectData" })
	]);

	// Retrieve the counts from the AJAX responses
	const deliverCount = deliverCountResponse;
	const forwardCount = forwardCountResponse;
	const rejectCount = rejectCountResponse;
	const appliedCount = deliverCount + forwardCount + rejectCount;
	// Update the HTML elements with the counts

	$("#appliedCount").html(appliedCount);
	$("#deliverCount").html(deliverCount);
	$("#forwardCount").html(forwardCount);
	$("#rejectCount").html(rejectCount);
}
fetchCounts();

//displaying line chart using ajax call
//$.ajax({

/*$.ajax({
	url: '/getyearwisecount',
	method: 'GET',
	dataType: 'json',
	success: function(data) {
		console.log(data)
		// Extract data from API response
		const year = data.map(entry => entry.submiyear);
		const deliverCounts = data.map(entry => entry.deliver_count);
		const forwardCounts = data.map(entry => entry.forward_count);
		const rejectCounts = data.map(entry => entry.reject_count);

		// Create the chart
		const ctx = document.getElementById('tripleLineChart').getContext('2d');
		tripleLineChart = new Chart(ctx, {
			type: 'line',
			data: {
				labels: year,
				datasets: [{
					label: 'deliver',
					data: deliverCounts,
					borderColor: 'rgb(255, 99, 132)',
					fill: false

				},

				{

					label: 'Pending',
					data: forwardCounts,
					borderColor: 'rgb(54, 162, 235)',
					fill: false
				}, {
					label: 'Reject',
					data: rejectCounts,
					borderColor: 'rgb(75, 192, 192)',
					fill: false

				}
				]


			},
			options: {
				responsive: true,
				maintainAspectRatio: false
			}
		});
	},
	error: function(xhr, status, error) {
		console.error('Error fetching data:', error);
	}
});

//displaying half semi circle pie chart
});*/
$.ajax({
	url: '/getyearwisecount',
	method: 'GET',
	dataType: 'json',
	success: function(data) {
		console.log(data);
		// Extract data from API response
		const deliverCounts = data.map(entry => entry.deliver_count);
		const forwardCounts = data.map(entry => entry.forward_count);
		const rejectCounts = data.map(entry => entry.reject_count);

		// Calculate total counts for each category
		const totalDeliver = deliverCounts.reduce((acc, val) => acc + val, 0);
		const totalForward = forwardCounts.reduce((acc, val) => acc + val, 0);
		const totalReject = rejectCounts.reduce((acc, val) => acc + val, 0);

		// Calculate percentages for each category
		const totalCount = totalDeliver + totalForward + totalReject;
		const percentDeliver = (totalDeliver / totalCount) * 100;
		const percentForward = (totalForward / totalCount) * 100;
		const percentReject = (totalReject / totalCount) * 100;

		// Create the chart
		const ctx = document.getElementById('halfChart').getContext('2d');
		halfChart = new Chart(ctx, {
			type: 'doughnut',
			data: {
				labels: ['Deliver', 'Pending', 'Reject'],
				datasets: [{
					label: 'Percentage',
					data: [percentDeliver, percentReject, percentForward],
					backgroundColor: [
						'#ffa94d',
						'#4dabf7',
						'#f03e3e'
					],
					borderWidth: 1
				}]
			},
			options: {
				responsive: true,
				maintainAspectRatio: false,
				rotation: -90, // Rotate to make a semi-circle
				circumference: 180, // Only show 180 degrees (half circle)
				plugins: {
					legend: {
						display: true,
						position: 'top'
					},
					tooltip: {
						callbacks: {
							label: function(tooltipItem) {
								let label = tooltipItem.label || '';
								let value = tooltipItem.raw.toFixed(2);
								let count;
								if (label === 'Deliver') {
									count = totalDeliver;
								} else if (label === 'Reject') {
									count = totalReject;
								} else if (label === 'Pending') {
									count = totalForward;
								}
								return `${label}: ${value}% (${count} counts)`;
							}
						}
					},
					datalabels: {
						display: true,
						color: 'white',
						font: {
							weight: 'bold',
							size: 16
						},
						formatter: function(value, context) {
							return value.toFixed(2) + '%';
						}
					}
				},
				layout: {
					padding: {
						top: 20,
						bottom: 20
					}
				}
			},
			plugins: [ChartDataLabels]
		});
	},
	error: function(jqXHR) {
		if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
			showToast(jqXHR.responseJSON.message);
		}
	}
});

//get top performerbydistrictwise
$.ajax({
	url: "/gettopperformerbydistrictwise",
	type: "GET",

	success: function(data, status) {
		console.log(data);

		var tableHTML = `<table class ="table table-bordered border-dark"style="width:100%;">
                        <thead>
                            <tr>
                                <th>District</th>
                                <th>Percentage</th>
                            </tr>
                        </thead>
                        <tbody>`;


		data.slice(0,5).forEach(dist =>  {
			tableHTML += `<tr>
                      <td>` + dist.district + `</td>
                      <td>` + dist.percentagevalue + `</td>
                    </tr>`;
		});

		// Close the table HTML
		tableHTML += `</tbody>
                  </table>`;

		$('#topcount').html(tableHTML);
	}
});
//get bottom performerbydistrictwise
$.ajax({
	url: "/gettopperformerbydistrictwise",
	type: "GET",

	success: function(data, status) {
		console.log(data);

		var tableHTML = `<table class="table table-bordered border-dark" style="width:100%;">
                            <thead>
                                <tr>
                                    <th>District</th>
                                    <th>Percentage</th>
                                </tr>
                            </thead>
                            <tbody>`;


		data.slice(-5).forEach(dist => {
			tableHTML += `<tr>
                          <td>` + dist.district + `</td>
                          <td>` + dist.percentagevalue + `</td>
                        </tr>`;
		});

		// Close the table HTML
		tableHTML += `</tbody>
                      </table>`;

		$('#bottomcount').html(tableHTML);
	}
});
//top performerbytehasil
$.ajax({
	url: "/gettopPerformerByTehasil",
	type: "GET",
	success: function(data, status) {
		console.log(data);

		var tableHTML = `<table class="table table-bordered border-dark" style="width:100%;">
                            <thead>
                                <tr>
                                    <th>Tehasil</th>
                                    <th>Percentage</th>
                                </tr>
                            </thead>
                            <tbody>`;


		data.slice(0,5).forEach(dist => {
			tableHTML += `<tr>
                          <td>` + dist.tehasil + `</td>
                          <td>` + dist.percentagevalue + `</td>
                        </tr>`;
		});

		// Close the table HTML
		tableHTML += `</tbody>
                      </table>`;

		$('#Tehasiltopcount').html(tableHTML);
	}
});

//bottomperformerbytehasil
$.ajax({
	url: "/gettopPerformerByTehasil",
	type: "GET",

	success: function(data, status) {
		console.log(data);

		var tableHTML = `<table class="table table-bordered border-dark" style="width:100%;">
                            <thead>
                                <tr>
                                    <th>Tehasil</th>
                                    <th>Percentage</th>
                                </tr>
                            </thead>
                            <tbody>`;


		data.slice(-5).forEach(dist => {

			tableHTML += `<tr>
                          <td>` + dist.tehasil + `</td>
                          <td>` + dist.percentagevalue + `</td>
                        </tr>`;
		});

		// Close the table HTML
		tableHTML += `</tbody>
                      </table>`;

		$('#Tehasilbottomcount').html(tableHTML);
	}
});

//datatable
abcReport.destroy();
abcReport = $('#districttbl').DataTable({
	scrollX: true,
	scrollY: 300,
	"ajax": {
		"url": "/findapplicationstatuscountbydistrictwise",
		"type": "GET",
		"dataSrc": ""
	},

	"columns": [
		{
			"data": "district", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="distId"  distlgd="' + full.districtlgd + '">' + data + '</div>';
			}
		},
		{
			"data": "appliedcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="appl" appl_id="' + full.districtlgd + '">' + data + '</div>';
			}
		},
		{
			"data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="deliver" deli_id="' + full.districtlgd + '">' + data + '</div>';
			}
		},
		{
			"data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="reject" reject_id="' + full.districtlgd + '">' + data + '</div>';
			}
		},
		{
			"data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="pending" pend_id="' + full.districtlgd + '">' + data + '</div>';
			}
		},

		{
			"data": "ortpscount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="ortpscount" ortpscount_id="' + full.districtlgd + '">' + data + '</div>';
			}
		},
		{
			"data": "ortps_percentage", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="ortps_percent" percent_id="' + full.districtlgd + '">' + data + '</div>';
			}
		}
	],
		dom: 'Blftrip',
							buttons: [
								{
									extend: 'excelHtml5',
									text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
									titleAttr: 'Excel'
								},
								{
									extend: 'pdfHtml5',
									text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
									titleAttr: 'PDF'
								}
							],
});

tehasilReport.destroy();
tehasilReport = $('#tehsiltbl').DataTable({
	scrollX: true,
	scrollY: 300,
	"ajax": {
		"url": "/findapplicationstatuscountbytehasilwise",
		"type": "GET",
		"dataSrc": ""
	},

	"columns": [
		{
			"data": "district", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="distId"  distlgd="' + full.districtlgd + '">' + data + '</div>';
			}
		},
		{
			"data": "appliedcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="appl" appl_id="' + full.districtlgd + '">' + data + '</div>';
			}
		},
		{
			"data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="deliver" deli_id="' + full.districtlgd + '">' + data + '</div>';
			}
		},
		{
			"data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="reject" reject_id="' + full.districtlgd + '">' + data + '</div>';
			}
		},
		{
			"data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="pending" pend_id="' + full.districtlgd + '">' + data + '</div>';
			}
		},

		{
			"data": "ortpscount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="ortpscount" ortpscount_id="' + full.districtlgd + '">' + data + '</div>';
			}
		},
		{
			"data": "ortps_percentage", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="ortps_percent" percent_id="' + full.districtlgd + '">' + data + '</div>';
			}
		}
	],
		dom: 'Blftrip',
							buttons: [
								{
									extend: 'excelHtml5',
									text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
									titleAttr: 'Excel'
								},
								{
									extend: 'pdfHtml5',
									text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
									titleAttr: 'PDF'
								}
							],
});


$('#districttbl').on('click', '#ortpscount, #pending', function(){
    var id = $(this).attr("ortpscount_id") || $(this).attr("pend_id");
    console.log(id);
  
    if($(this).attr("id") === "ortpscount"){
        url = "/getofficebyortpscount/" + id;
        ofcDetail.destroy();
        ofcDetail = $('#officelist').DataTable({
            scrollCollapse: true,
            scrollX: true,
            scrollY: 300,
            "ajax": {
                "url": url,
                "type": "GET",
                "dataSrc": ""
            },
            "columns": [
                {"data": null, "render": function (data, type, row){
                    return `<div id="userid" userLgd="` + data[1]+ `"> `+ data[0] +` </div>`;
                }},
                {"data": null, "render": function (data, type, row){
                    return data[2];
                }}
            ]
        });
        autoAdjustColumns(ofcDetail);
        ofcModal.show();
    } else if ($(this).attr("id") === "pending"){
        url = "/getofficenamebypendingcount/" + id;
        pendingdetail.destroy();
        pendingdetail = $('#example1').DataTable({
            scrollCollapse: true,
            scrollX: true,
            scrollY: 300,
            "ajax": {
                "url": url,
                "type": "GET",
                "dataSrc": ""
            },
            "columns": [
                {"data": null, "render": function (data, type, row){
                    return `<div id="userId" userlgd="` + data[1]+ `"> `+ data[0] +` </div>`
                }},
                {"data": null, "render": function (data, type, row){
                    return data[2];
                }}
            ]
        });
        autoAdjustColumns(pendingdetail);
        pendingModal.show();
    }
});
$('#officelist').on('click', '#userid', function(){
    let currentlyOpenRow = null;
    var id = $(this).attr("userLgd");
    console.log(id);

    var url;
    let tr = $(this).closest('tr');
    let row = ofcDetail.row(tr);
    let rowData = row.data();
    //console.log(rowData.length);
    console.log(rowData);
    if (row) {
    		// Close the currently open row if it's not the same row being clicked
    		if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
    			var openRow = ofcDetail.row(currentlyOpenRow);
    			openRow.child.hide();
    			currentlyOpenRow.removeClass('shown');
    			currentlyOpenRow = null;
    		}
    $.ajax({
        url: "/findusernameandtaskidbyortpscount/" + id,
        type: "GET",
        success: function(data, status) {
            console.log(data);

            var childRowContent = `<table id="listofUsername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                <thead>
                    <tr>
                        <th>User Name</th>
                        <th>TaskId</th>
                        <th>Task Name</th>
                        <th>Count</th>
                    </tr>
                </thead>
                <tbody>`;

            for (let dist of data) {
                childRowContent += `<tr>
                    <td id="username" tehasillgd="` + dist[0] + `">`+ dist[0] +`</td>
                    <td id="taskid" appl_id="` + dist[1] + `">`+ dist[1] +`</td>
                    <td id="taskname" appl_id="` + dist[2] + `">`+ dist[2] +`</td>
                    <td id="count" deli_id="` + dist[3] + `">`+ dist[3] +`</td>
                </tr>`;
            }

            // Closing the table
            childRowContent += `</tbody></table>`;

            if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
                row.child.hide();
                tr.removeClass('shown');
                currentlyOpenRow = null;
            } else {
                row.child(childRowContent).show();
                tr.addClass('shown');
                currentlyOpenRow = tr;
            }
        },
        error: function(xhr, textStatus, errorThrown) {
            console.error("Error fetching child row data:", errorThrown);
        }
    });
    }
});
$('#example1').on('click', '#userId', function(){
    let currentlyOpenRow = null;
    var id = $(this).attr("userlgd");
    console.log(id);

    var url;
    let tr = $(this).closest('tr');
    let row = pendingdetail.row(tr);
    let rowData = row.data();
    //console.log(rowData.length);
    console.log(rowData);
    if (row) {
    		// Close the currently open row if it's not the same row being clicked
    		if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
    			var openRow = pendingdetail.row(currentlyOpenRow);
    			openRow.child.hide();
    			currentlyOpenRow.removeClass('shown');
    			currentlyOpenRow = null;
    		}
    $.ajax({
        url: "/findusernameandtaskidbyofficetype/" + id,
        type: "GET",
        success: function(data, status) {
            console.log(data);

            var childRowContent = `<table id="listofusername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                <thead>
                    <tr>
                        <th>User Name</th>
                        <th>TaskId</th>
                         <th>Task Name</th>
                        <th>Count</th>
                    </tr>
                </thead>
                <tbody>`;

            for (let dist of data) {
                childRowContent += `<tr>
                    <td id="username" tehasillgd="` + dist[0] + `">`+ dist[0] +`</td>
                    <td id="taskid" appl_id="` + dist[1] + `">`+ dist[1] +`</td>
                     <td id="taskname" appl_id="` + dist[2] + `">`+ dist[2] +`</td>
                    <td id="count" deli_id="` + dist[3] + `">`+ dist[3] +`</td>
                </tr>`;
            }

            // Closing the table
            childRowContent += `</tbody></table>`;

            if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
                row.child.hide();
                tr.removeClass('shown');
                currentlyOpenRow = null;
            } else {
                row.child(childRowContent).show();
                tr.addClass('shown');
                currentlyOpenRow = tr;
            }
        },
        error: function(xhr, textStatus, errorThrown) {
            console.error("Error fetching child row data:", errorThrown);
        }
    });
    }
});


$('#districttbl').on('click', '#distId', function(){
    var id = $(this).attr("distlgd");
    console.log(id);

    var url;
    let tr = $(this).closest('tr');
    let row = abcReport.row(tr);
    let rowData = row.data();
    //console.log(rowData.length);
    console.log(rowData);
    if (row) {
    		// Close the currently open row if it's not the same row being clicked
    		if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
    			var openRow = abcReport.row(currentlyOpenRow);
    			openRow.child.hide();
    			currentlyOpenRow.removeClass('shown');
    			currentlyOpenRow = null;
    		}
    $.ajax({
        url: "/getAppliedPendingRejectOrtpsCountOrtpspercentagebytehasil/" + id,
        type: "GET",
        success: function(data, status) {
            console.log(data);

            var childRowContent = `<table id="listoftehasil" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                <thead>
                    <tr>
                        <th>Tehasil Name</th>
                        <th>Applied Count</th>
                        <th>Deliver Count</th>
                        <th>Reject Count</th>
                        <th>Pending Count</th>
                        <th>Ortps Count</th>
                        <th>Ortps Percentage</th>
                    </tr>
                </thead>
                <tbody>`;

            for (let dist of data) {
                childRowContent += `<tr>
                    <td id="tehasil" tehasillgd="` + dist.tehasillgd + `">` + dist.tehasil + `</td>
                    <td id="applied" appl_id="` + dist.tehasillgd + `">` + dist.districtStatusModel.appliedcount + `</td>
                    <td id="delivered" deli_id="` + dist.tehasillgd + `">` + dist.districtStatusModel.delivercount + `</td>
                    <td id="rejected" rjct_id="` + dist.tehasillgd + `">` + dist.districtStatusModel.rejectcount + `</td>
                    <td id="pend" pend_id="` + dist.tehasillgd + `">` + dist.districtStatusModel.forwardcount + `</td>
                    <td id="ortps" ortpscount_id="` + dist.tehasillgd + `">` + dist.districtStatusModel.ortpscount + `</td>
                    <td id="ortps-percentage" ortpspercent_id="` + dist.tehasillgd + `">` + dist.districtStatusModel.ortps_percentage + `</td>
                </tr>`;
            }

            // Closing the table
            childRowContent += `</tbody></table>`;

            if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
                row.child.hide();
                tr.removeClass('shown');
                currentlyOpenRow = null;
            } else {
                row.child(childRowContent).show();
                tr.addClass('shown');
                currentlyOpenRow = tr;
            }
        },
        error: function(xhr, textStatus, errorThrown) {
            console.error("Error fetching child row data:", errorThrown);
        }
    });
    }
});
$(document).on('click', '#listoftehasil td#pend, #listoftehasil td#ortps', function() {
    var id = $(this).attr("pend_id") || $(this).attr("ortpscount_id");
    console.log(id);

    if ($(this).attr("id") === "pend") {
        var url = "/findofficenamebypendingcountoftehasil/" + id;
         TotalDetail.destroy();
         TotalDetail= $('#example').DataTable({
            scrollCollapse: true,
            scrollX: true,
            scrollY: 300,
            ajax: {
                url: url,
                type: "GET",
                dataSrc: ""
            },
            columns: [
                {"data": null, "render": function (data, type, row){
                    return `<div id="officeid" officeLgd="` + data[1]+ `"> `+ data[0] +` </div>`;
                }},
                {"data": null, "render": function (data, type, row){
                    return data[2];
                }}
            ],
        });
        autoAdjustColumns(TotalDetail);
        TotalTehasilModal.show();
    } else if ($(this).attr("id") === "ortps") {
        var url = "/getofficebytehasilortpscount/" + id;
        ofcTehasilDetail.destroy();
        ofcTehasilDetail = $('#tehasiloffice').DataTable({
            scrollCollapse: true,
            scrollX: true,
            scrollY: 300,
            ajax: {
                url: url,
                type: "GET",
                dataSrc: ""
            },
            columns: [
                {"data": null, "render": function (data, type, row){
                    return `<div id="Officeid" officelgd="` + data[1]+ `"> `+ data[0] +` </div>`;
                }},
                {"data": null, "render": function (data, type, row){
                    return data[1];
                }}
            ],
        });
        autoAdjustColumns(ofcTehasilDetail);
        ofcTehasilDetailModal.show();
    }
});

$('#example').on('click', '#officeid', function() {
    let currentlyOpenRow = null;

    var id = $(this).attr("officeLgd");
    console.log(id);
    let tr = $(this).closest('tr');
    console.log(tr);
    let row = TotalDetail.row(tr);
    let rowData = row.data();
    console.log(rowData);

    if (row) {
        // Close the currently open row if it's not the same row being clicked
        if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
            var openRow = TotalDetail.row(currentlyOpenRow);
            if (openRow.child && openRow.child.isShown()) {
                openRow.child.hide();
            }
            currentlyOpenRow.removeClass('shown');
            currentlyOpenRow = null;
        }

        $.ajax({
            url: "/findusernameandtaskidbyofficetype/" + id,
            type: "GET",
            success: function(data, status) {
                console.log(data);

                var childRowContent = `<table id="listofUsername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                    <thead>
                        <tr>
                            <th>User Name</th>
                            <th>TaskId</th>
                            <th>Count</th>
                        </tr>
                    </thead>
                    <tbody>`;

                for (let dist of data) {
                    childRowContent += `<tr>
                        <td id="username" tehasillgd="` + dist[0] + `">`+ dist[0] +`</td>
                        <td id="taskid" appl_id="` + dist[1] + `">`+ dist[1] +`</td>
                        <td id="count" deli_id="` + dist[2] + `">`+ dist[2] +`</td>
                    </tr>`;
                }

                // Closing the table
                childRowContent += `</tbody></table>`;

                if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
                    row.child.hide();
                    tr.removeClass('shown');
                    currentlyOpenRow = null;
                } else {
                    row.child(childRowContent).show();
                    tr.addClass('shown');
                    currentlyOpenRow = tr;
                }
            },
            error: function(xhr, textStatus, errorThrown) {
                console.error("Error fetching child row data:", errorThrown);
            }
        });
    }
});

$('#tehasiloffice').on('click', '#Officeid', function() {
    let currentlyOpenRow = null;
    var id = $(this).attr("officelgd");
    console.log(id);
    var url;
        let tr = $(this).closest('tr');
        let row = ofcTehasilDetail.row(tr);
        let rowData = row.data();
        //console.log(rowData.length);
        console.log(rowData);
        if (row) {
        		// Close the currently open row if it's not the same row being clicked
        		if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
        			var openRow = ofcTehasilDetail.row(currentlyOpenRow);
        			openRow.child.hide();
        			currentlyOpenRow.removeClass('shown');
        			currentlyOpenRow = null;
        		}
        $.ajax({
            url: "/findusernameandtaskidbyofficetype/" + id,
            type: "GET",
            success: function(data, status) {
                console.log(data);

                var childRowContent = `<table id="listofUsername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                    <thead>
                        <tr>
                            <th>User Name</th>
                            <th>TaskId</th>
                            <th>Count</th>
                        </tr>
                    </thead>
                    <tbody>`;

                for (let dist of data) {
                    childRowContent += `<tr>
                        <td id="username" tehasillgd="` + dist[0] + `">`+ dist[0] +`</td>
                        <td id="taskid" appl_id="` + dist[1] + `">`+ dist[1] +`</td>
                        <td id="count" deli_id="` + dist[2] + `">`+ dist[2] +`</td>
                    </tr>`;
                }

                // Closing the table
                childRowContent += `</tbody></table>`;

                if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
                    row.child.hide();
                    tr.removeClass('shown');
                    currentlyOpenRow = null;
                } else {
                    row.child(childRowContent).show();
                    tr.addClass('shown');
                    currentlyOpenRow = tr;
                }
            },
            error: function(xhr, textStatus, errorThrown) {
                console.error("Error fetching child row data:", errorThrown);
            }
        });
        }
});

//
//var startDateInput = document.getElementById('startDate');
//startDateInput.addEventListener('change', function() {
//    var Submissiondate = $('#startDate').val();
//    var selectedDate = startDateInput.value;
//
//    // Parse date into parts
//    var parts = selectedDate.split('-');
//    var formattedDate = parts[2] + '-' + parts[1] + '-' + parts[0]; // DD-MM-YYYY format
//
//    console.log('Selected start date:', formattedDate);
//    getallAjaxcallbyStartdate(formattedDate);
//});

var monthyearInput = document.getElementById('monthyear');
monthyearInput.addEventListener('change', function() {
    var Enddate = $('#monthyear').val();
    console.log(Enddate);
    // Assuming the value is in the format 'YYYY-MM'
//    var selectedmonthyear = monthyearInput.value;
//    var parts = selectedmonthyear.split('-');
//
//    // Swap month and year
//    var formattedmonthyear = parts[0] + '-' + parts[1];
//    console.log(formattedmonthyear);
    getallAjaxcallbySubmissionmonthandyear(Enddate);
});













