var myPieChart;
var halfChart;
var myPieCha;
var currentlyOpenRow = null;

let TotalDetail = $('#example').DataTable({
	scrollCollapse: true,
	scrollY: 300,
	scrollX: true,
});
var TotalTehasilModal = new bootstrap.Modal(document.getElementById('tehasilmodal'));

let ofcDetail = $('#officelist').DataTable({
	scrollCollapse: true,
	scrollY: 300,
	scrollX: true,
});
var ofcModal = new bootstrap.Modal(document.getElementById('officemodal'));

let ofcTehasilDetail = $('#tehasiloffice').DataTable({
	scrollCollapse: true,
	scrollY: 300,
	scrollX: true,
});
var ofcTehasilDetailModal = new bootstrap.Modal(document.getElementById('officetehasilmodal'));

let pendingdetail = $('#example1').DataTable({
	scrollCollapse: true,
	scrollY: 300,
	scrollX: true,
});
var pendingModal = new bootstrap.Modal(document.getElementById('datatablemodal'));


let ortpsReport = $('#ortpsdatatble').DataTable({
	scrollX: true,
	scrollY: 300,
});
let servicetable = $('#servicetbl').DataTable({
	scrollX: true,
	scrollY: 300,
});


servicetable.destroy();
servicetable = $('#servicetbl').DataTable({
	scrollX: true,
	scrollY: 300,
	"ajax": {
		"url": "/findMaxMinTimeByService",
		"type": "GET",
		"dataSrc": ""
	},

	"columns": [
		{
			"data": "servicename", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="distId"  distlgd="' + full.serviceid + '">' + data + '</div>';
			}
		},

		{
			"data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
			}
		},
		{
			"data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="reject" reject_id="' + full.serviceid + '">' + data + '</div>';
			}
		},
		{
			"data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="pending" pend_id="' + full.serviceid + '">' + data + '</div>';
			}
		},

		{
			"data": "max_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="ortpscount" ortpscount_id="' + full.serviceid + '">' + data + '</div>';
			}
		},
		{
			"data": "min_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
			}
		},
		{
			"data": "avg_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
			}
		},
		{
			"data": "median_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
			}
		}
	],
	dom: 'Blftrip',
	buttons: [
		{
			extend: 'excelHtml5',
			text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
			titleAttr: 'Excel'
		},
		{
			extend: 'pdfHtml5',
			text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
			titleAttr: 'PDF'
		}
	],
});
function getallAjaxcallbyServiceId(serviceid) {

	$.ajax({
		type: "POST",
		url: "/findortpscountbyserviceId",
		contentType: 'application/json',
		data: JSON.stringify({ serviceIds: serviceid }),
		success: function(data) {
			console.log(data)
			// Extract data from API response
			const districts = data.map(entry => entry.district);
			const deliverCounts = data.map(entry => entry.delivercount);
			const forwardCounts = data.map(entry => entry.forwardcount);
			const rejectCounts = data.map(entry => entry.rejectcount);
			if (myPieCha) {
				myPieCha.destroy();
			}
			// Create the chart
			var ctx = document.getElementById('districtBarChart').getContext('2d');
			myPieCha = new Chart(ctx, {
				type: 'bar',
				data: {
					labels: districts,
				datasets: [
					{
						label: 'Deliver Count',
						data: deliverCounts,
						backgroundColor: '#ffa94d',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Reject Count',
						data: rejectCounts,
						backgroundColor: '#4dabf7',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Pending Count',
						data: forwardCounts,
						backgroundColor: '#f03e3e',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					}
				]
			},
			options: {
				 indexAxis: 'y',
				responsive: true,
				maintainAspectRatio: false,
				 scales: {
            x: {
                stacked: true // Enable stacking on x-axis
            },
            y: {
                stacked: true // Enable stacking on y-axis
            }
        }
			}
		});
		},
		error: function(xhr, status, error) {
			console.error('Error fetching data:', error);
		}
	});




	$.ajax({
		type: "POST",
		url: "/getDistinctMainGrandZoneByservice",
		contentType: 'application/json',
		data: JSON.stringify({ serviceIds: serviceid }),
		success: function(data) {
			console.log(data);
			$('#mZone').html('');
			let options = ``;

			for (let ofc of data) {
				options += `<option value="` + ofc[0] + `">` + ofc[1] + `</option>`;
			}
			$('#mZone').html(options);
			$('#mZone').selectpicker('refresh');
		}, error: function(jqXHR) {
			jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : ""
		}
	});




}







function autoAdjustColumns(table) {
	var container = table.table().container();
	var resizeObserver = new ResizeObserver(function() {
		table.columns.adjust();
	});
	resizeObserver.observe(container);
}



let zoneReport = $('#zonetbl').DataTable({
	scrollX: true,
	scrollY: 300,
});



function showLoader() {
	$("#loader").show();
}

function hideLoader() {
	$("#loader").hide();
}
zoneReport.destroy();
zoneReport = $('#zonetbl').DataTable({
	scrollX: true,
	scrollY: 300,
	"ajax": {
		"url": "/getEnergyAllcountByService",
		"type": "GET",
		"dataSrc": function(json) {
			let appliedCount = 0, deliverCount = 0, forwardCount = 0, rejectCount = 0, amountCount = 0;


			json.forEach(item => {
				appliedCount += item.appliedcount || 0;
				deliverCount += item.delivercount || 0;
				forwardCount += item.forwardcount || 0;
				rejectCount += item.rejectcount || 0;
				amountCount += item.total_payment_amount || 0;
			});


			$("#appliedCount").html(appliedCount);
			$("#deliverCount").html(deliverCount);
			$("#forwardCount").html(forwardCount);
			$("#rejectCount").html(rejectCount);
			$("#totalAmountCount").html(amountCount);

			return json;
		}
	},

	"columns": [
		{
			"data": "service", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="distId"  distlgd="' + full.serviceid + '">' + data + '</div>';
			}
		},
		{
			"data": "appliedcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="appl" appl_id="' + full.serviceid + '">' + data + '</div>';
			}
		},
		{
			"data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
			}
		},
		{
			"data": "ortpsdelivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="ortpsdeliver" deli_id="' + full.serviceid + '">' + data + '</div>';
			}
		},
		{
			"data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="reject" reject_id="' + full.serviceid + '">' + data + '</div>';
			}
		},
		{
			"data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="pending" pend_id="' + full.serviceid + '">' + data + '</div>';
			}
		},

		{
			"data": "ortpscount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="ortpscount" ortpscount_id="' + full.serviceid + '">' + data + '</div>';
			}
		},
		{
			"data": "ortps_percentage", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
			}
		},
		{
			"data": "total_payment_amount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
				return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
			}
		}
	],
	dom: 'Blftrip',
	buttons: [
		{
			extend: 'excelHtml5',
			text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
			titleAttr: 'Excel'
		},
		{
			extend: 'pdfHtml5',
			text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
			titleAttr: 'PDF'
		}
	],
});
$('#zonetbl').on('click', '#ortpscount, #pending', function() {
	var id = $(this).attr("ortpscount_id") || $(this).attr("pend_id");
	console.log(id);
	if ($(this).attr("id") === "ortpscount") {
		let url = "/getpendingOrtpsDataByserviceId/" + id;
		ofcDetail.destroy();
		ofcDetail = $('#officelist').DataTable({
			scrollCollapse: true,
			scrollX: true,
			scrollY: 300,
			"ajax": {
				"url": url,
				"type": "GET",
				"dataSrc": ""
			},
			"columns": [
				{
					"data": "user_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
						return '<div id="OuserId" getlgd=' + id + ' getserviceId=' + id + ' userlgd="' + full.user_name + '">' + data + '</div>';
					}
				},
				{
					"data": "count", "className": "dt-head-center dt-body-center",
				},


			],
		});
		autoAdjustColumns(ofcDetail);
		ofcModal.show();
	} else if ($(this).attr("id") === "pending") {
		let url = "/getpendingDataByserviceId/" + id;
		ofcDetail.destroy();
		ofcDetail = $('#officelist').DataTable({
			scrollCollapse: true,
			scrollX: true,
			scrollY: 300,
			"ajax": {
				"url": url,
				"type": "GET",
				"dataSrc": ""
			},
			"columns": [
				{
					"data": "user_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
						return '<div id="PuserId" getlgd=' + id + ' getserviceId=' + id + ' userlgd="' + full.user_name + '">' + data + '</div>';
					}
				},
				{
					"data": "count", "className": "dt-head-center dt-body-center",
				},


			],
		});
		autoAdjustColumns(pendingdetail);
		ofcModal.show();
	}
});

$('#officelist').on('click', '#PuserId', function() {
	// let currentlyOpenRow = null;
	let id = $(this).attr("userLgd");
	let service = $(this).attr("getserviceId")
	console.log(id);

	var url;
	let tr = $(this).closest('tr');
	let row = ofcDetail.row(tr);
	let rowData = row.data();

	console.log(rowData);

	if (row) {
		// Close the currently open row if it's not the same row being clicked
		if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
			var openRow = ofcDetail.row(currentlyOpenRow);
			openRow.child.hide();
			currentlyOpenRow.removeClass('shown');
			currentlyOpenRow = null;
		}
		if (currentlyOpenRow) {
			ofcDetail.row(currentlyOpenRow).child.hide();
			currentlyOpenRow.removeClass('shown');
			currentlyOpenRow = null;
		}
		$.ajax({
			type: "POST",
			url: "/getPendingTaskDataByUsername",
			contentType: 'application/json',
			data: JSON.stringify({ serviceIds: [service], user_name: id }),
			success: function(data) {
				console.log(data);

				var childRowContent = `<table id="listofUsername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                <thead>
                    <tr>
                        
                        <th>Task Name</th>
                        <th>Count</th>
                         <th>Total Amount</th>
                    </tr>
                </thead>
                <tbody>`;

				for (let dist of data) {
					childRowContent += `<tr>
                    
                   
                    <td id="taskname" >`+ dist.task_name + `</td>
                    <td id="count" >`+ dist.task_count + `</td>
                     <td id="taskid" >`+ dist.total_payment_amount + `</td>
                </tr>`;
				}

				// Closing the table
				childRowContent += `</tbody></table>`;

				if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
					row.child.hide();
					tr.removeClass('shown');
					currentlyOpenRow = null;
				} else {
					row.child(childRowContent).show();
					tr.addClass('shown');
					currentlyOpenRow = tr;
				}
			},
			error: function(xhr, textStatus, errorThrown) {
				console.error("Error fetching child row data:", errorThrown);
			}
		});
	}
});
$('#officelist').on('click', '#OuserId', function() {
	// let currentlyOpenRow = null;
	let id = $(this).attr("userLgd");
	let service = $(this).attr("getserviceId")
	console.log(id);

	var url;
	let tr = $(this).closest('tr');
	let row = ofcDetail.row(tr);
	let rowData = row.data();

	console.log(rowData);

	if (row) {
		// Close the currently open row if it's not the same row being clicked
		if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
			var openRow = ofcDetail.row(currentlyOpenRow);
			openRow.child.hide();
			currentlyOpenRow.removeClass('shown');
			currentlyOpenRow = null;
		}
		if (currentlyOpenRow) {
			ofcDetail.row(currentlyOpenRow).child.hide();
			currentlyOpenRow.removeClass('shown');
			currentlyOpenRow = null;
		}
		$.ajax({
			type: "POST",
			url: "/getPendingOrtpsTaskDataByUsername",
			contentType: 'application/json',
			data: JSON.stringify({ serviceIds: [service], user_name: id }),
			success: function(data) {
				console.log(data);

				var childRowContent = `<table id="listofUsername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                <thead>
                    <tr>
                        
                        <th>Task Name</th>
                        <th>Count</th>
                         <th>Total Amount</th>
                    </tr>
                </thead>
                <tbody>`;

				for (let dist of data) {
					childRowContent += `<tr>
                    
                   
                    <td id="taskname" >`+ dist.task_name + `</td>
                    <td id="count" >`+ dist.task_count + `</td>
                     <td id="taskid" >`+ dist.total_payment_amount + `</td>
                </tr>`;
				}

				// Closing the table
				childRowContent += `</tbody></table>`;

				if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
					row.child.hide();
					tr.removeClass('shown');
					currentlyOpenRow = null;
				} else {
					row.child(childRowContent).show();
					tr.addClass('shown');
					currentlyOpenRow = tr;
				}
			},
			error: function(xhr, textStatus, errorThrown) {
				console.error("Error fetching child row data:", errorThrown);
			}
		});
	}
});
//ontouch of select displaying different services
$.ajax({
	type: "GET",
	url: "/getEnergyserviceDetails",
	success: function(data) {
		$('#Service').html('');
		console.log(data);
		let options = ``;
		for (let serv of data) {
			options += `<option value="` + serv[0] + `">` + serv[1] + `</option>`
		}
		$('#Service').html(options);
		$('#Service').selectpicker('refresh');
	}, error: function(jqXHR) {
		jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : ""
	}
});
//getallmaxminavgmedianvalue
$.ajax({
	type: "GET",
	url: "/getalltimetakenvalue",
	beforeSend: function() {
		showLoader();
	},
	success: function(data) {
		console.log(data);

		var items = data[0];
		var maxtime = items[0];
		var mintime = items[1];
		var avgtime = items[2];
		var mediantime = items[3];

		// Update the HTML elements with the values
		document.getElementById("maxtime").innerText = maxtime;
		document.getElementById("mintime").innerText = mintime;
		document.getElementById("avgtime").innerText = avgtime;
		document.getElementById("mediantime").innerText = mediantime;

		hideLoader();
	},
	error: function(jqXHR) {
		jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : "";
	},
});





$.ajax({
	type: "GET",
	url: "/getservicenamebystatuscount",
	success: function(data) {
		$('#Servicename').html('');
		console.log(data);
		let options = ``;
		for (let serv of data) {
			options += `<option value="` + serv.serviceid + `">` + serv.servicename + `</option>`
		}
		$('#Servicename').html(options);
		$('#Servicename').selectpicker('refresh');
	}, error: function(jqXHR) {
		jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : ""
	}
});
//displaying dynamically cards using ajax call



$('#Office').on('change', function() {
	const serviceid = $('#Service').val();
	const Zone = $('#Office').val();

	let deliverCount = 0;
	let forwardCount = 0;
	let rejectCount = 0;
	$("#appliedCount").html("");
	$("#deliverCount").html('');
	$("#forwardCount").html('');
	$("#rejectCount").html('');
	$("#totalAmountCount").html('');
	if ($('#Office').val() === null || $('#Office').val().length === 0) {
		$('#cZone').trigger('change');
		return;
	}
	zoneReport.destroy();
	zoneReport = $('#zonetbl').DataTable({
		scrollX: true,
		scrollY: 300,
		"ajax": {
			"url": "/getDistinctCountByserviceandofcZone",
			"type": "POST",
			"contentType": "application/json",  // ✅ Added this line
			"data": function(d) {
				return JSON.stringify({ serviceIds: serviceid, main_lgd: Zone });
			},
			"dataSrc": function(json) {
				let appliedCount = 0, deliverCount = 0, forwardCount = 0, rejectCount = 0, amountCount = 0;


				json.forEach(item => {
					appliedCount += item.appliedcount || 0;
					deliverCount += item.delivercount || 0;
					forwardCount += item.forwardcount || 0;
					rejectCount += item.rejectcount || 0;
					amountCount += item.total_payment_amount || 0;
				});


				$("#appliedCount").html(appliedCount);
				$("#deliverCount").html(deliverCount);
				$("#forwardCount").html(forwardCount);
				$("#rejectCount").html(rejectCount);
				$("#totalAmountCount").html(amountCount);
				setTimeout(function() {
					// Destroy previous charts if they exist
					if (typeof myPieCha !== "undefined" && myPieCha !== null) {
						myPieCha.destroy();
					}
					if (typeof halfChart !== "undefined" && halfChart !== null) {
						halfChart.destroy();
					}

					// Debug JSON Response
					console.log("Chart Data:", json);

					// Get chart contexts
					var ctxBar = document.getElementById("districtBarChart").getContext("2d");
					var ctxDoughnut = document.getElementById("halfChart").getContext("2d");

					// Extract Data
					let labels = json.map(item => item.zone_name);
					let deliverCounts = json.map(item => item.delivercount || 0);
					let rejectCounts = json.map(item => item.rejectcount || 0);
					let pendingCounts = json.map(item => item.forwardcount || 0);

					// Create Bar Chart
					myPieCha = new Chart(ctxBar, {
						type: "bar",
						data: {
							labels: labels,
							datasets: [
					{
						label: 'Deliver Count',
						data: deliverCounts,
						backgroundColor: '#ffa94d',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Reject Count',
						data: rejectCounts,
						backgroundColor: '#4dabf7',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Pending Count',
						data: pendingCounts,
						backgroundColor: '#f03e3e',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					}
				]
			},
			options: {
				 indexAxis: 'y',
				responsive: true,
				maintainAspectRatio: false,
				 scales: {
            x: {
                stacked: true // Enable stacking on x-axis
            },
            y: {
                stacked: true // Enable stacking on y-axis
            }
        }
			}
		});

					// Calculate Percentages for Doughnut Chart
					let totalDeliverCount = deliverCounts.reduce((sum, val) => sum + val, 0);
					let totalRejectCount = rejectCounts.reduce((sum, val) => sum + val, 0);
					let totalForwardCount = pendingCounts.reduce((sum, val) => sum + val, 0);
					let totalCount = totalDeliverCount + totalRejectCount + totalForwardCount;

					let percentDeliver = totalCount > 0 ? (totalDeliverCount / totalCount) * 100 : 0;
					let percentReject = totalCount > 0 ? (totalRejectCount / totalCount) * 100 : 0;
					let percentForward = totalCount > 0 ? (totalForwardCount / totalCount) * 100 : 0;

					// ✅ Create Half Doughnut Chart with ChartDataLabels Plugin
					halfChart = new Chart(ctxDoughnut, {
						type: "doughnut",
						data: {
							labels: ["Deliver", "Reject", "Pending"],
							datasets: [{
								label: "Percentage",
								data: [percentDeliver, percentReject, percentForward],
								backgroundColor: ["#ffa94d", "#4dabf7", "#f03e3e"],
								borderWidth: 1
							}]
						},
						options: {
							responsive: true,
							maintainAspectRatio: false,
							rotation: -90, // Rotate to make a semi-circle
							circumference: 180, // Only show 180 degrees (half circle)
							plugins: {
								legend: {
									display: true,
									position: "top"
								},
								tooltip: {
									callbacks: {
										label: function(tooltipItem) {
											let label = tooltipItem.label || "";
											let value = tooltipItem.raw.toFixed(2);
											let count;
											if (label === "Deliver") {
												count = totalDeliverCount;
											} else if (label === "Pending") {
												count = totalForwardCount;
											} else if (label === "Reject") {
												count = totalRejectCount;
											}
											return `${label}: ${value}% (${count} counts)`;
										}
									}
								},
								datalabels: {  // ✅ Add ChartDataLabels configuration
									display: true,
									color: "white",
									font: {
										weight: "bold",
										size: 16
									},
									formatter: function(value) {
										return value.toFixed(2) + "%";
									}
								}
							},
							layout: {
								padding: {
									top: 20,
									bottom: 20
								}
							}
						},
						plugins: [ChartDataLabels] // ✅ Add ChartDataLabels plugin
					});

				}, 500);

				return json;
			}
		},

		"columns": [
			{
				"data": "zone_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="distId"  distlgd="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "appliedcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="appl" appl_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "ortpsdelivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="reject" reject_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="pendingO" pend_id="' + full.lgd_code + '">' + data + '</div>';
				}
			},

			{
				"data": "ortpscount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortpscountO" ortpscount_id="' + full.lgd_code + '">' + data + '</div>';
				}
			},
			{
				"data": "ortps_percentage", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "total_payment_amount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			}
		],
		dom: 'Blftrip',
		buttons: [
			{
				extend: 'excelHtml5',
				text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
				titleAttr: 'Excel'
			},
			{
				extend: 'pdfHtml5',
				text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
				titleAttr: 'PDF'
			}
		],
	});
	$('#zonetbl').on('click', '#ortpscountO, #pendingO', function() {
		var id = $(this).attr("ortpscount_id") || $(this).attr("pend_id");
		console.log(id);
		if ($(this).attr("id") === "ortpscountO") {
			let url = "/getpendingOrtpsDataByserviceIdAndOfcZone";
			ofcDetail.destroy();
			ofcDetail = $('#officelist').DataTable({
				scrollCollapse: true,
				scrollX: true,
				scrollY: 300,
				"ajax": {
					"url": url,
					"type": "POST",
					"contentType": "application/json",  // ✅ Added this line
					"data": function(d) {
						return JSON.stringify({ serviceIds: serviceid, main_lgd: [id] });
					},
					"dataSrc": ""
				},
				"columns": [
					{
						"data": "user_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
							return '<div id="OOuserId" getlgd=' + id + ' getserviceId=' + serviceid + ' userlgd="' + full.user_name + '">' + data + '</div>';
						}

					},
					{
						"data": "count", "className": "dt-head-center dt-body-center",
					}


				],
			});
			autoAdjustColumns(ofcDetail);
			ofcModal.show();
		} else if ($(this).attr("id") === "pendingO") {
			let url = "/getpendingDataByserviceIdAndOfcZone";
			ofcDetail.destroy();
			ofcDetail = $('#officelist').DataTable({
				scrollCollapse: true,
				scrollX: true,
				scrollY: 300,
				"ajax": {
					"url": url,
					"type": "POST",
					"contentType": "application/json",  // ✅ Added this line
					"data": function(d) {
						return JSON.stringify({ serviceIds: serviceid, main_lgd: [id] });
					},
					"dataSrc": ""
				},
				"columns": [
					{
						"data": "user_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
							return '<div id="POuserId" getlgd=' + id + ' getserviceId=' + serviceid + ' userlgd="' + full.user_name + '">' + data + '</div>';
						}
					},
					{
						"data": "count", "className": "dt-head-center dt-body-center",
					}


				],
			});
			autoAdjustColumns(pendingdetail);
			ofcModal.show();
		}
	});
	$('#officelist').on('click', '#POuserId', function() {
		// let currentlyOpenRow = null;
		let id = $(this).attr("userLgd");
		let lgdid = $(this).attr("getlgd");
		let service = $(this).attr("getserviceId")
		console.log(id);

		var url;
		let tr = $(this).closest('tr');
		let row = ofcDetail.row(tr);
		let rowData = row.data();

		console.log(rowData);

		if (row) {
			// Close the currently open row if it's not the same row being clicked
			if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
				var openRow = ofcDetail.row(currentlyOpenRow);
				openRow.child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			if (currentlyOpenRow) {
				ofcDetail.row(currentlyOpenRow).child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			$.ajax({
				type: "POST",
				url: "/getpendingTaskDataByserviceIdAndUsernameAndOfcZone",
				contentType: 'application/json',
				data: JSON.stringify({ serviceIds: [service], user_name: id, main_lgd: [lgdid] }),
				success: function(data) {
					console.log(data);

					var childRowContent = `<table id="listofUsername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                <thead>
                    <tr>
                        
                        <th>Task Name</th>
                        <th>Count</th>
                         <th>Total Amount</th>
                    </tr>
                </thead>
                <tbody>`;

					for (let dist of data) {
						childRowContent += `<tr>
                    
                   
                    <td id="taskname" >`+ dist.task_name + `</td>
                    <td id="count" >`+ dist.task_count + `</td>
                     <td id="taskid" >`+ dist.total_payment_amount + `</td>
                </tr>`;
					}

					// Closing the table
					childRowContent += `</tbody></table>`;

					if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
						row.child.hide();
						tr.removeClass('shown');
						currentlyOpenRow = null;
					} else {
						row.child(childRowContent).show();
						tr.addClass('shown');
						currentlyOpenRow = tr;
					}
				},
				error: function(xhr, textStatus, errorThrown) {
					console.error("Error fetching child row data:", errorThrown);
				}
			});
		}
	});
	$('#officelist').on('click', '#OOuserId', function() {
		// let currentlyOpenRow = null;
		let id = $(this).attr("userLgd");
		let lgdid = $(this).attr("getlgd");
		let service = $(this).attr("getserviceId")
		console.log(id);

		var url;
		let tr = $(this).closest('tr');
		let row = ofcDetail.row(tr);
		let rowData = row.data();

		console.log(rowData);

		if (row) {
			// Close the currently open row if it's not the same row being clicked
			if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
				var openRow = ofcDetail.row(currentlyOpenRow);
				openRow.child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			if (currentlyOpenRow) {
				ofcDetail.row(currentlyOpenRow).child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			$.ajax({
				type: "POST",
				url: "/getpendingOrtpsDataByserviceIdAndUsernameAndOfcZone",
				contentType: 'application/json',
				data: JSON.stringify({ serviceIds: [service], user_name: id, main_lgd: [lgdid] }),
				success: function(data) {
					console.log(data);

					var childRowContent = `<table id="listofUsername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                <thead>
                    <tr>
                        
                        <th>Task Name</th>
                        <th>Count</th>
                         <th>Total Amount</th>
                    </tr>
                </thead>
                <tbody>`;

					for (let dist of data) {
						childRowContent += `<tr>
                    
                   
                    <td id="taskname" >`+ dist.task_name + `</td>
                    <td id="count" >`+ dist.task_count + `</td>
                     <td id="taskid" >`+ dist.total_payment_amount + `</td>
                </tr>`;
					}

					// Closing the table
					childRowContent += `</tbody></table>`;

					if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
						row.child.hide();
						tr.removeClass('shown');
						currentlyOpenRow = null;
					} else {
						row.child(childRowContent).show();
						tr.addClass('shown');
						currentlyOpenRow = tr;
					}
				},
				error: function(xhr, textStatus, errorThrown) {
					console.error("Error fetching child row data:", errorThrown);
				}
			});
		}
	});
	servicetable.destroy();
	servicetable = $('#servicetbl').DataTable({
		scrollX: true,
		scrollY: 300,
		"ajax": {
			"url": "/getMaxMinCountByServiceAndOfczone",
			"type": "POST",
			"contentType": "application/json",  // ✅ Added this line
			"data": function(d) {
				return JSON.stringify({ serviceIds: serviceid, main_lgd: Zone });
			},
			"dataSrc": ""
		},

		"columns": [
			{
				"data": "servicename", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="distId"  distlgd="' + full.serviceid + '">' + data + '</div>';
				}
			},

			{
				"data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="reject" reject_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="pending" pend_id="' + full.serviceid + '">' + data + '</div>';
				}
			},

			{
				"data": "max_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortpscount" ortpscount_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "min_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "avg_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "median_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			}
		],
		dom: 'Blftrip',
		buttons: [
			{
				extend: 'excelHtml5',
				text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
				titleAttr: 'Excel'
			},
			{
				extend: 'pdfHtml5',
				text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
				titleAttr: 'PDF'
			}
		],
	});


});
$('#mZone').on('change', function() {
	$("#appliedCount").html("");
	$("#deliverCount").html('');
	$("#forwardCount").html('');
	$("#rejectCount").html('');
	$("#totalAmountCount").html('');
	let deliverCount = 0;
	let forwardCount = 0;
	let rejectCount = 0;

	if ($('#mZone').val() === null || $('#mZone').val().length === 0) {
		$('#Service').trigger('change');
		return;
	}
	const serviceid = $('#Service').val();
	const Zone = $('#mZone').val();
	zoneReport.destroy();
	zoneReport = $('#zonetbl').DataTable({
		scrollX: true,
		scrollY: 300,
		"ajax": {
			"url": "/getDistinctCountByserviceandmainZone",
			"type": "POST",
			"contentType": "application/json",  // ✅ Added this line
			"data": function(d) {
				return JSON.stringify({ serviceIds: serviceid, main_lgd: Zone });
			},
			"dataSrc": function(json) {
				let appliedCount = 0, deliverCount = 0, forwardCount = 0, rejectCount = 0, amountCount = 0;


				json.forEach(item => {
					appliedCount += item.appliedcount || 0;
					deliverCount += item.delivercount || 0;
					forwardCount += item.forwardcount || 0;
					rejectCount += item.rejectcount || 0;
					amountCount += item.total_payment_amount || 0;
				});


				$("#appliedCount").html(appliedCount);
				$("#deliverCount").html(deliverCount);
				$("#forwardCount").html(forwardCount);
				$("#rejectCount").html(rejectCount);
				$("#totalAmountCount").html(amountCount);
				setTimeout(function() {
					// Destroy previous charts if they exist
					if (typeof myPieCha !== "undefined" && myPieCha !== null) {
						myPieCha.destroy();
					}
					if (typeof halfChart !== "undefined" && halfChart !== null) {
						halfChart.destroy();
					}

					// Debug JSON Response
					console.log("Chart Data:", json);

					// Get chart contexts
					var ctxBar = document.getElementById("districtBarChart").getContext("2d");
					var ctxDoughnut = document.getElementById("halfChart").getContext("2d");

					// Extract Data
					let labels = json.map(item => item.zone_name);
					let deliverCounts = json.map(item => item.delivercount || 0);
					let rejectCounts = json.map(item => item.rejectcount || 0);
					let pendingCounts = json.map(item => item.forwardcount || 0);

					// Create Bar Chart
					myPieCha = new Chart(ctxBar, {
						type: "bar",
						data: {
							labels: labels,
						datasets: [
					{
						label: 'Deliver Count',
						data: deliverCounts,
						backgroundColor: '#ffa94d',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Reject Count',
						data: rejectCounts,
						backgroundColor: '#4dabf7',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Pending Count',
						data: pendingCounts,
						backgroundColor: '#f03e3e',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					}
				]
			},
			options: {
				 indexAxis: 'y',
				responsive: true,
				maintainAspectRatio: false,
				 scales: {
            x: {
                stacked: true // Enable stacking on x-axis
            },
            y: {
                stacked: true // Enable stacking on y-axis
            }
        }
			}
		});

					// Calculate Percentages for Doughnut Chart
					let totalDeliverCount = deliverCounts.reduce((sum, val) => sum + val, 0);
					let totalRejectCount = rejectCounts.reduce((sum, val) => sum + val, 0);
					let totalForwardCount = pendingCounts.reduce((sum, val) => sum + val, 0);
					let totalCount = totalDeliverCount + totalRejectCount + totalForwardCount;

					let percentDeliver = totalCount > 0 ? (totalDeliverCount / totalCount) * 100 : 0;
					let percentReject = totalCount > 0 ? (totalRejectCount / totalCount) * 100 : 0;
					let percentForward = totalCount > 0 ? (totalForwardCount / totalCount) * 100 : 0;

					// ✅ Create Half Doughnut Chart with ChartDataLabels Plugin
					halfChart = new Chart(ctxDoughnut, {
						type: "doughnut",
						data: {
							labels: ["Deliver", "Reject", "Pending"],
							datasets: [{
								label: "Percentage",
								data: [percentDeliver, percentReject, percentForward],
								backgroundColor: ["#ffa94d", "#4dabf7", "#f03e3e"],
								borderWidth: 1
							}]
						},
						options: {
							responsive: true,
							maintainAspectRatio: false,
							rotation: -90, // Rotate to make a semi-circle
							circumference: 180, // Only show 180 degrees (half circle)
							plugins: {
								legend: {
									display: true,
									position: "top"
								},
								tooltip: {
									callbacks: {
										label: function(tooltipItem) {
											let label = tooltipItem.label || "";
											let value = tooltipItem.raw.toFixed(2);
											let count;
											if (label === "Deliver") {
												count = totalDeliverCount;
											} else if (label === "Pending") {
												count = totalForwardCount;
											} else if (label === "Reject") {
												count = totalRejectCount;
											}
											return `${label}: ${value}% (${count} counts)`;
										}
									}
								},
								datalabels: {  // ✅ Add ChartDataLabels configuration
									display: true,
									color: "white",
									font: {
										weight: "bold",
										size: 16
									},
									formatter: function(value) {
										return value.toFixed(2) + "%";
									}
								}
							},
							layout: {
								padding: {
									top: 20,
									bottom: 20
								}
							}
						},
						plugins: [ChartDataLabels] // ✅ Add ChartDataLabels plugin
					});

				}, 500);

				return json;
			}
		},

		"columns": [
			{
				"data": "zone_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="distId"  distlgd="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "appliedcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="appl" appl_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "ortpsdelivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="reject" reject_id="' + full.lgd_code + '">' + data + '</div>';
				}
			},
			{
				"data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="pendingM" pend_id="' + full.lgd_code + '">' + data + '</div>';
				}
			},

			{
				"data": "ortpscount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortpscountM" ortpscount_id="' + full.lgd_code + '">' + data + '</div>';
				}
			},
			{
				"data": "ortps_percentage", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "total_payment_amount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			}
		],
		dom: 'Blftrip',
		buttons: [
			{
				extend: 'excelHtml5',
				text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
				titleAttr: 'Excel'
			},
			{
				extend: 'pdfHtml5',
				text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
				titleAttr: 'PDF'
			}
		],
	});
	$('#zonetbl').on('click', '#ortpscountM, #pendingM', function() {
		var id = $(this).attr("ortpscount_id") || $(this).attr("pend_id");
		console.log(id);
		if ($(this).attr("id") === "ortpscountM") {
			let url = "/getpendingOrtpsDataByserviceIdAndMainZone";
			ofcDetail.destroy();
			ofcDetail = $('#officelist').DataTable({
				scrollCollapse: true,
				scrollX: true,
				scrollY: 300,
				"ajax": {
					"url": url,
					"type": "POST",
					"contentType": "application/json",  // ✅ Added this line
					"data": function(d) {
						return JSON.stringify({ serviceIds: serviceid, main_lgd: [id] });
					},
					"dataSrc": ""
				},
				"columns": [
					{
						"data": "user_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
							return '<div id="OMuserId" getlgd=' + id + ' getserviceId="' + serviceid + '" userlgd="' + full.user_name + '">' + data + '</div>';
						}
					},
					{
						"data": "count", "className": "dt-head-center dt-body-center",
					}


				],
			});
			autoAdjustColumns(ofcDetail);
			ofcModal.show();
		} else if ($(this).attr("id") === "pendingM") {
			let url = "/getpendingDataByserviceIdAndMainZone";
			ofcDetail.destroy();
			ofcDetail = $('#officelist').DataTable({
				scrollCollapse: true,
				scrollX: true,
				scrollY: 300,
				"ajax": {
					"url": url,
					"type": "POST",
					"contentType": "application/json",  // ✅ Added this line
					"data": function(d) {
						return JSON.stringify({ serviceIds: serviceid, main_lgd: [id] });
					},
					"dataSrc": ""
				},
				"columns": [
					{
						"data": "user_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
							return '<div id="PMuserId" getlgd=' + id + ' getserviceId="' + serviceid + '" userlgd="' + full.user_name + '">' + data + '</div>';
						}
					},
					{
						"data": "count", "className": "dt-head-center dt-body-center",
					}


				],
			});
			autoAdjustColumns(pendingdetail);
			ofcModal.show();
		}
	});
	$('#officelist').on('click', '#PMuserId', function() {
		// let currentlyOpenRow = null;
		let id = $(this).attr("userLgd");
		let lgdid = $(this).attr("getlgd");
		let service = $(this).attr("getserviceId")
		console.log(id);

		var url;
		let tr = $(this).closest('tr');
		let row = ofcDetail.row(tr);
		let rowData = row.data();

		console.log(rowData);

		if (row) {
			// Close the currently open row if it's not the same row being clicked
			if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
				var openRow = ofcDetail.row(currentlyOpenRow);
				openRow.child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			if (currentlyOpenRow) {
				ofcDetail.row(currentlyOpenRow).child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			$.ajax({
				type: "POST",
				url: "/getpendingTaskDataByserviceIdAndUsernameAndMainZone",
				contentType: 'application/json',
				data: JSON.stringify({ serviceIds: [service], user_name: id, main_lgd: [lgdid] }),
				success: function(data) {
					console.log(data);

					var childRowContent = `<table id="listofUsername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                <thead>
                    <tr>
                        
                        <th>Task Name</th>
                        <th>Count</th>
                         <th>Total Amount</th>
                    </tr>
                </thead>
                <tbody>`;

					for (let dist of data) {
						childRowContent += `<tr>
                    
                   
                    <td id="taskname" >`+ dist.task_name + `</td>
                    <td id="count" >`+ dist.task_count + `</td>
                     <td id="taskid" >`+ dist.total_payment_amount + `</td>
                </tr>`;
					}

					// Closing the table
					childRowContent += `</tbody></table>`;

					if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
						row.child.hide();
						tr.removeClass('shown');
						currentlyOpenRow = null;
					} else {
						row.child(childRowContent).show();
						tr.addClass('shown');
						currentlyOpenRow = tr;
					}
				},
				error: function(xhr, textStatus, errorThrown) {
					console.error("Error fetching child row data:", errorThrown);
				}
			});
		}
	});
	$('#officelist').on('click', '#OMuserId', function() {
		// let currentlyOpenRow = null;
		let id = $(this).attr("userLgd");
		let lgdid = $(this).attr("getlgd");
		let service = $(this).attr("getserviceId")
		console.log(id);

		var url;
		let tr = $(this).closest('tr');
		let row = ofcDetail.row(tr);
		let rowData = row.data();

		console.log(rowData);

		if (row) {
			// Close the currently open row if it's not the same row being clicked
			if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
				var openRow = ofcDetail.row(currentlyOpenRow);
				openRow.child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			if (currentlyOpenRow) {
				ofcDetail.row(currentlyOpenRow).child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			$.ajax({
				type: "POST",
				url: "/getpendingOrtpsDataByserviceIdAndUsernameAndMainZone",
				contentType: 'application/json',
				data: JSON.stringify({ serviceIds: [service], user_name: id, main_lgd: [lgdid] }),
				success: function(data) {
					console.log(data);

					var childRowContent = `<table id="listofUsername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                <thead>
                    <tr>
                        
                        <th>Task Name</th>
                        <th>Count</th>
                         <th>Total Amount</th>
                    </tr>
                </thead>
                <tbody>`;

					for (let dist of data) {
						childRowContent += `<tr>
                    
                   
                    <td id="taskname" >`+ dist.task_name + `</td>
                    <td id="count" >`+ dist.task_count + `</td>
                     <td id="taskid" >`+ dist.total_payment_amount + `</td>
                </tr>`;
					}

					// Closing the table
					childRowContent += `</tbody></table>`;

					if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
						row.child.hide();
						tr.removeClass('shown');
						currentlyOpenRow = null;
					} else {
						row.child(childRowContent).show();
						tr.addClass('shown');
						currentlyOpenRow = tr;
					}
				},
				error: function(xhr, textStatus, errorThrown) {
					console.error("Error fetching child row data:", errorThrown);
				}
			});
		}
	});
	servicetable.destroy();
	servicetable = $('#servicetbl').DataTable({
		scrollX: true,
		scrollY: 300,
		"ajax": {
			"url": "/getMaxMinCountByServiceAndMainzone",
			"type": "POST",
			"contentType": "application/json",  // ✅ Added this line
			"data": function(d) {
				return JSON.stringify({ serviceIds: serviceid, main_lgd: Zone });
			},
			"dataSrc": ""
		},

		"columns": [
			{
				"data": "servicename", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="distId"  distlgd="' + full.serviceid + '">' + data + '</div>';
				}
			},

			{
				"data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="reject" reject_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="pending" pend_id="' + full.serviceid + '">' + data + '</div>';
				}
			},

			{
				"data": "max_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortpscount" ortpscount_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "min_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "avg_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "median_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			}
		],
		dom: 'Blftrip',
		buttons: [
			{
				extend: 'excelHtml5',
				text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
				titleAttr: 'Excel'
			},
			{
				extend: 'pdfHtml5',
				text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
				titleAttr: 'PDF'
			}
		],
	});

	$.ajax({
		type: "POST",
		url: "/getDistinctGrandZoneByserviceAndMainzone",
		contentType: 'application/json',
		data: JSON.stringify({ serviceIds: serviceid, zoneid: Zone }),
		success: function(data) {
			console.log(data);
			$('#gZone').html('');
			let options = ``;

			for (let ofc of data) {
				options += `<option value="` + ofc[0] + `">` + ofc[1] + `</option>`;
			}
			$('#gZone').html(options);
			$('#gZone').selectpicker('refresh');
		}, error: function(jqXHR) {
			jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : ""
		}
	});


});
$('#pZone').on('change', function() {
	$("#appliedCount").html("");
	$("#deliverCount").html('');
	$("#forwardCount").html('');
	$("#rejectCount").html('');
	$("#totalAmountCount").html('');
	if ($('#pZone').val() === null || $('#pZone').val().length === 0) {
		$('#gZone').trigger('change');
		return;
	}
	let deliverCount = 0;
	let forwardCount = 0;
	let rejectCount = 0;
	const serviceid = $('#Service').val();
	const Zone = $('#pZone').val();
	zoneReport.destroy();
	zoneReport = $('#zonetbl').DataTable({
		scrollX: true,
		scrollY: 300,
		"ajax": {
			"url": "/getDistinctCountByserviceandparentZone",
			"type": "POST",
			"contentType": "application/json",  // ✅ Added this line
			"data": function(d) {
				return JSON.stringify({ serviceIds: serviceid, main_lgd: Zone });
			},
			"dataSrc": function(json) {
				let appliedCount = 0, deliverCount = 0, forwardCount = 0, rejectCount = 0, amountCount = 0;


				json.forEach(item => {
					appliedCount += item.appliedcount || 0;
					deliverCount += item.delivercount || 0;
					forwardCount += item.forwardcount || 0;
					rejectCount += item.rejectcount || 0;
					amountCount += item.total_payment_amount || 0;
				});


				$("#appliedCount").html(appliedCount);
				$("#deliverCount").html(deliverCount);
				$("#forwardCount").html(forwardCount);
				$("#rejectCount").html(rejectCount);
				$("#totalAmountCount").html(amountCount);
				setTimeout(function() {
					// Destroy previous charts if they exist
					if (typeof myPieCha !== "undefined" && myPieCha !== null) {
						myPieCha.destroy();
					}
					if (typeof halfChart !== "undefined" && halfChart !== null) {
						halfChart.destroy();
					}

					// Debug JSON Response
					console.log("Chart Data:", json);

					// Get chart contexts
					var ctxBar = document.getElementById("districtBarChart").getContext("2d");
					var ctxDoughnut = document.getElementById("halfChart").getContext("2d");

					// Extract Data
					let labels = json.map(item => item.zone_name);
					let deliverCounts = json.map(item => item.delivercount || 0);
					let rejectCounts = json.map(item => item.rejectcount || 0);
					let pendingCounts = json.map(item => item.forwardcount || 0);

					// Create Bar Chart
					myPieCha = new Chart(ctxBar, {
						type: "bar",
						data: {
							labels: labels,
							datasets: [
					{
						label: 'Deliver Count',
						data: deliverCounts,
						backgroundColor: '#ffa94d',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Reject Count',
						data: rejectCounts,
						backgroundColor: '#4dabf7',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Pending Count',
						data: pendingCounts,
						backgroundColor: '#f03e3e',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					}
				]
			},
			options: {
				 indexAxis: 'y',
				responsive: true,
				maintainAspectRatio: false,
				 scales: {
            x: {
                stacked: true // Enable stacking on x-axis
            },
            y: {
                stacked: true // Enable stacking on y-axis
            }
        }
			}
		});

					// Calculate Percentages for Doughnut Chart
					let totalDeliverCount = deliverCounts.reduce((sum, val) => sum + val, 0);
					let totalRejectCount = rejectCounts.reduce((sum, val) => sum + val, 0);
					let totalForwardCount = pendingCounts.reduce((sum, val) => sum + val, 0);
					let totalCount = totalDeliverCount + totalRejectCount + totalForwardCount;

					let percentDeliver = totalCount > 0 ? (totalDeliverCount / totalCount) * 100 : 0;
					let percentReject = totalCount > 0 ? (totalRejectCount / totalCount) * 100 : 0;
					let percentForward = totalCount > 0 ? (totalForwardCount / totalCount) * 100 : 0;

					// ✅ Create Half Doughnut Chart with ChartDataLabels Plugin
					halfChart = new Chart(ctxDoughnut, {
						type: "doughnut",
						data: {
							labels: ["Deliver", "Reject", "Pending"],
							datasets: [{
								label: "Percentage",
								data: [percentDeliver, percentReject, percentForward],
								backgroundColor: ["#ffa94d", "#4dabf7", "#f03e3e"],
								borderWidth: 1
							}]
						},
						options: {
							responsive: true,
							maintainAspectRatio: false,
							rotation: -90, // Rotate to make a semi-circle
							circumference: 180, // Only show 180 degrees (half circle)
							plugins: {
								legend: {
									display: true,
									position: "top"
								},
								tooltip: {
									callbacks: {
										label: function(tooltipItem) {
											let label = tooltipItem.label || "";
											let value = tooltipItem.raw.toFixed(2);
											let count;
											if (label === "Deliver") {
												count = totalDeliverCount;
											} else if (label === "Pending") {
												count = totalForwardCount;
											} else if (label === "Reject") {
												count = totalRejectCount;
											}
											return `${label}: ${value}% (${count} counts)`;
										}
									}
								},
								datalabels: {  // ✅ Add ChartDataLabels configuration
									display: true,
									color: "white",
									font: {
										weight: "bold",
										size: 16
									},
									formatter: function(value) {
										return value.toFixed(2) + "%";
									}
								}
							},
							layout: {
								padding: {
									top: 20,
									bottom: 20
								}
							}
						},
						plugins: [ChartDataLabels] // ✅ Add ChartDataLabels plugin
					});

				}, 500);
				return json;
			}
		},

		"columns": [
			{
				"data": "zone_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="distId"  distlgd="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "appliedcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="appl" appl_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "ortpsdelivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="reject" reject_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="pendingP" pend_id="' + full.lgd_code + '">' + data + '</div>';
				}
			},

			{
				"data": "ortpscount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortpscountP" ortpscount_id="' + full.lgd_code + '">' + data + '</div>';
				}
			},
			{
				"data": "ortps_percentage", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "total_payment_amount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			}
		],
		dom: 'Blftrip',
		buttons: [
			{
				extend: 'excelHtml5',
				text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
				titleAttr: 'Excel'
			},
			{
				extend: 'pdfHtml5',
				text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
				titleAttr: 'PDF'
			}
		],
	});
	$('#zonetbl').on('click', '#ortpscountP, #pendingP', function() {
		var id = $(this).attr("ortpscount_id") || $(this).attr("pend_id");
		console.log(id);
		if ($(this).attr("id") === "ortpscountP") {
			let url = "/getpendingOrtpsDataByserviceIdAndParentZone";
			ofcDetail.destroy();
			ofcDetail = $('#officelist').DataTable({
				scrollCollapse: true,
				scrollX: true,
				scrollY: 300,
				"ajax": {
					"url": url,
					"type": "POST",
					"contentType": "application/json",  // ✅ Added this line
					"data": function(d) {
						return JSON.stringify({ serviceIds: serviceid, main_lgd: [id] });
					},
					"dataSrc": ""
				},
				"columns": [
					{
						"data": "user_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
							return '<div id="OPuserId" getlgd=' + id + ' getserviceId=' + serviceid + ' userlgd="' + full.user_name + '">' + data + '</div>';
						}
					},
					{
						"data": "count", "className": "dt-head-center dt-body-center",
					}


				],
			});
			autoAdjustColumns(ofcDetail);
			ofcModal.show();
		} else if ($(this).attr("id") === "pendingP") {
			let url = "/getpendingDataByserviceIdAndParentZone";
			ofcDetail.destroy();
			ofcDetail = $('#officelist').DataTable({
				scrollCollapse: true,
				scrollX: true,
				scrollY: 300,
				"ajax": {
					"url": url,
					"type": "POST",
					"contentType": "application/json",  // ✅ Added this line
					"data": function(d) {
						return JSON.stringify({ serviceIds: serviceid, main_lgd: [id] });
					},
					"dataSrc": ""
				},
				"columns": [
					{
						"data": "user_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
							return '<div id="PPuserId" getlgd=' + id + ' getserviceId=' + serviceid + ' userlgd="' + full.user_name + '">' + data + '</div>';
						}
					},
					{
						"data": "count", "className": "dt-head-center dt-body-center",
					}


				],
			});
			autoAdjustColumns(pendingdetail);
			ofcModal.show();
		}
	});
	$('#officelist').on('click', '#PPuserId', function() {
		// let currentlyOpenRow = null;
		let id = $(this).attr("userLgd");
		let lgdid = $(this).attr("getlgd");
		let service = $(this).attr("getserviceId")
		console.log(id);

		var url;
		let tr = $(this).closest('tr');
		let row = ofcDetail.row(tr);
		let rowData = row.data();

		console.log(rowData);

		if (row) {
			// Close the currently open row if it's not the same row being clicked
			if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
				var openRow = ofcDetail.row(currentlyOpenRow);
				openRow.child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			if (currentlyOpenRow) {
				ofcDetail.row(currentlyOpenRow).child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			$.ajax({
				type: "POST",
				url: "/getpendingTaskDataByserviceIdAndUsernameAndParentZone",
				contentType: 'application/json',
				data: JSON.stringify({ serviceIds: [service], user_name: id, main_lgd: [lgdid] }),
				success: function(data) {
					console.log(data);

					var childRowContent = `<table id="listofUsername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                <thead>
                    <tr>
                        
                        <th>Task Name</th>
                        <th>Count</th>
                         <th>Total Amount</th>
                    </tr>
                </thead>
                <tbody>`;

					for (let dist of data) {
						childRowContent += `<tr>
                    
                   
                    <td id="taskname" >`+ dist.task_name + `</td>
                    <td id="count" >`+ dist.task_count + `</td>
                     <td id="taskid" >`+ dist.total_payment_amount + `</td>
                </tr>`;
					}

					// Closing the table
					childRowContent += `</tbody></table>`;

					if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
						row.child.hide();
						tr.removeClass('shown');
						currentlyOpenRow = null;
					} else {
						row.child(childRowContent).show();
						tr.addClass('shown');
						currentlyOpenRow = tr;
					}
				},
				error: function(xhr, textStatus, errorThrown) {
					console.error("Error fetching child row data:", errorThrown);
				}
			});
		}
	});
	$('#officelist').on('click', '#OPuserId', function() {
		// let currentlyOpenRow = null;
		let id = $(this).attr("userLgd");
		let lgdid = $(this).attr("getlgd");
		let service = $(this).attr("getserviceId")
		console.log(id);

		var url;
		let tr = $(this).closest('tr');
		let row = ofcDetail.row(tr);
		let rowData = row.data();

		console.log(rowData);

		if (row) {
			// Close the currently open row if it's not the same row being clicked
			if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
				var openRow = ofcDetail.row(currentlyOpenRow);
				openRow.child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			if (currentlyOpenRow) {
				ofcDetail.row(currentlyOpenRow).child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			$.ajax({
				type: "POST",
				url: "/getpendingOrtpsDataByserviceIdAndUsernameAndParentZone",
				contentType: 'application/json',
				data: JSON.stringify({ serviceIds: [service], user_name: id, main_lgd: [lgdid] }),
				success: function(data) {
					console.log(data);

					var childRowContent = `<table id="listofUsername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                <thead>
                    <tr>
                        
                        <th>Task Name</th>
                        <th>Count</th>
                         <th>Total Amount</th>
                    </tr>
                </thead>
                <tbody>`;

					for (let dist of data) {
						childRowContent += `<tr>
                    
                   
                    <td id="taskname" >`+ dist.task_name + `</td>
                    <td id="count" >`+ dist.task_count + `</td>
                     <td id="taskid" >`+ dist.total_payment_amount + `</td>
                </tr>`;
					}

					// Closing the table
					childRowContent += `</tbody></table>`;

					if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
						row.child.hide();
						tr.removeClass('shown');
						currentlyOpenRow = null;
					} else {
						row.child(childRowContent).show();
						tr.addClass('shown');
						currentlyOpenRow = tr;
					}
				},
				error: function(xhr, textStatus, errorThrown) {
					console.error("Error fetching child row data:", errorThrown);
				}
			});
		}
	});
	servicetable.destroy();
	servicetable = $('#servicetbl').DataTable({
		scrollX: true,
		scrollY: 300,
		"ajax": {
			"url": "/getMaxMinCountByServiceAndParentzone",
			"type": "POST",
			"contentType": "application/json",  // ✅ Added this line
			"data": function(d) {
				return JSON.stringify({ serviceIds: serviceid, main_lgd: Zone });
			},
			"dataSrc": ""
		},

		"columns": [
			{
				"data": "servicename", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="distId"  distlgd="' + full.serviceid + '">' + data + '</div>';
				}
			},

			{
				"data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="reject" reject_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="pending" pend_id="' + full.serviceid + '">' + data + '</div>';
				}
			},

			{
				"data": "max_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortpscount" ortpscount_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "min_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "avg_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "median_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			}
		],
		dom: 'Blftrip',
		buttons: [
			{
				extend: 'excelHtml5',
				text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
				titleAttr: 'Excel'
			},
			{
				extend: 'pdfHtml5',
				text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
				titleAttr: 'PDF'
			}
		],
	});
	$.ajax({
		type: "POST",
		url: "/getDistinctChildZoneByserviceAndparentLgd",
		contentType: 'application/json',
		data: JSON.stringify({ serviceIds: serviceid, parent_lgd: Zone }),
		success: function(data) {
			console.log(data);
			$('#cZone').html('');
			let options = ``;

			for (let ofc of data) {
				options += `<option value="` + ofc[0] + `">` + ofc[1] + `</option>`;
			}
			$('#cZone').html(options);
			$('#cZone').selectpicker('refresh');
		}, error: function(jqXHR) {
			jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : ""
		}
	});


});
$('#cZone').on('change', function() {
	$("#appliedCount").html("");
	$("#deliverCount").html('');
	$("#forwardCount").html('');
	$("#rejectCount").html('');
	$("#totalAmountCount").html('');
	if ($('#cZone').val() === null || $('#cZone').val().length === 0) {
		$('#pZone').trigger('change');
		return;
	}
	let deliverCount = 0;
	let forwardCount = 0;
	let rejectCount = 0;
	const serviceid = $('#Service').val();
	const zone = $('#cZone').val();
	//getallAjaxcallbyServiceIdandZone(serviceid,Zone);
	zoneReport.destroy();
	zoneReport = $('#zonetbl').DataTable({
		scrollX: true,
		scrollY: 300,
		"ajax": {
			"url": "/getDistinctCountByserviceandchildZone",
			"type": "POST",
			"contentType": "application/json",  // ✅ Added this line
			"data": function(d) {
				return JSON.stringify({ serviceIds: serviceid, main_lgd: zone });
			},
			"dataSrc": function(json) {
				let appliedCount = 0, deliverCount = 0, forwardCount = 0, rejectCount = 0, amountCount = 0;


				json.forEach(item => {
					appliedCount += item.appliedcount || 0;
					deliverCount += item.delivercount || 0;
					forwardCount += item.forwardcount || 0;
					rejectCount += item.rejectcount || 0;
					amountCount += item.total_payment_amount || 0;
				});


				$("#appliedCount").html(appliedCount);
				$("#deliverCount").html(deliverCount);
				$("#forwardCount").html(forwardCount);
				$("#rejectCount").html(rejectCount);
				$("#totalAmountCount").html(amountCount);
				setTimeout(function() {
					// Destroy previous charts if they exist
					if (typeof myPieCha !== "undefined" && myPieCha !== null) {
						myPieCha.destroy();
					}
					if (typeof halfChart !== "undefined" && halfChart !== null) {
						halfChart.destroy();
					}

					// Debug JSON Response
					console.log("Chart Data:", json);

					// Get chart contexts
					var ctxBar = document.getElementById("districtBarChart").getContext("2d");
					var ctxDoughnut = document.getElementById("halfChart").getContext("2d");

					// Extract Data
					let labels = json.map(item => item.zone_name);
					let deliverCounts = json.map(item => item.delivercount || 0);
					let rejectCounts = json.map(item => item.rejectcount || 0);
					let pendingCounts = json.map(item => item.forwardcount || 0);

					// Create Bar Chart
					myPieCha = new Chart(ctxBar, {
						type: "bar",
						data: {
							labels: labels,
							datasets: [
					{
						label: 'Deliver Count',
						data: deliverCounts,
						backgroundColor: '#ffa94d',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Reject Count',
						data: rejectCounts,
						backgroundColor: '#4dabf7',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Pending Count',
						data: pendingCounts,
						backgroundColor: '#f03e3e',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					}
				]
			},
			options: {
				 indexAxis: 'y',
				responsive: true,
				maintainAspectRatio: false,
				 scales: {
            x: {
                stacked: true // Enable stacking on x-axis
            },
            y: {
                stacked: true // Enable stacking on y-axis
            }
        }
			}
		});

					// Calculate Percentages for Doughnut Chart
					let totalDeliverCount = deliverCounts.reduce((sum, val) => sum + val, 0);
					let totalRejectCount = rejectCounts.reduce((sum, val) => sum + val, 0);
					let totalForwardCount = pendingCounts.reduce((sum, val) => sum + val, 0);
					let totalCount = totalDeliverCount + totalRejectCount + totalForwardCount;

					let percentDeliver = totalCount > 0 ? (totalDeliverCount / totalCount) * 100 : 0;
					let percentReject = totalCount > 0 ? (totalRejectCount / totalCount) * 100 : 0;
					let percentForward = totalCount > 0 ? (totalForwardCount / totalCount) * 100 : 0;

					// ✅ Create Half Doughnut Chart with ChartDataLabels Plugin
					halfChart = new Chart(ctxDoughnut, {
						type: "doughnut",
						data: {
							labels: ["Deliver", "Reject", "Pending"],
							datasets: [{
								label: "Percentage",
								data: [percentDeliver, percentReject, percentForward],
								backgroundColor: ["#ffa94d", "#4dabf7", "#f03e3e"],
								borderWidth: 1
							}]
						},
						options: {
							responsive: true,
							maintainAspectRatio: false,
							rotation: -90, // Rotate to make a semi-circle
							circumference: 180, // Only show 180 degrees (half circle)
							plugins: {
								legend: {
									display: true,
									position: "top"
								},
								tooltip: {
									callbacks: {
										label: function(tooltipItem) {
											let label = tooltipItem.label || "";
											let value = tooltipItem.raw.toFixed(2);
											let count;
											if (label === "Deliver") {
												count = totalDeliverCount;
											} else if (label === "Pending") {
												count = totalForwardCount;
											} else if (label === "Reject") {
												count = totalRejectCount;
											}
											return `${label}: ${value}% (${count} counts)`;
										}
									}
								},
								datalabels: {  // ✅ Add ChartDataLabels configuration
									display: true,
									color: "white",
									font: {
										weight: "bold",
										size: 16
									},
									formatter: function(value) {
										return value.toFixed(2) + "%";
									}
								}
							},
							layout: {
								padding: {
									top: 20,
									bottom: 20
								}
							}
						},
						plugins: [ChartDataLabels] // ✅ Add ChartDataLabels plugin
					});

				}, 500);

				return json;
			}
		},

		"columns": [
			{
				"data": "zone_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="distId"  distlgd="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "appliedcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="appl" appl_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "ortpsdelivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="reject" reject_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="pendingC" pend_id="' + full.lgd_code + '">' + data + '</div>';
				}
			},

			{
				"data": "ortpscount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortpscountC" ortpscount_id="' + full.lgd_code + '">' + data + '</div>';
				}
			},
			{
				"data": "ortps_percentage", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "total_payment_amount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			}
		],
		dom: 'Blftrip',
		buttons: [
			{
				extend: 'excelHtml5',
				text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
				titleAttr: 'Excel'
			},
			{
				extend: 'pdfHtml5',
				text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
				titleAttr: 'PDF'
			}
		],
	});
	$('#zonetbl').on('click', '#ortpscountC, #pendingC', function() {
		var id = $(this).attr("ortpscount_id") || $(this).attr("pend_id");
		console.log(id);
		if ($(this).attr("id") === "ortpscountC") {
			let url = "/getpendingOrtpsDataByserviceIdAndChildZone";
			ofcDetail.destroy();
			ofcDetail = $('#officelist').DataTable({
				scrollCollapse: true,
				scrollX: true,
				scrollY: 300,
				"ajax": {
					"url": url,
					"type": "POST",
					"contentType": "application/json",  // ✅ Added this line
					"data": function(d) {
						return JSON.stringify({ serviceIds: serviceid, main_lgd: [id] });
					},
					"dataSrc": ""
				},
				"columns": [
					{
						"data": "user_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
							return '<div id="OCuserId" getlgd=' + id + ' getserviceId=' + serviceid + ' userlgd="' + full.user_name + '">' + data + '</div>';
						}
					},
					{
						"data": "count", "className": "dt-head-center dt-body-center",
					}


				],
			});
			autoAdjustColumns(ofcDetail);
			ofcModal.show();
		} else if ($(this).attr("id") === "pendingC") {
			let url = "/getpendingDataByserviceIdAndChildZone";
			ofcDetail.destroy();
			ofcDetail = $('#officelist').DataTable({
				scrollCollapse: true,
				scrollX: true,
				scrollY: 300,
				"ajax": {
					"url": url,
					"type": "POST",
					"contentType": "application/json",  // ✅ Added this line
					"data": function(d) {
						return JSON.stringify({ serviceIds: serviceid, main_lgd: [id] });
					},
					"dataSrc": ""
				},
				"columns": [
					{
						"data": "user_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
							return '<div id="PCuserId" getlgd=' + id + ' getserviceId=' + serviceid + ' userlgd="' + full.user_name + '">' + data + '</div>';
						}
					},
					{
						"data": "count", "className": "dt-head-center dt-body-center",
					}


				],
			});
			autoAdjustColumns(pendingdetail);
			ofcModal.show();
		}
	});
	$('#officelist').on('click', '#PCuserId', function() {
		// let currentlyOpenRow = null;
		let id = $(this).attr("userLgd");
		let lgdid = $(this).attr("getlgd");
		let service = $(this).attr("getserviceId")
		console.log(id);

		var url;
		let tr = $(this).closest('tr');
		let row = ofcDetail.row(tr);
		let rowData = row.data();

		console.log(rowData);

		if (row) {
			// Close the currently open row if it's not the same row being clicked
			if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
				var openRow = ofcDetail.row(currentlyOpenRow);
				openRow.child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
		/*	if (currentlyOpenRow) {
				ofcDetail.row(currentlyOpenRow).child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}*/
			$.ajax({
				type: "POST",
				url: "/getpendingTaskDataByserviceIdAndUsernameAndChildZone",
				contentType: 'application/json',
				data: JSON.stringify({ serviceIds: [service], user_name: id, main_lgd: [lgdid] }),
				success: function(data) {
					console.log(data);

					var childRowContent = `<table id="listofUsername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                <thead>
                    <tr>
                        
                        <th>Task Name</th>
                        <th>Count</th>
                         <th>Total Amount</th>
                    </tr>
                </thead>
                <tbody>`;

					for (let dist of data) {
						childRowContent += `<tr>
                    
                   
                    <td id="taskname" >`+ dist.task_name + `</td>
                    <td id="count" >`+ dist.task_count + `</td>
                     <td id="taskid" >`+ dist.total_payment_amount + `</td>
                </tr>`;
					}

					// Closing the table
					childRowContent += `</tbody></table>`;

					if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
						row.child.hide();
						tr.removeClass('shown');
						currentlyOpenRow = null;
					} else {
						row.child(childRowContent).show();
						tr.addClass('shown');
						currentlyOpenRow = tr;
					}
				},
				error: function(xhr, textStatus, errorThrown) {
					console.error("Error fetching child row data:", errorThrown);
				}
			});
		}
	});
	$('#officelist').on('click', '#OCuserId', function() {
		// let currentlyOpenRow = null;
		let id = $(this).attr("userLgd");
		let lgdid = $(this).attr("getlgd");
		let service = $(this).attr("getserviceId")
		console.log(id);

		var url;
		let tr = $(this).closest('tr');
		let row = ofcDetail.row(tr);
		let rowData = row.data();

		console.log(rowData);

		if (row) {
			// Close the currently open row if it's not the same row being clicked
			if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
				var openRow = ofcDetail.row(currentlyOpenRow);
				openRow.child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
		/*	if (currentlyOpenRow) {
				ofcDetail.row(currentlyOpenRow).child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}*/
			$.ajax({
				type: "POST",
				url: "/getpendingOrtpsDataByserviceIdAndUsernameAndChildZone",
				contentType: 'application/json',
				data: JSON.stringify({ serviceIds: [service], user_name: id, main_lgd: [lgdid] }),
				success: function(data) {
					console.log(data);

					var childRowContent = `<table id="listofUsername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                <thead>
                    <tr>
                        
                        <th>Task Name</th>
                        <th>Count</th>
                         <th>Total Amount</th>
                    </tr>
                </thead>
                <tbody>`;

					for (let dist of data) {
						childRowContent += `<tr>
                    
                   
                    <td id="taskname" >`+ dist.task_name + `</td>
                    <td id="count" >`+ dist.task_count + `</td>
                     <td id="taskid" >`+ dist.total_payment_amount + `</td>
                </tr>`;
					}

					// Closing the table
					childRowContent += `</tbody></table>`;

					if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
						row.child.hide();
						tr.removeClass('shown');
						currentlyOpenRow = null;
					} else {
						row.child(childRowContent).show();
						tr.addClass('shown');
						currentlyOpenRow = tr;
					}
				},
				error: function(xhr, textStatus, errorThrown) {
					console.error("Error fetching child row data:", errorThrown);
				}
			});
		}
	});
	servicetable.destroy();
	servicetable = $('#servicetbl').DataTable({
		scrollX: true,
		scrollY: 300,
		"ajax": {
			"url": "/getMaxMinCountByServiceAndChildzone",
			"type": "POST",
			"contentType": "application/json",  // ✅ Added this line
			"data": function(d) {
				return JSON.stringify({ serviceIds: serviceid, main_lgd: zone });
			},
			"dataSrc": ""
		},

		"columns": [
			{
				"data": "servicename", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="distId"  distlgd="' + full.serviceid + '">' + data + '</div>';
				}
			},

			{
				"data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="reject" reject_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="pending" pend_id="' + full.serviceid + '">' + data + '</div>';
				}
			},

			{
				"data": "max_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortpscount" ortpscount_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "min_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "avg_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "median_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			}
		],
		dom: 'Blftrip',
		buttons: [
			{
				extend: 'excelHtml5',
				text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
				titleAttr: 'Excel'
			},
			{
				extend: 'pdfHtml5',
				text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
				titleAttr: 'PDF'
			}
		],
	});
	$.ajax({
		type: "POST",
		url: "/getDistinctOfcByserviceAndZone",
		contentType: 'application/json',
		data: JSON.stringify({ serviceIds: serviceid, zoneIds: zone }),
		success: function(data) {
			console.log(data);
			$('#Office').html('');
			let options = ``;

			for (let ofc of data) {
				options += `<option value="` + ofc[0] + `">` + ofc[1] + `</option>`;
			}
			$('#Office').html(options);
			$('#Office').selectpicker('refresh');
		}, error: function(jqXHR) {
			jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : ""
		}
	})

});

$('#gZone').on('change', function() {
	let deliverCount = 0;
	let forwardCount = 0;
	let rejectCount = 0;
	const serviceid = $('#Service').val();
	const Zone = $('#gZone').val();
	$("#appliedCount").html("");
	$("#deliverCount").html('');
	$("#forwardCount").html('');
	$("#rejectCount").html('');
	$("#totalAmountCount").html('');
	if ($('#gZone').val() === null || $('#gZone').val().length === 0) {
		$('#mZone').trigger('change');
		return;
	}
	zoneReport.destroy();
	zoneReport = $('#zonetbl').DataTable({
		scrollX: true,
		scrollY: 300,
		"ajax": {
			"url": "/getDistinctCountByserviceandgrandZone",
			"type": "POST",
			"contentType": "application/json",  // ✅ Added this line
			"data": function(d) {
				return JSON.stringify({ serviceIds: serviceid, main_lgd: Zone });
			},
			"dataSrc": function(json) {
				let appliedCount = 0, deliverCount = 0, forwardCount = 0, rejectCount = 0, amountCount = 0;


				json.forEach(item => {
					appliedCount += item.appliedcount || 0;
					deliverCount += item.delivercount || 0;
					forwardCount += item.forwardcount || 0;
					rejectCount += item.rejectcount || 0;
					amountCount += item.total_payment_amount || 0;
				});


				$("#appliedCount").html(appliedCount);
				$("#deliverCount").html(deliverCount);
				$("#forwardCount").html(forwardCount);
				$("#rejectCount").html(rejectCount);
				$("#totalAmountCount").html(amountCount);
				setTimeout(function() {
					// Destroy previous charts if they exist
					if (typeof myPieCha !== "undefined" && myPieCha !== null) {
						myPieCha.destroy();
					}
					if (typeof halfChart !== "undefined" && halfChart !== null) {
						halfChart.destroy();
					}

					// Debug JSON Response
					console.log("Chart Data:", json);

					// Get chart contexts
					var ctxBar = document.getElementById("districtBarChart").getContext("2d");
					var ctxDoughnut = document.getElementById("halfChart").getContext("2d");

					// Extract Data
					let labels = json.map(item => item.zone_name);
					let deliverCounts = json.map(item => item.delivercount || 0);
					let rejectCounts = json.map(item => item.rejectcount || 0);
					let pendingCounts = json.map(item => item.forwardcount || 0);

					// Create Bar Chart
					myPieCha = new Chart(ctxBar, {
						type: "bar",
						data: {
							labels: labels,
						datasets: [
					{
						label: 'Deliver Count',
						data: deliverCounts,
						backgroundColor: '#ffa94d',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Reject Count',
						data: rejectCounts,
						backgroundColor: '#4dabf7',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Pending Count',
						data: pendingCounts,
						backgroundColor: '#f03e3e',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					}
				]
			},
			options: {
				 indexAxis: 'y',
				responsive: true,
				maintainAspectRatio: false,
				 scales: {
            x: {
                stacked: true // Enable stacking on x-axis
            },
            y: {
                stacked: true // Enable stacking on y-axis
            }
        }
			}
		});

					// Calculate Percentages for Doughnut Chart
					let totalDeliverCount = deliverCounts.reduce((sum, val) => sum + val, 0);
					let totalRejectCount = rejectCounts.reduce((sum, val) => sum + val, 0);
					let totalForwardCount = pendingCounts.reduce((sum, val) => sum + val, 0);
					let totalCount = totalDeliverCount + totalRejectCount + totalForwardCount;

					let percentDeliver = totalCount > 0 ? (totalDeliverCount / totalCount) * 100 : 0;
					let percentReject = totalCount > 0 ? (totalRejectCount / totalCount) * 100 : 0;
					let percentForward = totalCount > 0 ? (totalForwardCount / totalCount) * 100 : 0;

					// ✅ Create Half Doughnut Chart with ChartDataLabels Plugin
					halfChart = new Chart(ctxDoughnut, {
						type: "doughnut",
						data: {
							labels: ["Deliver", "Reject", "Pending"],
							datasets: [{
								label: "Percentage",
								data: [percentDeliver, percentReject, percentForward],
								backgroundColor: ["#ffa94d", "#4dabf7", "#f03e3e"],
								borderWidth: 1
							}]
						},
						options: {
							responsive: true,
							maintainAspectRatio: false,
							rotation: -90, // Rotate to make a semi-circle
							circumference: 180, // Only show 180 degrees (half circle)
							plugins: {
								legend: {
									display: true,
									position: "top"
								},
								tooltip: {
									callbacks: {
										label: function(tooltipItem) {
											let label = tooltipItem.label || "";
											let value = tooltipItem.raw.toFixed(2);
											let count;
											if (label === "Deliver") {
												count = totalDeliverCount;
											} else if (label === "Pending") {
												count = totalForwardCount;
											} else if (label === "Reject") {
												count = totalRejectCount;
											}
											return `${label}: ${value}% (${count} counts)`;
										}
									}
								},
								datalabels: {  // ✅ Add ChartDataLabels configuration
									display: true,
									color: "white",
									font: {
										weight: "bold",
										size: 16
									},
									formatter: function(value) {
										return value.toFixed(2) + "%";
									}
								}
							},
							layout: {
								padding: {
									top: 20,
									bottom: 20
								}
							}
						},
						plugins: [ChartDataLabels] // ✅ Add ChartDataLabels plugin
					});

				}, 500);

				return json;

			}
		},

		"columns": [
			{
				"data": "zone_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="distId"  distlgd="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "appliedcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="appl" appl_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "ortpsdelivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="reject" reject_id="' + full.lgd_code + '">' + data + '</div>';
				}
			},
			{
				"data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="pendingG" pend_id="' + full.lgd_code + '">' + data + '</div>';
				}
			},

			{
				"data": "ortpscount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortpscountG" ortpscount_id="' + full.lgd_code + '">' + data + '</div>';
				}
			},
			{
				"data": "ortps_percentage", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "total_payment_amount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			}
		],
		dom: 'Blftrip',
		buttons: [
			{
				extend: 'excelHtml5',
				text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
				titleAttr: 'Excel'
			},
			{
				extend: 'pdfHtml5',
				text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
				titleAttr: 'PDF'
			}
		],
	});
	$('#zonetbl').on('click', '#ortpscountG, #pendingG', function() {
		var id = $(this).attr("ortpscount_id") || $(this).attr("pend_id");
		console.log(id);
		if ($(this).attr("id") === "ortpscountG") {
			let url = "/getpendingOrtpsDataByserviceIdAndGrandZone";
			ofcDetail.destroy();
			ofcDetail = $('#officelist').DataTable({
				scrollCollapse: true,
				scrollX: true,
				scrollY: 300,
				"ajax": {
					"url": url,
					"type": "POST",
					"contentType": "application/json",  // ✅ Added this line
					"data": function(d) {
						return JSON.stringify({ serviceIds: serviceid, main_lgd: [id] });
					},
					"dataSrc": ""
				},
				"columns": [
					{
						"data": "user_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
							return '<div id="OGuserId" getlgd=' + id + ' getserviceId=' + serviceid + ' userlgd="' + full.user_name + '">' + data + '</div>';
						}
					},
					{
						"data": "count", "className": "dt-head-center dt-body-center",
					}


				],
			});
			autoAdjustColumns(ofcDetail);
			ofcModal.show();
		} else if ($(this).attr("id") === "pendingG") {
			let url = "/getpendingDataByserviceIdAndGrandZone";
			ofcDetail.destroy();
			ofcDetail = $('#officelist').DataTable({
				scrollCollapse: true,
				scrollX: true,
				scrollY: 300,
				"ajax": {
					"url": url,
					"type": "POST",
					"contentType": "application/json",  // ✅ Added this line
					"data": function(d) {
						return JSON.stringify({ serviceIds: serviceid, main_lgd: [id] });
					},
					"dataSrc": ""
				},
				"columns": [
					{
						"data": "user_name", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
							return '<div id="PGuserId" getlgd=' + id + ' getserviceId=' + serviceid + ' userlgd="' + full.user_name + '">' + data + '</div>';
						}
					},
					{
						"data": "count", "className": "dt-head-center dt-body-center",
					}


				],
			});
			autoAdjustColumns(pendingdetail);
			ofcModal.show();
		}
	});
	$('#officelist').on('click', '#PGuserId', function() {
		// let currentlyOpenRow = null;
		let id = $(this).attr("userLgd");
		let lgdid = $(this).attr("getlgd");
		let service = $(this).attr("getserviceId")
		console.log(id);

		var url;
		let tr = $(this).closest('tr');
		let row = ofcDetail.row(tr);
		let rowData = row.data();

		console.log(rowData);

		if (row) {
			// Close the currently open row if it's not the same row being clicked
			if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
				var openRow = ofcDetail.row(currentlyOpenRow);
				openRow.child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			if (currentlyOpenRow) {
				ofcDetail.row(currentlyOpenRow).child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			$.ajax({
				type: "POST",
				url: "/getpendingTaskDataByserviceIdAndUsernameAndGrandZone",
				contentType: 'application/json',
				data: JSON.stringify({ serviceIds: [service], user_name: id, main_lgd: [lgdid] }),
				success: function(data) {
					console.log(data);

					var childRowContent = `<table id="listofUsername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                <thead>
                    <tr>
                        
                        <th>Task Name</th>
                        <th>Count</th>
                         <th>Total Amount</th>
                    </tr>
                </thead>
                <tbody>`;

					for (let dist of data) {
						childRowContent += `<tr>
                    
                   
                    <td id="taskname" >`+ dist.task_name + `</td>
                    <td id="count" >`+ dist.task_count + `</td>
                     <td id="taskid" >`+ dist.total_payment_amount + `</td>
                </tr>`;
					}

					// Closing the table
					childRowContent += `</tbody></table>`;

					if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
						row.child.hide();
						tr.removeClass('shown');
						currentlyOpenRow = null;
					} else {
						row.child(childRowContent).show();
						tr.addClass('shown');
						currentlyOpenRow = tr;
					}
				},
				error: function(xhr, textStatus, errorThrown) {
					console.error("Error fetching child row data:", errorThrown);
				}
			});
		}
	});
	$('#officelist').on('click', '#OGuserId', function() {
		// let currentlyOpenRow = null;
		let id = $(this).attr("userLgd");
		let lgdid = $(this).attr("getlgd");
		let service = $(this).attr("getserviceId")
		console.log(id);

		var url;
		let tr = $(this).closest('tr');
		let row = ofcDetail.row(tr);
		let rowData = row.data();

		console.log(rowData);

		if (row) {
			// Close the currently open row if it's not the same row being clicked
			if (currentlyOpenRow && currentlyOpenRow[0] !== tr[0]) {
				var openRow = ofcDetail.row(currentlyOpenRow);
				openRow.child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			if (currentlyOpenRow) {
				ofcDetail.row(currentlyOpenRow).child.hide();
				currentlyOpenRow.removeClass('shown');
				currentlyOpenRow = null;
			}
			$.ajax({
				type: "POST",
				url: "/getpendingOrtpsDataByserviceIdAndUsernameAndGrandZone",
				contentType: 'application/json',
				data: JSON.stringify({ serviceIds: [service], user_name: id, main_lgd: [lgdid] }),
				success: function(data) {
					console.log(data);

					var childRowContent = `<table id="listofUsername" class="table table-primary table-striped" style="width:90%; margin:0 auto;">
                <thead>
                    <tr>
                        
                        <th>Task Name</th>
                        <th>Count</th>
                         <th>Total Amount</th>
                    </tr>
                </thead>
                <tbody>`;

					for (let dist of data) {
						childRowContent += `<tr>
                    
                   
                    <td id="taskname" >`+ dist.task_name + `</td>
                    <td id="count" >`+ dist.task_count + `</td>
                     <td id="taskid" >`+ dist.total_payment_amount + `</td>
                </tr>`;
					}

					// Closing the table
					childRowContent += `</tbody></table>`;

					if (currentlyOpenRow && currentlyOpenRow[0] === tr[0]) {
						row.child.hide();
						tr.removeClass('shown');
						currentlyOpenRow = null;
					} else {
						row.child(childRowContent).show();
						tr.addClass('shown');
						currentlyOpenRow = tr;
					}
				},
				error: function(xhr, textStatus, errorThrown) {
					console.error("Error fetching child row data:", errorThrown);
				}
			});
		}
	});
	servicetable.destroy();
	servicetable = $('#servicetbl').DataTable({
		scrollX: true,
		scrollY: 300,
		"ajax": {
			"url": "/getMaxMinCountByServiceAndGrandzone",
			"type": "POST",
			"contentType": "application/json",  // ✅ Added this line
			"data": function(d) {
				return JSON.stringify({ serviceIds: serviceid, main_lgd: Zone });
			},
			"dataSrc": ""
		},

		"columns": [
			{
				"data": "servicename", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="distId"  distlgd="' + full.serviceid + '">' + data + '</div>';
				}
			},

			{
				"data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="reject" reject_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="pending" pend_id="' + full.serviceid + '">' + data + '</div>';
				}
			},

			{
				"data": "max_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortpscount" ortpscount_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "min_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "avg_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "median_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			}
		],
		dom: 'Blftrip',
		buttons: [
			{
				extend: 'excelHtml5',
				text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
				titleAttr: 'Excel'
			},
			{
				extend: 'pdfHtml5',
				text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
				titleAttr: 'PDF'
			}
		],
	});
	$.ajax({
		type: "POST",
		url: "/getDistinctParentZoneByserviceAndgrandLgd",
		contentType: 'application/json',
		data: JSON.stringify({ serviceIds: serviceid, grand_lgd: Zone }),
		success: function(data) {
			console.log(data);
			$('#pZone').html('');
			let options = ``;

			for (let ofc of data) {
				options += `<option value="` + ofc[0] + `">` + ofc[1] + `</option>`;
			}
			$('#pZone').html(options);
			$('#pZone').selectpicker('refresh');
		}, error: function(jqXHR) {
			jqXHR.responseJSON ? showToast(jqXHR.responseJSON.message) : ""
		}
	});

});


//on change of select
$('#Service').on('change', function() {
	var service = $('#Service').val() || []; // Ensure it's an array

	// Reset displayed counts
	$("#appliedCount").html("");
	$("#deliverCount").html('');
	$("#forwardCount").html('');
	$("#rejectCount").html('');
	$("#totalAmountCount").html('');

	// Destroy DataTable if it exists
	if ($.fn.DataTable.isDataTable('#zonetbl')) {
		zoneReport.destroy();
	}

	zoneReport = $('#zonetbl').DataTable({
		scrollX: true,
		scrollY: 300,
		"ajax": {
			"url": "/getEnergyAllcountByService",
			"type": "GET",
			"dataSrc": function(json) {
				let appliedCount = 0, deliverCount = 0, forwardCount = 0, rejectCount = 0, amountCount = 0;

				let selectedServices = service.map(id => id.toString().trim());

				let filteredData = json.filter(item => selectedServices.includes(item.serviceid.toString().trim()));

				let deliverCounts = [], rejectCounts = [], forwardCounts = [];

				filteredData.forEach(item => {
					appliedCount += item.appliedcount || 0;
					deliverCount += item.delivercount || 0;
					forwardCount += item.forwardcount || 0;
					rejectCount += item.rejectcount || 0;
					amountCount += item.total_payment_amount || 0;

					// Collect values for bar chart
					deliverCounts.push(item.delivercount || 0);
					rejectCounts.push(item.rejectcount || 0);
					forwardCounts.push(item.forwardcount || 0);
				});

				$("#appliedCount").html(appliedCount);
				$("#deliverCount").html(deliverCount);
				$("#forwardCount").html(forwardCount);
				$("#rejectCount").html(rejectCount);
				$("#totalAmountCount").html(amountCount);

				setTimeout(() => {
					// Destroy previous charts if they exist
					if (typeof myPieCha !== 'undefined' && myPieCha) {
						myPieCha.destroy();
					}
					if (typeof halfChart !== 'undefined' && halfChart) {
						halfChart.destroy();
					}

					var ctxBar = document.getElementById('districtBarChart').getContext('2d');
					var ctxDoughnut = document.getElementById('halfChart').getContext('2d');

					// ✅ Create Bar Chart
					myPieCha = new Chart(ctxBar, {
						type: 'bar',
						data: {
							labels: filteredData.map(item => item.service),
							datasets: [
					{
						label: 'Deliver Count',
						data: deliverCounts,
						backgroundColor: '#ffa94d',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Reject Count',
						data: rejectCounts,
						backgroundColor: '#4dabf7',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Pending Count',
						data: forwardCounts,
						backgroundColor: '#f03e3e',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					}
				]
			},
			options: {
				 indexAxis: 'y',
				responsive: true,
				maintainAspectRatio: false,
				 scales: {
            x: {
                stacked: true // Enable stacking on x-axis
            },
            y: {
                stacked: true // Enable stacking on y-axis
            }
        }
			}
		});

					// ✅ Calculate percentages for half doughnut chart
					let totalCount = deliverCount + rejectCount + forwardCount;
					let percentDeliver = totalCount > 0 ? (deliverCount / totalCount) * 100 : 0;
					let percentReject = totalCount > 0 ? (rejectCount / totalCount) * 100 : 0;
					let percentForward = totalCount > 0 ? (forwardCount / totalCount) * 100 : 0;

					// ✅ Create Half Doughnut Chart
					halfChart = new Chart(ctxDoughnut, {
						type: "doughnut",
						data: {
							labels: ["Deliver", "Reject", "Pending"],
							datasets: [{
								label: "Percentage",
								data: [percentDeliver, percentReject, percentForward],
								backgroundColor: ["#ffa94d", "#4dabf7", "#f03e3e"],
								borderWidth: 1
							}]
						},
						options: {
							responsive: true,
							maintainAspectRatio: false,
							rotation: -90, // Rotate to make a semi-circle
							circumference: 180, // Only show 180 degrees (half circle)
							plugins: {
								legend: {
									display: true,
									position: "top"
								},
								tooltip: {
									callbacks: {
										label: function(tooltipItem) {
											let label = tooltipItem.label || "";
											let value = tooltipItem.raw.toFixed(2);
											let count;
											if (label === "Deliver") {
												count = deliverCount;
											} else if (label === "Pending") {
												count = forwardCount;
											} else if (label === "Reject") {
												count = rejectCount;
											}
											return `${label}: ${value}% (${count} counts)`;
										}
									}
								},
								datalabels: {  // ✅ ChartDataLabels for percentages
									display: true,
									color: "white",
									font: {
										weight: "bold",
										size: 16
									},
									formatter: function(value) {
										return value.toFixed(2) + "%";
									}
								}
							},
							layout: {
								padding: {
									top: 20,
									bottom: 20
								}
							}
						},
						plugins: [ChartDataLabels] // ✅ Ensure ChartDataLabels is added
					});

				}, 100);

				return filteredData;
			}
		},
		"columns": [
			{ "data": "service", "className": "dt-head-center dt-body-center", "render": function(data, type, full) { return `<div id="distId" distlgd="${full.serviceid}">${data}</div>`; } },
			{ "data": "appliedcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full) { return `<div id="appl" appl_id="${full.serviceid}">${data}</div>`; } },
			{ "data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full) { return `<div id="deliver" deli_id="${full.serviceid}">${data}</div>`; } },
			{ "data": "ortpsdelivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full) { return `<div id="deliver" deli_id="${full.serviceid}">${data}</div>`; } },
			{ "data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full) { return `<div id="reject" reject_id="${full.serviceid}">${data}</div>`; } },
			{ "data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full) { return `<div id="pending" pend_id="${full.serviceid}">${data}</div>`; } },
			{ "data": "ortpscount", "className": "dt-head-center dt-body-center", "render": function(data, type, full) { return `<div id="ortpscount" ortpscount_id="${full.serviceid}">${data}</div>`; } },
			{ "data": "ortps_percentage", "className": "dt-head-center dt-body-center", "render": function(data, type, full) { return `<div id="ortps_percent" percent_id="${full.serviceid}">${data}</div>`; } },
			{ "data": "total_payment_amount", "className": "dt-head-center dt-body-center", "render": function(data, type, full) { return `<div id="ortps_percent" percent_id="${full.serviceid}">${data}</div>`; } }
		],
		dom: 'Blftrip',
		buttons: [
			{ extend: 'excelHtml5', text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>', titleAttr: 'Excel' },
			{ extend: 'pdfHtml5', text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>', titleAttr: 'PDF' }
		],
	});
	servicetable.destroy();
	servicetable = $('#servicetbl').DataTable({
		scrollX: true,
		scrollY: 300,
		"ajax": {
			"url": "/findMaxMinTimeByService",
			"type": "GET",
			"dataSrc": function(json) {


				let selectedServices = service.map(id => id.toString().trim());

				let filteredData = json.filter(item => selectedServices.includes(item.baseservice_id.toString().trim()));
				return filteredData;
			}
		},

		"columns": [
			{
				"data": "servicename", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="distId"  distlgd="' + full.serviceid + '">' + data + '</div>';
				}
			},

			{
				"data": "delivercount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="deliver" deli_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "rejectcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="reject" reject_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "forwardcount", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="pending" pend_id="' + full.serviceid + '">' + data + '</div>';
				}
			},

			{
				"data": "max_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortpscount" ortpscount_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "min_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "avg_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			},
			{
				"data": "median_diff", "className": "dt-head-center dt-body-center", "render": function(data, type, full, meta) {
					return '<div id="ortps_percent" percent_id="' + full.serviceid + '">' + data + '</div>';
				}
			}
		],
		dom: 'Blftrip',
		buttons: [
			{
				extend: 'excelHtml5',
				text: '<i class="fas fa-file-excel fa-xl" style="color: #1dc007;"></i>',
				titleAttr: 'Excel'
			},
			{
				extend: 'pdfHtml5',
				text: '<i class="fas fa-file-pdf fa-xl" style="color: #e63a0f;"></i>',
				titleAttr: 'PDF'
			}
		],
	});
	getallAjaxcallbyServiceId(service);
});




//displaying bar chart by count
$.ajax({
	url: '/getEnergyAllcountByService',
	method: 'GET',
	dataType: 'json',
	success: function(data) {
		console.log(data);

		// Extract data from API response
		const districts = data.map(entry => entry.service);
		const deliverCounts = data.map(entry => entry.delivercount || 0);
		const forwardCounts = data.map(entry => entry.forwardcount || 0);
		const rejectCounts = data.map(entry => entry.rejectcount || 0);

		// Calculate totals
		const totalDeliver = deliverCounts.reduce((sum, val) => sum + val, 0);
		const totalReject = rejectCounts.reduce((sum, val) => sum + val, 0);
		const totalForward = forwardCounts.reduce((sum, val) => sum + val, 0);
		const total = totalDeliver + totalReject + totalForward;

		// Calculate percentages for half doughnut chart
		const percentDeliver = total > 0 ? (totalDeliver / total) * 100 : 0;
		const percentReject = total > 0 ? (totalReject / total) * 100 : 0;
		const percentForward = total > 0 ? (totalForward / total) * 100 : 0;

		// ✅ Destroy previous charts if they exist
		if (typeof myPieCha !== 'undefined' && myPieCha) {
			myPieCha.destroy();
		}
		if (typeof halfChart !== 'undefined' && halfChart) {
			halfChart.destroy();
		}

		// ✅ Create Bar Chart
		var ctxBar = document.getElementById('districtBarChart').getContext('2d');
		myPieCha = new Chart(ctxBar, {
			type: 'bar',
			data: {
				labels: districts,
				datasets: [
					{
						label: 'Deliver Count',
						data: deliverCounts,
						backgroundColor: '#ffa94d',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Reject Count',
						data: rejectCounts,
						backgroundColor: '#4dabf7',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					},
					{
						label: 'Pending Count',
						data: forwardCounts,
						backgroundColor: '#f03e3e',
						borderColor: '#000000',
						borderWidth: 1,
						 stack: 'stack1'
					}
				]
			},
			options: {
				 indexAxis: 'y',
				responsive: true,
				maintainAspectRatio: false,
				 scales: {
            x: {
                stacked: true // Enable stacking on x-axis
            },
            y: {
                stacked: true // Enable stacking on y-axis
            }
        }
			}
		});

		// ✅ Create Half Doughnut Chart
		var ctxDoughnut = document.getElementById('halfChart').getContext('2d');
		halfChart = new Chart(ctxDoughnut, {
			type: "doughnut",
			data: {
				labels: ["Deliver", "Reject", "Pending"],
				datasets: [{
					data: [percentDeliver, percentReject, percentForward],
					backgroundColor: ["#ffa94d", "#4dabf7", "#f03e3e"],
					borderWidth: 1
				}]
			},
			options: {
				responsive: true,
				maintainAspectRatio: false,
				rotation: -90, // Rotate to make a semi-circle
				circumference: 180, // Show only 180 degrees (half circle)
				plugins: {
					legend: {
						display: true,
						position: "top"
					},
					tooltip: {
						callbacks: {
							label: function(tooltipItem) {
								let label = tooltipItem.label || "";
								let value = tooltipItem.raw.toFixed(2);
								let count;
								if (label === "Deliver") {
									count = totalDeliver;
								} else if (label === "Pending") {
									count = totalForward;
								} else if (label === "Reject") {
									count = totalReject;
								}
								return `${label}: ${value}% (${count} counts)`;
							}
						}
					},
					datalabels: {  // ✅ Display percentage inside the doughnut
						display: true,
						color: "white",
						font: {
							weight: "bold",
							size: 16
						},
						formatter: function(value) {
							return value.toFixed(2) + "%";
						}
					}
				},
				layout: {
					padding: {
						top: 20,
						bottom: 20
					}
				}
			},
			plugins: [ChartDataLabels] // ✅ Ensure ChartDataLabels is added
		});
	},
	error: function(xhr, status, error) {
		console.error('Error fetching data:', error);
	}
});


$('#districttbl').on('click', '#ortpscount, #pending', function() {
	var id = $(this).attr("ortpscount_id") || $(this).attr("pend_id");
	console.log(id);
	if ($(this).attr("id") === "ortpscount") {
		url = "/getofficebyortpscount/" + id;
		ofcDetail.destroy();
		ofcDetail = $('#officelist').DataTable({
			scrollCollapse: true,
			scrollX: true,
			scrollY: 300,
			"ajax": {
				"url": url,
				"type": "GET",
				"dataSrc": ""
			},
			"columns": [
				{
					"data": null, "render": function(data, type, row) {
						return `<div id="userid" userLgd="` + data[1] + `"> ` + data[0] + ` </div>`;
					}
				},
				{
					"data": null, "render": function(data, type, row) {
						return data[2];
					}
				}
			]
		});
		autoAdjustColumns(ofcDetail);
		ofcModal.show();
	} else if ($(this).attr("id") === "pending") {
		url = "/getofficenamebypendingcount/" + id;
		pendingdetail.destroy();
		pendingdetail = $('#example1').DataTable({
			scrollCollapse: true,
			scrollX: true,
			scrollY: 300,
			"ajax": {
				"url": url,
				"type": "GET",
				"dataSrc": ""
			},
			"columns": [
				{
					"data": null, "render": function(data, type, row) {
						return `<div id="userId" userlgd="` + data[1] + `"> ` + data[0] + ` </div>`
					}
				},
				{
					"data": null, "render": function(data, type, row) {
						return data[2];
					}
				}
			]
		});
		autoAdjustColumns(pendingdetail);
		pendingModal.show();
	}
});






























