package in.nic.edistdash;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdistdashApplicationTests {

	@Test
	void contextLoads() {
	}

}
